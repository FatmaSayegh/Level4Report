(function(scope){
'use strict';

function F(arity, fun, wrapper) {
  wrapper.a = arity;
  wrapper.f = fun;
  return wrapper;
}

function F2(fun) {
  return F(2, fun, function(a) { return function(b) { return fun(a,b); }; })
}
function F3(fun) {
  return F(3, fun, function(a) {
    return function(b) { return function(c) { return fun(a, b, c); }; };
  });
}
function F4(fun) {
  return F(4, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return fun(a, b, c, d); }; }; };
  });
}
function F5(fun) {
  return F(5, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return fun(a, b, c, d, e); }; }; }; };
  });
}
function F6(fun) {
  return F(6, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return fun(a, b, c, d, e, f); }; }; }; }; };
  });
}
function F7(fun) {
  return F(7, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return function(g) { return fun(a, b, c, d, e, f, g); }; }; }; }; }; };
  });
}
function F8(fun) {
  return F(8, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return function(g) { return function(h) {
    return fun(a, b, c, d, e, f, g, h); }; }; }; }; }; }; };
  });
}
function F9(fun) {
  return F(9, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return function(g) { return function(h) { return function(i) {
    return fun(a, b, c, d, e, f, g, h, i); }; }; }; }; }; }; }; };
  });
}

function A2(fun, a, b) {
  return fun.a === 2 ? fun.f(a, b) : fun(a)(b);
}
function A3(fun, a, b, c) {
  return fun.a === 3 ? fun.f(a, b, c) : fun(a)(b)(c);
}
function A4(fun, a, b, c, d) {
  return fun.a === 4 ? fun.f(a, b, c, d) : fun(a)(b)(c)(d);
}
function A5(fun, a, b, c, d, e) {
  return fun.a === 5 ? fun.f(a, b, c, d, e) : fun(a)(b)(c)(d)(e);
}
function A6(fun, a, b, c, d, e, f) {
  return fun.a === 6 ? fun.f(a, b, c, d, e, f) : fun(a)(b)(c)(d)(e)(f);
}
function A7(fun, a, b, c, d, e, f, g) {
  return fun.a === 7 ? fun.f(a, b, c, d, e, f, g) : fun(a)(b)(c)(d)(e)(f)(g);
}
function A8(fun, a, b, c, d, e, f, g, h) {
  return fun.a === 8 ? fun.f(a, b, c, d, e, f, g, h) : fun(a)(b)(c)(d)(e)(f)(g)(h);
}
function A9(fun, a, b, c, d, e, f, g, h, i) {
  return fun.a === 9 ? fun.f(a, b, c, d, e, f, g, h, i) : fun(a)(b)(c)(d)(e)(f)(g)(h)(i);
}

console.warn('Compiled in DEV mode. Follow the advice at https://elm-lang.org/0.19.1/optimize for better performance and smaller assets.');


var _JsArray_empty = [];

function _JsArray_singleton(value)
{
    return [value];
}

function _JsArray_length(array)
{
    return array.length;
}

var _JsArray_initialize = F3(function(size, offset, func)
{
    var result = new Array(size);

    for (var i = 0; i < size; i++)
    {
        result[i] = func(offset + i);
    }

    return result;
});

var _JsArray_initializeFromList = F2(function (max, ls)
{
    var result = new Array(max);

    for (var i = 0; i < max && ls.b; i++)
    {
        result[i] = ls.a;
        ls = ls.b;
    }

    result.length = i;
    return _Utils_Tuple2(result, ls);
});

var _JsArray_unsafeGet = F2(function(index, array)
{
    return array[index];
});

var _JsArray_unsafeSet = F3(function(index, value, array)
{
    var length = array.length;
    var result = new Array(length);

    for (var i = 0; i < length; i++)
    {
        result[i] = array[i];
    }

    result[index] = value;
    return result;
});

var _JsArray_push = F2(function(value, array)
{
    var length = array.length;
    var result = new Array(length + 1);

    for (var i = 0; i < length; i++)
    {
        result[i] = array[i];
    }

    result[length] = value;
    return result;
});

var _JsArray_foldl = F3(function(func, acc, array)
{
    var length = array.length;

    for (var i = 0; i < length; i++)
    {
        acc = A2(func, array[i], acc);
    }

    return acc;
});

var _JsArray_foldr = F3(function(func, acc, array)
{
    for (var i = array.length - 1; i >= 0; i--)
    {
        acc = A2(func, array[i], acc);
    }

    return acc;
});

var _JsArray_map = F2(function(func, array)
{
    var length = array.length;
    var result = new Array(length);

    for (var i = 0; i < length; i++)
    {
        result[i] = func(array[i]);
    }

    return result;
});

var _JsArray_indexedMap = F3(function(func, offset, array)
{
    var length = array.length;
    var result = new Array(length);

    for (var i = 0; i < length; i++)
    {
        result[i] = A2(func, offset + i, array[i]);
    }

    return result;
});

var _JsArray_slice = F3(function(from, to, array)
{
    return array.slice(from, to);
});

var _JsArray_appendN = F3(function(n, dest, source)
{
    var destLen = dest.length;
    var itemsToCopy = n - destLen;

    if (itemsToCopy > source.length)
    {
        itemsToCopy = source.length;
    }

    var size = destLen + itemsToCopy;
    var result = new Array(size);

    for (var i = 0; i < destLen; i++)
    {
        result[i] = dest[i];
    }

    for (var i = 0; i < itemsToCopy; i++)
    {
        result[i + destLen] = source[i];
    }

    return result;
});



// LOG

var _Debug_log_UNUSED = F2(function(tag, value)
{
	return value;
});

var _Debug_log = F2(function(tag, value)
{
	console.log(tag + ': ' + _Debug_toString(value));
	return value;
});


// TODOS

function _Debug_todo(moduleName, region)
{
	return function(message) {
		_Debug_crash(8, moduleName, region, message);
	};
}

function _Debug_todoCase(moduleName, region, value)
{
	return function(message) {
		_Debug_crash(9, moduleName, region, value, message);
	};
}


// TO STRING

function _Debug_toString_UNUSED(value)
{
	return '<internals>';
}

function _Debug_toString(value)
{
	return _Debug_toAnsiString(false, value);
}

function _Debug_toAnsiString(ansi, value)
{
	if (typeof value === 'function')
	{
		return _Debug_internalColor(ansi, '<function>');
	}

	if (typeof value === 'boolean')
	{
		return _Debug_ctorColor(ansi, value ? 'True' : 'False');
	}

	if (typeof value === 'number')
	{
		return _Debug_numberColor(ansi, value + '');
	}

	if (value instanceof String)
	{
		return _Debug_charColor(ansi, "'" + _Debug_addSlashes(value, true) + "'");
	}

	if (typeof value === 'string')
	{
		return _Debug_stringColor(ansi, '"' + _Debug_addSlashes(value, false) + '"');
	}

	if (typeof value === 'object' && '$' in value)
	{
		var tag = value.$;

		if (typeof tag === 'number')
		{
			return _Debug_internalColor(ansi, '<internals>');
		}

		if (tag[0] === '#')
		{
			var output = [];
			for (var k in value)
			{
				if (k === '$') continue;
				output.push(_Debug_toAnsiString(ansi, value[k]));
			}
			return '(' + output.join(',') + ')';
		}

		if (tag === 'Set_elm_builtin')
		{
			return _Debug_ctorColor(ansi, 'Set')
				+ _Debug_fadeColor(ansi, '.fromList') + ' '
				+ _Debug_toAnsiString(ansi, $elm$core$Set$toList(value));
		}

		if (tag === 'RBNode_elm_builtin' || tag === 'RBEmpty_elm_builtin')
		{
			return _Debug_ctorColor(ansi, 'Dict')
				+ _Debug_fadeColor(ansi, '.fromList') + ' '
				+ _Debug_toAnsiString(ansi, $elm$core$Dict$toList(value));
		}

		if (tag === 'Array_elm_builtin')
		{
			return _Debug_ctorColor(ansi, 'Array')
				+ _Debug_fadeColor(ansi, '.fromList') + ' '
				+ _Debug_toAnsiString(ansi, $elm$core$Array$toList(value));
		}

		if (tag === '::' || tag === '[]')
		{
			var output = '[';

			value.b && (output += _Debug_toAnsiString(ansi, value.a), value = value.b)

			for (; value.b; value = value.b) // WHILE_CONS
			{
				output += ',' + _Debug_toAnsiString(ansi, value.a);
			}
			return output + ']';
		}

		var output = '';
		for (var i in value)
		{
			if (i === '$') continue;
			var str = _Debug_toAnsiString(ansi, value[i]);
			var c0 = str[0];
			var parenless = c0 === '{' || c0 === '(' || c0 === '[' || c0 === '<' || c0 === '"' || str.indexOf(' ') < 0;
			output += ' ' + (parenless ? str : '(' + str + ')');
		}
		return _Debug_ctorColor(ansi, tag) + output;
	}

	if (typeof DataView === 'function' && value instanceof DataView)
	{
		return _Debug_stringColor(ansi, '<' + value.byteLength + ' bytes>');
	}

	if (typeof File !== 'undefined' && value instanceof File)
	{
		return _Debug_internalColor(ansi, '<' + value.name + '>');
	}

	if (typeof value === 'object')
	{
		var output = [];
		for (var key in value)
		{
			var field = key[0] === '_' ? key.slice(1) : key;
			output.push(_Debug_fadeColor(ansi, field) + ' = ' + _Debug_toAnsiString(ansi, value[key]));
		}
		if (output.length === 0)
		{
			return '{}';
		}
		return '{ ' + output.join(', ') + ' }';
	}

	return _Debug_internalColor(ansi, '<internals>');
}

function _Debug_addSlashes(str, isChar)
{
	var s = str
		.replace(/\\/g, '\\\\')
		.replace(/\n/g, '\\n')
		.replace(/\t/g, '\\t')
		.replace(/\r/g, '\\r')
		.replace(/\v/g, '\\v')
		.replace(/\0/g, '\\0');

	if (isChar)
	{
		return s.replace(/\'/g, '\\\'');
	}
	else
	{
		return s.replace(/\"/g, '\\"');
	}
}

function _Debug_ctorColor(ansi, string)
{
	return ansi ? '\x1b[96m' + string + '\x1b[0m' : string;
}

function _Debug_numberColor(ansi, string)
{
	return ansi ? '\x1b[95m' + string + '\x1b[0m' : string;
}

function _Debug_stringColor(ansi, string)
{
	return ansi ? '\x1b[93m' + string + '\x1b[0m' : string;
}

function _Debug_charColor(ansi, string)
{
	return ansi ? '\x1b[92m' + string + '\x1b[0m' : string;
}

function _Debug_fadeColor(ansi, string)
{
	return ansi ? '\x1b[37m' + string + '\x1b[0m' : string;
}

function _Debug_internalColor(ansi, string)
{
	return ansi ? '\x1b[36m' + string + '\x1b[0m' : string;
}

function _Debug_toHexDigit(n)
{
	return String.fromCharCode(n < 10 ? 48 + n : 55 + n);
}


// CRASH


function _Debug_crash_UNUSED(identifier)
{
	throw new Error('https://github.com/elm/core/blob/1.0.0/hints/' + identifier + '.md');
}


function _Debug_crash(identifier, fact1, fact2, fact3, fact4)
{
	switch(identifier)
	{
		case 0:
			throw new Error('What node should I take over? In JavaScript I need something like:\n\n    Elm.Main.init({\n        node: document.getElementById("elm-node")\n    })\n\nYou need to do this with any Browser.sandbox or Browser.element program.');

		case 1:
			throw new Error('Browser.application programs cannot handle URLs like this:\n\n    ' + document.location.href + '\n\nWhat is the root? The root of your file system? Try looking at this program with `elm reactor` or some other server.');

		case 2:
			var jsonErrorString = fact1;
			throw new Error('Problem with the flags given to your Elm program on initialization.\n\n' + jsonErrorString);

		case 3:
			var portName = fact1;
			throw new Error('There can only be one port named `' + portName + '`, but your program has multiple.');

		case 4:
			var portName = fact1;
			var problem = fact2;
			throw new Error('Trying to send an unexpected type of value through port `' + portName + '`:\n' + problem);

		case 5:
			throw new Error('Trying to use `(==)` on functions.\nThere is no way to know if functions are "the same" in the Elm sense.\nRead more about this at https://package.elm-lang.org/packages/elm/core/latest/Basics#== which describes why it is this way and what the better version will look like.');

		case 6:
			var moduleName = fact1;
			throw new Error('Your page is loading multiple Elm scripts with a module named ' + moduleName + '. Maybe a duplicate script is getting loaded accidentally? If not, rename one of them so I know which is which!');

		case 8:
			var moduleName = fact1;
			var region = fact2;
			var message = fact3;
			throw new Error('TODO in module `' + moduleName + '` ' + _Debug_regionToString(region) + '\n\n' + message);

		case 9:
			var moduleName = fact1;
			var region = fact2;
			var value = fact3;
			var message = fact4;
			throw new Error(
				'TODO in module `' + moduleName + '` from the `case` expression '
				+ _Debug_regionToString(region) + '\n\nIt received the following value:\n\n    '
				+ _Debug_toString(value).replace('\n', '\n    ')
				+ '\n\nBut the branch that handles it says:\n\n    ' + message.replace('\n', '\n    ')
			);

		case 10:
			throw new Error('Bug in https://github.com/elm/virtual-dom/issues');

		case 11:
			throw new Error('Cannot perform mod 0. Division by zero error.');
	}
}

function _Debug_regionToString(region)
{
	if (region.start.line === region.end.line)
	{
		return 'on line ' + region.start.line;
	}
	return 'on lines ' + region.start.line + ' through ' + region.end.line;
}



// EQUALITY

function _Utils_eq(x, y)
{
	for (
		var pair, stack = [], isEqual = _Utils_eqHelp(x, y, 0, stack);
		isEqual && (pair = stack.pop());
		isEqual = _Utils_eqHelp(pair.a, pair.b, 0, stack)
		)
	{}

	return isEqual;
}

function _Utils_eqHelp(x, y, depth, stack)
{
	if (x === y)
	{
		return true;
	}

	if (typeof x !== 'object' || x === null || y === null)
	{
		typeof x === 'function' && _Debug_crash(5);
		return false;
	}

	if (depth > 100)
	{
		stack.push(_Utils_Tuple2(x,y));
		return true;
	}

	/**/
	if (x.$ === 'Set_elm_builtin')
	{
		x = $elm$core$Set$toList(x);
		y = $elm$core$Set$toList(y);
	}
	if (x.$ === 'RBNode_elm_builtin' || x.$ === 'RBEmpty_elm_builtin')
	{
		x = $elm$core$Dict$toList(x);
		y = $elm$core$Dict$toList(y);
	}
	//*/

	/**_UNUSED/
	if (x.$ < 0)
	{
		x = $elm$core$Dict$toList(x);
		y = $elm$core$Dict$toList(y);
	}
	//*/

	for (var key in x)
	{
		if (!_Utils_eqHelp(x[key], y[key], depth + 1, stack))
		{
			return false;
		}
	}
	return true;
}

var _Utils_equal = F2(_Utils_eq);
var _Utils_notEqual = F2(function(a, b) { return !_Utils_eq(a,b); });



// COMPARISONS

// Code in Generate/JavaScript.hs, Basics.js, and List.js depends on
// the particular integer values assigned to LT, EQ, and GT.

function _Utils_cmp(x, y, ord)
{
	if (typeof x !== 'object')
	{
		return x === y ? /*EQ*/ 0 : x < y ? /*LT*/ -1 : /*GT*/ 1;
	}

	/**/
	if (x instanceof String)
	{
		var a = x.valueOf();
		var b = y.valueOf();
		return a === b ? 0 : a < b ? -1 : 1;
	}
	//*/

	/**_UNUSED/
	if (typeof x.$ === 'undefined')
	//*/
	/**/
	if (x.$[0] === '#')
	//*/
	{
		return (ord = _Utils_cmp(x.a, y.a))
			? ord
			: (ord = _Utils_cmp(x.b, y.b))
				? ord
				: _Utils_cmp(x.c, y.c);
	}

	// traverse conses until end of a list or a mismatch
	for (; x.b && y.b && !(ord = _Utils_cmp(x.a, y.a)); x = x.b, y = y.b) {} // WHILE_CONSES
	return ord || (x.b ? /*GT*/ 1 : y.b ? /*LT*/ -1 : /*EQ*/ 0);
}

var _Utils_lt = F2(function(a, b) { return _Utils_cmp(a, b) < 0; });
var _Utils_le = F2(function(a, b) { return _Utils_cmp(a, b) < 1; });
var _Utils_gt = F2(function(a, b) { return _Utils_cmp(a, b) > 0; });
var _Utils_ge = F2(function(a, b) { return _Utils_cmp(a, b) >= 0; });

var _Utils_compare = F2(function(x, y)
{
	var n = _Utils_cmp(x, y);
	return n < 0 ? $elm$core$Basics$LT : n ? $elm$core$Basics$GT : $elm$core$Basics$EQ;
});


// COMMON VALUES

var _Utils_Tuple0_UNUSED = 0;
var _Utils_Tuple0 = { $: '#0' };

function _Utils_Tuple2_UNUSED(a, b) { return { a: a, b: b }; }
function _Utils_Tuple2(a, b) { return { $: '#2', a: a, b: b }; }

function _Utils_Tuple3_UNUSED(a, b, c) { return { a: a, b: b, c: c }; }
function _Utils_Tuple3(a, b, c) { return { $: '#3', a: a, b: b, c: c }; }

function _Utils_chr_UNUSED(c) { return c; }
function _Utils_chr(c) { return new String(c); }


// RECORDS

function _Utils_update(oldRecord, updatedFields)
{
	var newRecord = {};

	for (var key in oldRecord)
	{
		newRecord[key] = oldRecord[key];
	}

	for (var key in updatedFields)
	{
		newRecord[key] = updatedFields[key];
	}

	return newRecord;
}


// APPEND

var _Utils_append = F2(_Utils_ap);

function _Utils_ap(xs, ys)
{
	// append Strings
	if (typeof xs === 'string')
	{
		return xs + ys;
	}

	// append Lists
	if (!xs.b)
	{
		return ys;
	}
	var root = _List_Cons(xs.a, ys);
	xs = xs.b
	for (var curr = root; xs.b; xs = xs.b) // WHILE_CONS
	{
		curr = curr.b = _List_Cons(xs.a, ys);
	}
	return root;
}



var _List_Nil_UNUSED = { $: 0 };
var _List_Nil = { $: '[]' };

function _List_Cons_UNUSED(hd, tl) { return { $: 1, a: hd, b: tl }; }
function _List_Cons(hd, tl) { return { $: '::', a: hd, b: tl }; }


var _List_cons = F2(_List_Cons);

function _List_fromArray(arr)
{
	var out = _List_Nil;
	for (var i = arr.length; i--; )
	{
		out = _List_Cons(arr[i], out);
	}
	return out;
}

function _List_toArray(xs)
{
	for (var out = []; xs.b; xs = xs.b) // WHILE_CONS
	{
		out.push(xs.a);
	}
	return out;
}

var _List_map2 = F3(function(f, xs, ys)
{
	for (var arr = []; xs.b && ys.b; xs = xs.b, ys = ys.b) // WHILE_CONSES
	{
		arr.push(A2(f, xs.a, ys.a));
	}
	return _List_fromArray(arr);
});

var _List_map3 = F4(function(f, xs, ys, zs)
{
	for (var arr = []; xs.b && ys.b && zs.b; xs = xs.b, ys = ys.b, zs = zs.b) // WHILE_CONSES
	{
		arr.push(A3(f, xs.a, ys.a, zs.a));
	}
	return _List_fromArray(arr);
});

var _List_map4 = F5(function(f, ws, xs, ys, zs)
{
	for (var arr = []; ws.b && xs.b && ys.b && zs.b; ws = ws.b, xs = xs.b, ys = ys.b, zs = zs.b) // WHILE_CONSES
	{
		arr.push(A4(f, ws.a, xs.a, ys.a, zs.a));
	}
	return _List_fromArray(arr);
});

var _List_map5 = F6(function(f, vs, ws, xs, ys, zs)
{
	for (var arr = []; vs.b && ws.b && xs.b && ys.b && zs.b; vs = vs.b, ws = ws.b, xs = xs.b, ys = ys.b, zs = zs.b) // WHILE_CONSES
	{
		arr.push(A5(f, vs.a, ws.a, xs.a, ys.a, zs.a));
	}
	return _List_fromArray(arr);
});

var _List_sortBy = F2(function(f, xs)
{
	return _List_fromArray(_List_toArray(xs).sort(function(a, b) {
		return _Utils_cmp(f(a), f(b));
	}));
});

var _List_sortWith = F2(function(f, xs)
{
	return _List_fromArray(_List_toArray(xs).sort(function(a, b) {
		var ord = A2(f, a, b);
		return ord === $elm$core$Basics$EQ ? 0 : ord === $elm$core$Basics$LT ? -1 : 1;
	}));
});



// MATH

var _Basics_add = F2(function(a, b) { return a + b; });
var _Basics_sub = F2(function(a, b) { return a - b; });
var _Basics_mul = F2(function(a, b) { return a * b; });
var _Basics_fdiv = F2(function(a, b) { return a / b; });
var _Basics_idiv = F2(function(a, b) { return (a / b) | 0; });
var _Basics_pow = F2(Math.pow);

var _Basics_remainderBy = F2(function(b, a) { return a % b; });

// https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/divmodnote-letter.pdf
var _Basics_modBy = F2(function(modulus, x)
{
	var answer = x % modulus;
	return modulus === 0
		? _Debug_crash(11)
		:
	((answer > 0 && modulus < 0) || (answer < 0 && modulus > 0))
		? answer + modulus
		: answer;
});


// TRIGONOMETRY

var _Basics_pi = Math.PI;
var _Basics_e = Math.E;
var _Basics_cos = Math.cos;
var _Basics_sin = Math.sin;
var _Basics_tan = Math.tan;
var _Basics_acos = Math.acos;
var _Basics_asin = Math.asin;
var _Basics_atan = Math.atan;
var _Basics_atan2 = F2(Math.atan2);


// MORE MATH

function _Basics_toFloat(x) { return x; }
function _Basics_truncate(n) { return n | 0; }
function _Basics_isInfinite(n) { return n === Infinity || n === -Infinity; }

var _Basics_ceiling = Math.ceil;
var _Basics_floor = Math.floor;
var _Basics_round = Math.round;
var _Basics_sqrt = Math.sqrt;
var _Basics_log = Math.log;
var _Basics_isNaN = isNaN;


// BOOLEANS

function _Basics_not(bool) { return !bool; }
var _Basics_and = F2(function(a, b) { return a && b; });
var _Basics_or  = F2(function(a, b) { return a || b; });
var _Basics_xor = F2(function(a, b) { return a !== b; });



var _String_cons = F2(function(chr, str)
{
	return chr + str;
});

function _String_uncons(string)
{
	var word = string.charCodeAt(0);
	return !isNaN(word)
		? $elm$core$Maybe$Just(
			0xD800 <= word && word <= 0xDBFF
				? _Utils_Tuple2(_Utils_chr(string[0] + string[1]), string.slice(2))
				: _Utils_Tuple2(_Utils_chr(string[0]), string.slice(1))
		)
		: $elm$core$Maybe$Nothing;
}

var _String_append = F2(function(a, b)
{
	return a + b;
});

function _String_length(str)
{
	return str.length;
}

var _String_map = F2(function(func, string)
{
	var len = string.length;
	var array = new Array(len);
	var i = 0;
	while (i < len)
	{
		var word = string.charCodeAt(i);
		if (0xD800 <= word && word <= 0xDBFF)
		{
			array[i] = func(_Utils_chr(string[i] + string[i+1]));
			i += 2;
			continue;
		}
		array[i] = func(_Utils_chr(string[i]));
		i++;
	}
	return array.join('');
});

var _String_filter = F2(function(isGood, str)
{
	var arr = [];
	var len = str.length;
	var i = 0;
	while (i < len)
	{
		var char = str[i];
		var word = str.charCodeAt(i);
		i++;
		if (0xD800 <= word && word <= 0xDBFF)
		{
			char += str[i];
			i++;
		}

		if (isGood(_Utils_chr(char)))
		{
			arr.push(char);
		}
	}
	return arr.join('');
});

function _String_reverse(str)
{
	var len = str.length;
	var arr = new Array(len);
	var i = 0;
	while (i < len)
	{
		var word = str.charCodeAt(i);
		if (0xD800 <= word && word <= 0xDBFF)
		{
			arr[len - i] = str[i + 1];
			i++;
			arr[len - i] = str[i - 1];
			i++;
		}
		else
		{
			arr[len - i] = str[i];
			i++;
		}
	}
	return arr.join('');
}

var _String_foldl = F3(function(func, state, string)
{
	var len = string.length;
	var i = 0;
	while (i < len)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		i++;
		if (0xD800 <= word && word <= 0xDBFF)
		{
			char += string[i];
			i++;
		}
		state = A2(func, _Utils_chr(char), state);
	}
	return state;
});

var _String_foldr = F3(function(func, state, string)
{
	var i = string.length;
	while (i--)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		if (0xDC00 <= word && word <= 0xDFFF)
		{
			i--;
			char = string[i] + char;
		}
		state = A2(func, _Utils_chr(char), state);
	}
	return state;
});

var _String_split = F2(function(sep, str)
{
	return str.split(sep);
});

var _String_join = F2(function(sep, strs)
{
	return strs.join(sep);
});

var _String_slice = F3(function(start, end, str) {
	return str.slice(start, end);
});

function _String_trim(str)
{
	return str.trim();
}

function _String_trimLeft(str)
{
	return str.replace(/^\s+/, '');
}

function _String_trimRight(str)
{
	return str.replace(/\s+$/, '');
}

function _String_words(str)
{
	return _List_fromArray(str.trim().split(/\s+/g));
}

function _String_lines(str)
{
	return _List_fromArray(str.split(/\r\n|\r|\n/g));
}

function _String_toUpper(str)
{
	return str.toUpperCase();
}

function _String_toLower(str)
{
	return str.toLowerCase();
}

var _String_any = F2(function(isGood, string)
{
	var i = string.length;
	while (i--)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		if (0xDC00 <= word && word <= 0xDFFF)
		{
			i--;
			char = string[i] + char;
		}
		if (isGood(_Utils_chr(char)))
		{
			return true;
		}
	}
	return false;
});

var _String_all = F2(function(isGood, string)
{
	var i = string.length;
	while (i--)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		if (0xDC00 <= word && word <= 0xDFFF)
		{
			i--;
			char = string[i] + char;
		}
		if (!isGood(_Utils_chr(char)))
		{
			return false;
		}
	}
	return true;
});

var _String_contains = F2(function(sub, str)
{
	return str.indexOf(sub) > -1;
});

var _String_startsWith = F2(function(sub, str)
{
	return str.indexOf(sub) === 0;
});

var _String_endsWith = F2(function(sub, str)
{
	return str.length >= sub.length &&
		str.lastIndexOf(sub) === str.length - sub.length;
});

var _String_indexes = F2(function(sub, str)
{
	var subLen = sub.length;

	if (subLen < 1)
	{
		return _List_Nil;
	}

	var i = 0;
	var is = [];

	while ((i = str.indexOf(sub, i)) > -1)
	{
		is.push(i);
		i = i + subLen;
	}

	return _List_fromArray(is);
});


// TO STRING

function _String_fromNumber(number)
{
	return number + '';
}


// INT CONVERSIONS

function _String_toInt(str)
{
	var total = 0;
	var code0 = str.charCodeAt(0);
	var start = code0 == 0x2B /* + */ || code0 == 0x2D /* - */ ? 1 : 0;

	for (var i = start; i < str.length; ++i)
	{
		var code = str.charCodeAt(i);
		if (code < 0x30 || 0x39 < code)
		{
			return $elm$core$Maybe$Nothing;
		}
		total = 10 * total + code - 0x30;
	}

	return i == start
		? $elm$core$Maybe$Nothing
		: $elm$core$Maybe$Just(code0 == 0x2D ? -total : total);
}


// FLOAT CONVERSIONS

function _String_toFloat(s)
{
	// check if it is a hex, octal, or binary number
	if (s.length === 0 || /[\sxbo]/.test(s))
	{
		return $elm$core$Maybe$Nothing;
	}
	var n = +s;
	// faster isNaN check
	return n === n ? $elm$core$Maybe$Just(n) : $elm$core$Maybe$Nothing;
}

function _String_fromList(chars)
{
	return _List_toArray(chars).join('');
}




function _Char_toCode(char)
{
	var code = char.charCodeAt(0);
	if (0xD800 <= code && code <= 0xDBFF)
	{
		return (code - 0xD800) * 0x400 + char.charCodeAt(1) - 0xDC00 + 0x10000
	}
	return code;
}

function _Char_fromCode(code)
{
	return _Utils_chr(
		(code < 0 || 0x10FFFF < code)
			? '\uFFFD'
			:
		(code <= 0xFFFF)
			? String.fromCharCode(code)
			:
		(code -= 0x10000,
			String.fromCharCode(Math.floor(code / 0x400) + 0xD800, code % 0x400 + 0xDC00)
		)
	);
}

function _Char_toUpper(char)
{
	return _Utils_chr(char.toUpperCase());
}

function _Char_toLower(char)
{
	return _Utils_chr(char.toLowerCase());
}

function _Char_toLocaleUpper(char)
{
	return _Utils_chr(char.toLocaleUpperCase());
}

function _Char_toLocaleLower(char)
{
	return _Utils_chr(char.toLocaleLowerCase());
}



/**/
function _Json_errorToString(error)
{
	return $elm$json$Json$Decode$errorToString(error);
}
//*/


// CORE DECODERS

function _Json_succeed(msg)
{
	return {
		$: 0,
		a: msg
	};
}

function _Json_fail(msg)
{
	return {
		$: 1,
		a: msg
	};
}

function _Json_decodePrim(decoder)
{
	return { $: 2, b: decoder };
}

var _Json_decodeInt = _Json_decodePrim(function(value) {
	return (typeof value !== 'number')
		? _Json_expecting('an INT', value)
		:
	(-2147483647 < value && value < 2147483647 && (value | 0) === value)
		? $elm$core$Result$Ok(value)
		:
	(isFinite(value) && !(value % 1))
		? $elm$core$Result$Ok(value)
		: _Json_expecting('an INT', value);
});

var _Json_decodeBool = _Json_decodePrim(function(value) {
	return (typeof value === 'boolean')
		? $elm$core$Result$Ok(value)
		: _Json_expecting('a BOOL', value);
});

var _Json_decodeFloat = _Json_decodePrim(function(value) {
	return (typeof value === 'number')
		? $elm$core$Result$Ok(value)
		: _Json_expecting('a FLOAT', value);
});

var _Json_decodeValue = _Json_decodePrim(function(value) {
	return $elm$core$Result$Ok(_Json_wrap(value));
});

var _Json_decodeString = _Json_decodePrim(function(value) {
	return (typeof value === 'string')
		? $elm$core$Result$Ok(value)
		: (value instanceof String)
			? $elm$core$Result$Ok(value + '')
			: _Json_expecting('a STRING', value);
});

function _Json_decodeList(decoder) { return { $: 3, b: decoder }; }
function _Json_decodeArray(decoder) { return { $: 4, b: decoder }; }

function _Json_decodeNull(value) { return { $: 5, c: value }; }

var _Json_decodeField = F2(function(field, decoder)
{
	return {
		$: 6,
		d: field,
		b: decoder
	};
});

var _Json_decodeIndex = F2(function(index, decoder)
{
	return {
		$: 7,
		e: index,
		b: decoder
	};
});

function _Json_decodeKeyValuePairs(decoder)
{
	return {
		$: 8,
		b: decoder
	};
}

function _Json_mapMany(f, decoders)
{
	return {
		$: 9,
		f: f,
		g: decoders
	};
}

var _Json_andThen = F2(function(callback, decoder)
{
	return {
		$: 10,
		b: decoder,
		h: callback
	};
});

function _Json_oneOf(decoders)
{
	return {
		$: 11,
		g: decoders
	};
}


// DECODING OBJECTS

var _Json_map1 = F2(function(f, d1)
{
	return _Json_mapMany(f, [d1]);
});

var _Json_map2 = F3(function(f, d1, d2)
{
	return _Json_mapMany(f, [d1, d2]);
});

var _Json_map3 = F4(function(f, d1, d2, d3)
{
	return _Json_mapMany(f, [d1, d2, d3]);
});

var _Json_map4 = F5(function(f, d1, d2, d3, d4)
{
	return _Json_mapMany(f, [d1, d2, d3, d4]);
});

var _Json_map5 = F6(function(f, d1, d2, d3, d4, d5)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5]);
});

var _Json_map6 = F7(function(f, d1, d2, d3, d4, d5, d6)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5, d6]);
});

var _Json_map7 = F8(function(f, d1, d2, d3, d4, d5, d6, d7)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5, d6, d7]);
});

var _Json_map8 = F9(function(f, d1, d2, d3, d4, d5, d6, d7, d8)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5, d6, d7, d8]);
});


// DECODE

var _Json_runOnString = F2(function(decoder, string)
{
	try
	{
		var value = JSON.parse(string);
		return _Json_runHelp(decoder, value);
	}
	catch (e)
	{
		return $elm$core$Result$Err(A2($elm$json$Json$Decode$Failure, 'This is not valid JSON! ' + e.message, _Json_wrap(string)));
	}
});

var _Json_run = F2(function(decoder, value)
{
	return _Json_runHelp(decoder, _Json_unwrap(value));
});

function _Json_runHelp(decoder, value)
{
	switch (decoder.$)
	{
		case 2:
			return decoder.b(value);

		case 5:
			return (value === null)
				? $elm$core$Result$Ok(decoder.c)
				: _Json_expecting('null', value);

		case 3:
			if (!_Json_isArray(value))
			{
				return _Json_expecting('a LIST', value);
			}
			return _Json_runArrayDecoder(decoder.b, value, _List_fromArray);

		case 4:
			if (!_Json_isArray(value))
			{
				return _Json_expecting('an ARRAY', value);
			}
			return _Json_runArrayDecoder(decoder.b, value, _Json_toElmArray);

		case 6:
			var field = decoder.d;
			if (typeof value !== 'object' || value === null || !(field in value))
			{
				return _Json_expecting('an OBJECT with a field named `' + field + '`', value);
			}
			var result = _Json_runHelp(decoder.b, value[field]);
			return ($elm$core$Result$isOk(result)) ? result : $elm$core$Result$Err(A2($elm$json$Json$Decode$Field, field, result.a));

		case 7:
			var index = decoder.e;
			if (!_Json_isArray(value))
			{
				return _Json_expecting('an ARRAY', value);
			}
			if (index >= value.length)
			{
				return _Json_expecting('a LONGER array. Need index ' + index + ' but only see ' + value.length + ' entries', value);
			}
			var result = _Json_runHelp(decoder.b, value[index]);
			return ($elm$core$Result$isOk(result)) ? result : $elm$core$Result$Err(A2($elm$json$Json$Decode$Index, index, result.a));

		case 8:
			if (typeof value !== 'object' || value === null || _Json_isArray(value))
			{
				return _Json_expecting('an OBJECT', value);
			}

			var keyValuePairs = _List_Nil;
			// TODO test perf of Object.keys and switch when support is good enough
			for (var key in value)
			{
				if (value.hasOwnProperty(key))
				{
					var result = _Json_runHelp(decoder.b, value[key]);
					if (!$elm$core$Result$isOk(result))
					{
						return $elm$core$Result$Err(A2($elm$json$Json$Decode$Field, key, result.a));
					}
					keyValuePairs = _List_Cons(_Utils_Tuple2(key, result.a), keyValuePairs);
				}
			}
			return $elm$core$Result$Ok($elm$core$List$reverse(keyValuePairs));

		case 9:
			var answer = decoder.f;
			var decoders = decoder.g;
			for (var i = 0; i < decoders.length; i++)
			{
				var result = _Json_runHelp(decoders[i], value);
				if (!$elm$core$Result$isOk(result))
				{
					return result;
				}
				answer = answer(result.a);
			}
			return $elm$core$Result$Ok(answer);

		case 10:
			var result = _Json_runHelp(decoder.b, value);
			return (!$elm$core$Result$isOk(result))
				? result
				: _Json_runHelp(decoder.h(result.a), value);

		case 11:
			var errors = _List_Nil;
			for (var temp = decoder.g; temp.b; temp = temp.b) // WHILE_CONS
			{
				var result = _Json_runHelp(temp.a, value);
				if ($elm$core$Result$isOk(result))
				{
					return result;
				}
				errors = _List_Cons(result.a, errors);
			}
			return $elm$core$Result$Err($elm$json$Json$Decode$OneOf($elm$core$List$reverse(errors)));

		case 1:
			return $elm$core$Result$Err(A2($elm$json$Json$Decode$Failure, decoder.a, _Json_wrap(value)));

		case 0:
			return $elm$core$Result$Ok(decoder.a);
	}
}

function _Json_runArrayDecoder(decoder, value, toElmValue)
{
	var len = value.length;
	var array = new Array(len);
	for (var i = 0; i < len; i++)
	{
		var result = _Json_runHelp(decoder, value[i]);
		if (!$elm$core$Result$isOk(result))
		{
			return $elm$core$Result$Err(A2($elm$json$Json$Decode$Index, i, result.a));
		}
		array[i] = result.a;
	}
	return $elm$core$Result$Ok(toElmValue(array));
}

function _Json_isArray(value)
{
	return Array.isArray(value) || (typeof FileList !== 'undefined' && value instanceof FileList);
}

function _Json_toElmArray(array)
{
	return A2($elm$core$Array$initialize, array.length, function(i) { return array[i]; });
}

function _Json_expecting(type, value)
{
	return $elm$core$Result$Err(A2($elm$json$Json$Decode$Failure, 'Expecting ' + type, _Json_wrap(value)));
}


// EQUALITY

function _Json_equality(x, y)
{
	if (x === y)
	{
		return true;
	}

	if (x.$ !== y.$)
	{
		return false;
	}

	switch (x.$)
	{
		case 0:
		case 1:
			return x.a === y.a;

		case 2:
			return x.b === y.b;

		case 5:
			return x.c === y.c;

		case 3:
		case 4:
		case 8:
			return _Json_equality(x.b, y.b);

		case 6:
			return x.d === y.d && _Json_equality(x.b, y.b);

		case 7:
			return x.e === y.e && _Json_equality(x.b, y.b);

		case 9:
			return x.f === y.f && _Json_listEquality(x.g, y.g);

		case 10:
			return x.h === y.h && _Json_equality(x.b, y.b);

		case 11:
			return _Json_listEquality(x.g, y.g);
	}
}

function _Json_listEquality(aDecoders, bDecoders)
{
	var len = aDecoders.length;
	if (len !== bDecoders.length)
	{
		return false;
	}
	for (var i = 0; i < len; i++)
	{
		if (!_Json_equality(aDecoders[i], bDecoders[i]))
		{
			return false;
		}
	}
	return true;
}


// ENCODE

var _Json_encode = F2(function(indentLevel, value)
{
	return JSON.stringify(_Json_unwrap(value), null, indentLevel) + '';
});

function _Json_wrap(value) { return { $: 0, a: value }; }
function _Json_unwrap(value) { return value.a; }

function _Json_wrap_UNUSED(value) { return value; }
function _Json_unwrap_UNUSED(value) { return value; }

function _Json_emptyArray() { return []; }
function _Json_emptyObject() { return {}; }

var _Json_addField = F3(function(key, value, object)
{
	object[key] = _Json_unwrap(value);
	return object;
});

function _Json_addEntry(func)
{
	return F2(function(entry, array)
	{
		array.push(_Json_unwrap(func(entry)));
		return array;
	});
}

var _Json_encodeNull = _Json_wrap(null);



// TASKS

function _Scheduler_succeed(value)
{
	return {
		$: 0,
		a: value
	};
}

function _Scheduler_fail(error)
{
	return {
		$: 1,
		a: error
	};
}

function _Scheduler_binding(callback)
{
	return {
		$: 2,
		b: callback,
		c: null
	};
}

var _Scheduler_andThen = F2(function(callback, task)
{
	return {
		$: 3,
		b: callback,
		d: task
	};
});

var _Scheduler_onError = F2(function(callback, task)
{
	return {
		$: 4,
		b: callback,
		d: task
	};
});

function _Scheduler_receive(callback)
{
	return {
		$: 5,
		b: callback
	};
}


// PROCESSES

var _Scheduler_guid = 0;

function _Scheduler_rawSpawn(task)
{
	var proc = {
		$: 0,
		e: _Scheduler_guid++,
		f: task,
		g: null,
		h: []
	};

	_Scheduler_enqueue(proc);

	return proc;
}

function _Scheduler_spawn(task)
{
	return _Scheduler_binding(function(callback) {
		callback(_Scheduler_succeed(_Scheduler_rawSpawn(task)));
	});
}

function _Scheduler_rawSend(proc, msg)
{
	proc.h.push(msg);
	_Scheduler_enqueue(proc);
}

var _Scheduler_send = F2(function(proc, msg)
{
	return _Scheduler_binding(function(callback) {
		_Scheduler_rawSend(proc, msg);
		callback(_Scheduler_succeed(_Utils_Tuple0));
	});
});

function _Scheduler_kill(proc)
{
	return _Scheduler_binding(function(callback) {
		var task = proc.f;
		if (task.$ === 2 && task.c)
		{
			task.c();
		}

		proc.f = null;

		callback(_Scheduler_succeed(_Utils_Tuple0));
	});
}


/* STEP PROCESSES

type alias Process =
  { $ : tag
  , id : unique_id
  , root : Task
  , stack : null | { $: SUCCEED | FAIL, a: callback, b: stack }
  , mailbox : [msg]
  }

*/


var _Scheduler_working = false;
var _Scheduler_queue = [];


function _Scheduler_enqueue(proc)
{
	_Scheduler_queue.push(proc);
	if (_Scheduler_working)
	{
		return;
	}
	_Scheduler_working = true;
	while (proc = _Scheduler_queue.shift())
	{
		_Scheduler_step(proc);
	}
	_Scheduler_working = false;
}


function _Scheduler_step(proc)
{
	while (proc.f)
	{
		var rootTag = proc.f.$;
		if (rootTag === 0 || rootTag === 1)
		{
			while (proc.g && proc.g.$ !== rootTag)
			{
				proc.g = proc.g.i;
			}
			if (!proc.g)
			{
				return;
			}
			proc.f = proc.g.b(proc.f.a);
			proc.g = proc.g.i;
		}
		else if (rootTag === 2)
		{
			proc.f.c = proc.f.b(function(newRoot) {
				proc.f = newRoot;
				_Scheduler_enqueue(proc);
			});
			return;
		}
		else if (rootTag === 5)
		{
			if (proc.h.length === 0)
			{
				return;
			}
			proc.f = proc.f.b(proc.h.shift());
		}
		else // if (rootTag === 3 || rootTag === 4)
		{
			proc.g = {
				$: rootTag === 3 ? 0 : 1,
				b: proc.f.b,
				i: proc.g
			};
			proc.f = proc.f.d;
		}
	}
}



function _Process_sleep(time)
{
	return _Scheduler_binding(function(callback) {
		var id = setTimeout(function() {
			callback(_Scheduler_succeed(_Utils_Tuple0));
		}, time);

		return function() { clearTimeout(id); };
	});
}




// PROGRAMS


var _Platform_worker = F4(function(impl, flagDecoder, debugMetadata, args)
{
	return _Platform_initialize(
		flagDecoder,
		args,
		impl.init,
		impl.update,
		impl.subscriptions,
		function() { return function() {} }
	);
});



// INITIALIZE A PROGRAM


function _Platform_initialize(flagDecoder, args, init, update, subscriptions, stepperBuilder)
{
	var result = A2(_Json_run, flagDecoder, _Json_wrap(args ? args['flags'] : undefined));
	$elm$core$Result$isOk(result) || _Debug_crash(2 /**/, _Json_errorToString(result.a) /**/);
	var managers = {};
	var initPair = init(result.a);
	var model = initPair.a;
	var stepper = stepperBuilder(sendToApp, model);
	var ports = _Platform_setupEffects(managers, sendToApp);

	function sendToApp(msg, viewMetadata)
	{
		var pair = A2(update, msg, model);
		stepper(model = pair.a, viewMetadata);
		_Platform_enqueueEffects(managers, pair.b, subscriptions(model));
	}

	_Platform_enqueueEffects(managers, initPair.b, subscriptions(model));

	return ports ? { ports: ports } : {};
}



// TRACK PRELOADS
//
// This is used by code in elm/browser and elm/http
// to register any HTTP requests that are triggered by init.
//


var _Platform_preload;


function _Platform_registerPreload(url)
{
	_Platform_preload.add(url);
}



// EFFECT MANAGERS


var _Platform_effectManagers = {};


function _Platform_setupEffects(managers, sendToApp)
{
	var ports;

	// setup all necessary effect managers
	for (var key in _Platform_effectManagers)
	{
		var manager = _Platform_effectManagers[key];

		if (manager.a)
		{
			ports = ports || {};
			ports[key] = manager.a(key, sendToApp);
		}

		managers[key] = _Platform_instantiateManager(manager, sendToApp);
	}

	return ports;
}


function _Platform_createManager(init, onEffects, onSelfMsg, cmdMap, subMap)
{
	return {
		b: init,
		c: onEffects,
		d: onSelfMsg,
		e: cmdMap,
		f: subMap
	};
}


function _Platform_instantiateManager(info, sendToApp)
{
	var router = {
		g: sendToApp,
		h: undefined
	};

	var onEffects = info.c;
	var onSelfMsg = info.d;
	var cmdMap = info.e;
	var subMap = info.f;

	function loop(state)
	{
		return A2(_Scheduler_andThen, loop, _Scheduler_receive(function(msg)
		{
			var value = msg.a;

			if (msg.$ === 0)
			{
				return A3(onSelfMsg, router, value, state);
			}

			return cmdMap && subMap
				? A4(onEffects, router, value.i, value.j, state)
				: A3(onEffects, router, cmdMap ? value.i : value.j, state);
		}));
	}

	return router.h = _Scheduler_rawSpawn(A2(_Scheduler_andThen, loop, info.b));
}



// ROUTING


var _Platform_sendToApp = F2(function(router, msg)
{
	return _Scheduler_binding(function(callback)
	{
		router.g(msg);
		callback(_Scheduler_succeed(_Utils_Tuple0));
	});
});


var _Platform_sendToSelf = F2(function(router, msg)
{
	return A2(_Scheduler_send, router.h, {
		$: 0,
		a: msg
	});
});



// BAGS


function _Platform_leaf(home)
{
	return function(value)
	{
		return {
			$: 1,
			k: home,
			l: value
		};
	};
}


function _Platform_batch(list)
{
	return {
		$: 2,
		m: list
	};
}


var _Platform_map = F2(function(tagger, bag)
{
	return {
		$: 3,
		n: tagger,
		o: bag
	}
});



// PIPE BAGS INTO EFFECT MANAGERS
//
// Effects must be queued!
//
// Say your init contains a synchronous command, like Time.now or Time.here
//
//   - This will produce a batch of effects (FX_1)
//   - The synchronous task triggers the subsequent `update` call
//   - This will produce a batch of effects (FX_2)
//
// If we just start dispatching FX_2, subscriptions from FX_2 can be processed
// before subscriptions from FX_1. No good! Earlier versions of this code had
// this problem, leading to these reports:
//
//   https://github.com/elm/core/issues/980
//   https://github.com/elm/core/pull/981
//   https://github.com/elm/compiler/issues/1776
//
// The queue is necessary to avoid ordering issues for synchronous commands.


// Why use true/false here? Why not just check the length of the queue?
// The goal is to detect "are we currently dispatching effects?" If we
// are, we need to bail and let the ongoing while loop handle things.
//
// Now say the queue has 1 element. When we dequeue the final element,
// the queue will be empty, but we are still actively dispatching effects.
// So you could get queue jumping in a really tricky category of cases.
//
var _Platform_effectsQueue = [];
var _Platform_effectsActive = false;


function _Platform_enqueueEffects(managers, cmdBag, subBag)
{
	_Platform_effectsQueue.push({ p: managers, q: cmdBag, r: subBag });

	if (_Platform_effectsActive) return;

	_Platform_effectsActive = true;
	for (var fx; fx = _Platform_effectsQueue.shift(); )
	{
		_Platform_dispatchEffects(fx.p, fx.q, fx.r);
	}
	_Platform_effectsActive = false;
}


function _Platform_dispatchEffects(managers, cmdBag, subBag)
{
	var effectsDict = {};
	_Platform_gatherEffects(true, cmdBag, effectsDict, null);
	_Platform_gatherEffects(false, subBag, effectsDict, null);

	for (var home in managers)
	{
		_Scheduler_rawSend(managers[home], {
			$: 'fx',
			a: effectsDict[home] || { i: _List_Nil, j: _List_Nil }
		});
	}
}


function _Platform_gatherEffects(isCmd, bag, effectsDict, taggers)
{
	switch (bag.$)
	{
		case 1:
			var home = bag.k;
			var effect = _Platform_toEffect(isCmd, home, taggers, bag.l);
			effectsDict[home] = _Platform_insert(isCmd, effect, effectsDict[home]);
			return;

		case 2:
			for (var list = bag.m; list.b; list = list.b) // WHILE_CONS
			{
				_Platform_gatherEffects(isCmd, list.a, effectsDict, taggers);
			}
			return;

		case 3:
			_Platform_gatherEffects(isCmd, bag.o, effectsDict, {
				s: bag.n,
				t: taggers
			});
			return;
	}
}


function _Platform_toEffect(isCmd, home, taggers, value)
{
	function applyTaggers(x)
	{
		for (var temp = taggers; temp; temp = temp.t)
		{
			x = temp.s(x);
		}
		return x;
	}

	var map = isCmd
		? _Platform_effectManagers[home].e
		: _Platform_effectManagers[home].f;

	return A2(map, applyTaggers, value)
}


function _Platform_insert(isCmd, newEffect, effects)
{
	effects = effects || { i: _List_Nil, j: _List_Nil };

	isCmd
		? (effects.i = _List_Cons(newEffect, effects.i))
		: (effects.j = _List_Cons(newEffect, effects.j));

	return effects;
}



// PORTS


function _Platform_checkPortName(name)
{
	if (_Platform_effectManagers[name])
	{
		_Debug_crash(3, name)
	}
}



// OUTGOING PORTS


function _Platform_outgoingPort(name, converter)
{
	_Platform_checkPortName(name);
	_Platform_effectManagers[name] = {
		e: _Platform_outgoingPortMap,
		u: converter,
		a: _Platform_setupOutgoingPort
	};
	return _Platform_leaf(name);
}


var _Platform_outgoingPortMap = F2(function(tagger, value) { return value; });


function _Platform_setupOutgoingPort(name)
{
	var subs = [];
	var converter = _Platform_effectManagers[name].u;

	// CREATE MANAGER

	var init = _Process_sleep(0);

	_Platform_effectManagers[name].b = init;
	_Platform_effectManagers[name].c = F3(function(router, cmdList, state)
	{
		for ( ; cmdList.b; cmdList = cmdList.b) // WHILE_CONS
		{
			// grab a separate reference to subs in case unsubscribe is called
			var currentSubs = subs;
			var value = _Json_unwrap(converter(cmdList.a));
			for (var i = 0; i < currentSubs.length; i++)
			{
				currentSubs[i](value);
			}
		}
		return init;
	});

	// PUBLIC API

	function subscribe(callback)
	{
		subs.push(callback);
	}

	function unsubscribe(callback)
	{
		// copy subs into a new array in case unsubscribe is called within a
		// subscribed callback
		subs = subs.slice();
		var index = subs.indexOf(callback);
		if (index >= 0)
		{
			subs.splice(index, 1);
		}
	}

	return {
		subscribe: subscribe,
		unsubscribe: unsubscribe
	};
}



// INCOMING PORTS


function _Platform_incomingPort(name, converter)
{
	_Platform_checkPortName(name);
	_Platform_effectManagers[name] = {
		f: _Platform_incomingPortMap,
		u: converter,
		a: _Platform_setupIncomingPort
	};
	return _Platform_leaf(name);
}


var _Platform_incomingPortMap = F2(function(tagger, finalTagger)
{
	return function(value)
	{
		return tagger(finalTagger(value));
	};
});


function _Platform_setupIncomingPort(name, sendToApp)
{
	var subs = _List_Nil;
	var converter = _Platform_effectManagers[name].u;

	// CREATE MANAGER

	var init = _Scheduler_succeed(null);

	_Platform_effectManagers[name].b = init;
	_Platform_effectManagers[name].c = F3(function(router, subList, state)
	{
		subs = subList;
		return init;
	});

	// PUBLIC API

	function send(incomingValue)
	{
		var result = A2(_Json_run, converter, _Json_wrap(incomingValue));

		$elm$core$Result$isOk(result) || _Debug_crash(4, name, result.a);

		var value = result.a;
		for (var temp = subs; temp.b; temp = temp.b) // WHILE_CONS
		{
			sendToApp(temp.a(value));
		}
	}

	return { send: send };
}



// EXPORT ELM MODULES
//
// Have DEBUG and PROD versions so that we can (1) give nicer errors in
// debug mode and (2) not pay for the bits needed for that in prod mode.
//


function _Platform_export_UNUSED(exports)
{
	scope['Elm']
		? _Platform_mergeExportsProd(scope['Elm'], exports)
		: scope['Elm'] = exports;
}


function _Platform_mergeExportsProd(obj, exports)
{
	for (var name in exports)
	{
		(name in obj)
			? (name == 'init')
				? _Debug_crash(6)
				: _Platform_mergeExportsProd(obj[name], exports[name])
			: (obj[name] = exports[name]);
	}
}


function _Platform_export(exports)
{
	scope['Elm']
		? _Platform_mergeExportsDebug('Elm', scope['Elm'], exports)
		: scope['Elm'] = exports;
}


function _Platform_mergeExportsDebug(moduleName, obj, exports)
{
	for (var name in exports)
	{
		(name in obj)
			? (name == 'init')
				? _Debug_crash(6, moduleName)
				: _Platform_mergeExportsDebug(moduleName + '.' + name, obj[name], exports[name])
			: (obj[name] = exports[name]);
	}
}




// HELPERS


var _VirtualDom_divertHrefToApp;

var _VirtualDom_doc = typeof document !== 'undefined' ? document : {};


function _VirtualDom_appendChild(parent, child)
{
	parent.appendChild(child);
}

var _VirtualDom_init = F4(function(virtualNode, flagDecoder, debugMetadata, args)
{
	// NOTE: this function needs _Platform_export available to work

	/**_UNUSED/
	var node = args['node'];
	//*/
	/**/
	var node = args && args['node'] ? args['node'] : _Debug_crash(0);
	//*/

	node.parentNode.replaceChild(
		_VirtualDom_render(virtualNode, function() {}),
		node
	);

	return {};
});



// TEXT


function _VirtualDom_text(string)
{
	return {
		$: 0,
		a: string
	};
}



// NODE


var _VirtualDom_nodeNS = F2(function(namespace, tag)
{
	return F2(function(factList, kidList)
	{
		for (var kids = [], descendantsCount = 0; kidList.b; kidList = kidList.b) // WHILE_CONS
		{
			var kid = kidList.a;
			descendantsCount += (kid.b || 0);
			kids.push(kid);
		}
		descendantsCount += kids.length;

		return {
			$: 1,
			c: tag,
			d: _VirtualDom_organizeFacts(factList),
			e: kids,
			f: namespace,
			b: descendantsCount
		};
	});
});


var _VirtualDom_node = _VirtualDom_nodeNS(undefined);



// KEYED NODE


var _VirtualDom_keyedNodeNS = F2(function(namespace, tag)
{
	return F2(function(factList, kidList)
	{
		for (var kids = [], descendantsCount = 0; kidList.b; kidList = kidList.b) // WHILE_CONS
		{
			var kid = kidList.a;
			descendantsCount += (kid.b.b || 0);
			kids.push(kid);
		}
		descendantsCount += kids.length;

		return {
			$: 2,
			c: tag,
			d: _VirtualDom_organizeFacts(factList),
			e: kids,
			f: namespace,
			b: descendantsCount
		};
	});
});


var _VirtualDom_keyedNode = _VirtualDom_keyedNodeNS(undefined);



// CUSTOM


function _VirtualDom_custom(factList, model, render, diff)
{
	return {
		$: 3,
		d: _VirtualDom_organizeFacts(factList),
		g: model,
		h: render,
		i: diff
	};
}



// MAP


var _VirtualDom_map = F2(function(tagger, node)
{
	return {
		$: 4,
		j: tagger,
		k: node,
		b: 1 + (node.b || 0)
	};
});



// LAZY


function _VirtualDom_thunk(refs, thunk)
{
	return {
		$: 5,
		l: refs,
		m: thunk,
		k: undefined
	};
}

var _VirtualDom_lazy = F2(function(func, a)
{
	return _VirtualDom_thunk([func, a], function() {
		return func(a);
	});
});

var _VirtualDom_lazy2 = F3(function(func, a, b)
{
	return _VirtualDom_thunk([func, a, b], function() {
		return A2(func, a, b);
	});
});

var _VirtualDom_lazy3 = F4(function(func, a, b, c)
{
	return _VirtualDom_thunk([func, a, b, c], function() {
		return A3(func, a, b, c);
	});
});

var _VirtualDom_lazy4 = F5(function(func, a, b, c, d)
{
	return _VirtualDom_thunk([func, a, b, c, d], function() {
		return A4(func, a, b, c, d);
	});
});

var _VirtualDom_lazy5 = F6(function(func, a, b, c, d, e)
{
	return _VirtualDom_thunk([func, a, b, c, d, e], function() {
		return A5(func, a, b, c, d, e);
	});
});

var _VirtualDom_lazy6 = F7(function(func, a, b, c, d, e, f)
{
	return _VirtualDom_thunk([func, a, b, c, d, e, f], function() {
		return A6(func, a, b, c, d, e, f);
	});
});

var _VirtualDom_lazy7 = F8(function(func, a, b, c, d, e, f, g)
{
	return _VirtualDom_thunk([func, a, b, c, d, e, f, g], function() {
		return A7(func, a, b, c, d, e, f, g);
	});
});

var _VirtualDom_lazy8 = F9(function(func, a, b, c, d, e, f, g, h)
{
	return _VirtualDom_thunk([func, a, b, c, d, e, f, g, h], function() {
		return A8(func, a, b, c, d, e, f, g, h);
	});
});



// FACTS


var _VirtualDom_on = F2(function(key, handler)
{
	return {
		$: 'a0',
		n: key,
		o: handler
	};
});
var _VirtualDom_style = F2(function(key, value)
{
	return {
		$: 'a1',
		n: key,
		o: value
	};
});
var _VirtualDom_property = F2(function(key, value)
{
	return {
		$: 'a2',
		n: key,
		o: value
	};
});
var _VirtualDom_attribute = F2(function(key, value)
{
	return {
		$: 'a3',
		n: key,
		o: value
	};
});
var _VirtualDom_attributeNS = F3(function(namespace, key, value)
{
	return {
		$: 'a4',
		n: key,
		o: { f: namespace, o: value }
	};
});



// XSS ATTACK VECTOR CHECKS
//
// For some reason, tabs can appear in href protocols and it still works.
// So '\tjava\tSCRIPT:alert("!!!")' and 'javascript:alert("!!!")' are the same
// in practice. That is why _VirtualDom_RE_js and _VirtualDom_RE_js_html look
// so freaky.
//
// Pulling the regular expressions out to the top level gives a slight speed
// boost in small benchmarks (4-10%) but hoisting values to reduce allocation
// can be unpredictable in large programs where JIT may have a harder time with
// functions are not fully self-contained. The benefit is more that the js and
// js_html ones are so weird that I prefer to see them near each other.


var _VirtualDom_RE_script = /^script$/i;
var _VirtualDom_RE_on_formAction = /^(on|formAction$)/i;
var _VirtualDom_RE_js = /^\s*j\s*a\s*v\s*a\s*s\s*c\s*r\s*i\s*p\s*t\s*:/i;
var _VirtualDom_RE_js_html = /^\s*(j\s*a\s*v\s*a\s*s\s*c\s*r\s*i\s*p\s*t\s*:|d\s*a\s*t\s*a\s*:\s*t\s*e\s*x\s*t\s*\/\s*h\s*t\s*m\s*l\s*(,|;))/i;


function _VirtualDom_noScript(tag)
{
	return _VirtualDom_RE_script.test(tag) ? 'p' : tag;
}

function _VirtualDom_noOnOrFormAction(key)
{
	return _VirtualDom_RE_on_formAction.test(key) ? 'data-' + key : key;
}

function _VirtualDom_noInnerHtmlOrFormAction(key)
{
	return key == 'innerHTML' || key == 'formAction' ? 'data-' + key : key;
}

function _VirtualDom_noJavaScriptUri(value)
{
	return _VirtualDom_RE_js.test(value)
		? /**_UNUSED/''//*//**/'javascript:alert("This is an XSS vector. Please use ports or web components instead.")'//*/
		: value;
}

function _VirtualDom_noJavaScriptOrHtmlUri(value)
{
	return _VirtualDom_RE_js_html.test(value)
		? /**_UNUSED/''//*//**/'javascript:alert("This is an XSS vector. Please use ports or web components instead.")'//*/
		: value;
}

function _VirtualDom_noJavaScriptOrHtmlJson(value)
{
	return (typeof _Json_unwrap(value) === 'string' && _VirtualDom_RE_js_html.test(_Json_unwrap(value)))
		? _Json_wrap(
			/**_UNUSED/''//*//**/'javascript:alert("This is an XSS vector. Please use ports or web components instead.")'//*/
		) : value;
}



// MAP FACTS


var _VirtualDom_mapAttribute = F2(function(func, attr)
{
	return (attr.$ === 'a0')
		? A2(_VirtualDom_on, attr.n, _VirtualDom_mapHandler(func, attr.o))
		: attr;
});

function _VirtualDom_mapHandler(func, handler)
{
	var tag = $elm$virtual_dom$VirtualDom$toHandlerInt(handler);

	// 0 = Normal
	// 1 = MayStopPropagation
	// 2 = MayPreventDefault
	// 3 = Custom

	return {
		$: handler.$,
		a:
			!tag
				? A2($elm$json$Json$Decode$map, func, handler.a)
				:
			A3($elm$json$Json$Decode$map2,
				tag < 3
					? _VirtualDom_mapEventTuple
					: _VirtualDom_mapEventRecord,
				$elm$json$Json$Decode$succeed(func),
				handler.a
			)
	};
}

var _VirtualDom_mapEventTuple = F2(function(func, tuple)
{
	return _Utils_Tuple2(func(tuple.a), tuple.b);
});

var _VirtualDom_mapEventRecord = F2(function(func, record)
{
	return {
		message: func(record.message),
		stopPropagation: record.stopPropagation,
		preventDefault: record.preventDefault
	}
});



// ORGANIZE FACTS


function _VirtualDom_organizeFacts(factList)
{
	for (var facts = {}; factList.b; factList = factList.b) // WHILE_CONS
	{
		var entry = factList.a;

		var tag = entry.$;
		var key = entry.n;
		var value = entry.o;

		if (tag === 'a2')
		{
			(key === 'className')
				? _VirtualDom_addClass(facts, key, _Json_unwrap(value))
				: facts[key] = _Json_unwrap(value);

			continue;
		}

		var subFacts = facts[tag] || (facts[tag] = {});
		(tag === 'a3' && key === 'class')
			? _VirtualDom_addClass(subFacts, key, value)
			: subFacts[key] = value;
	}

	return facts;
}

function _VirtualDom_addClass(object, key, newClass)
{
	var classes = object[key];
	object[key] = classes ? classes + ' ' + newClass : newClass;
}



// RENDER


function _VirtualDom_render(vNode, eventNode)
{
	var tag = vNode.$;

	if (tag === 5)
	{
		return _VirtualDom_render(vNode.k || (vNode.k = vNode.m()), eventNode);
	}

	if (tag === 0)
	{
		return _VirtualDom_doc.createTextNode(vNode.a);
	}

	if (tag === 4)
	{
		var subNode = vNode.k;
		var tagger = vNode.j;

		while (subNode.$ === 4)
		{
			typeof tagger !== 'object'
				? tagger = [tagger, subNode.j]
				: tagger.push(subNode.j);

			subNode = subNode.k;
		}

		var subEventRoot = { j: tagger, p: eventNode };
		var domNode = _VirtualDom_render(subNode, subEventRoot);
		domNode.elm_event_node_ref = subEventRoot;
		return domNode;
	}

	if (tag === 3)
	{
		var domNode = vNode.h(vNode.g);
		_VirtualDom_applyFacts(domNode, eventNode, vNode.d);
		return domNode;
	}

	// at this point `tag` must be 1 or 2

	var domNode = vNode.f
		? _VirtualDom_doc.createElementNS(vNode.f, vNode.c)
		: _VirtualDom_doc.createElement(vNode.c);

	if (_VirtualDom_divertHrefToApp && vNode.c == 'a')
	{
		domNode.addEventListener('click', _VirtualDom_divertHrefToApp(domNode));
	}

	_VirtualDom_applyFacts(domNode, eventNode, vNode.d);

	for (var kids = vNode.e, i = 0; i < kids.length; i++)
	{
		_VirtualDom_appendChild(domNode, _VirtualDom_render(tag === 1 ? kids[i] : kids[i].b, eventNode));
	}

	return domNode;
}



// APPLY FACTS


function _VirtualDom_applyFacts(domNode, eventNode, facts)
{
	for (var key in facts)
	{
		var value = facts[key];

		key === 'a1'
			? _VirtualDom_applyStyles(domNode, value)
			:
		key === 'a0'
			? _VirtualDom_applyEvents(domNode, eventNode, value)
			:
		key === 'a3'
			? _VirtualDom_applyAttrs(domNode, value)
			:
		key === 'a4'
			? _VirtualDom_applyAttrsNS(domNode, value)
			:
		((key !== 'value' && key !== 'checked') || domNode[key] !== value) && (domNode[key] = value);
	}
}



// APPLY STYLES


function _VirtualDom_applyStyles(domNode, styles)
{
	var domNodeStyle = domNode.style;

	for (var key in styles)
	{
		domNodeStyle[key] = styles[key];
	}
}



// APPLY ATTRS


function _VirtualDom_applyAttrs(domNode, attrs)
{
	for (var key in attrs)
	{
		var value = attrs[key];
		typeof value !== 'undefined'
			? domNode.setAttribute(key, value)
			: domNode.removeAttribute(key);
	}
}



// APPLY NAMESPACED ATTRS


function _VirtualDom_applyAttrsNS(domNode, nsAttrs)
{
	for (var key in nsAttrs)
	{
		var pair = nsAttrs[key];
		var namespace = pair.f;
		var value = pair.o;

		typeof value !== 'undefined'
			? domNode.setAttributeNS(namespace, key, value)
			: domNode.removeAttributeNS(namespace, key);
	}
}



// APPLY EVENTS


function _VirtualDom_applyEvents(domNode, eventNode, events)
{
	var allCallbacks = domNode.elmFs || (domNode.elmFs = {});

	for (var key in events)
	{
		var newHandler = events[key];
		var oldCallback = allCallbacks[key];

		if (!newHandler)
		{
			domNode.removeEventListener(key, oldCallback);
			allCallbacks[key] = undefined;
			continue;
		}

		if (oldCallback)
		{
			var oldHandler = oldCallback.q;
			if (oldHandler.$ === newHandler.$)
			{
				oldCallback.q = newHandler;
				continue;
			}
			domNode.removeEventListener(key, oldCallback);
		}

		oldCallback = _VirtualDom_makeCallback(eventNode, newHandler);
		domNode.addEventListener(key, oldCallback,
			_VirtualDom_passiveSupported
			&& { passive: $elm$virtual_dom$VirtualDom$toHandlerInt(newHandler) < 2 }
		);
		allCallbacks[key] = oldCallback;
	}
}



// PASSIVE EVENTS


var _VirtualDom_passiveSupported;

try
{
	window.addEventListener('t', null, Object.defineProperty({}, 'passive', {
		get: function() { _VirtualDom_passiveSupported = true; }
	}));
}
catch(e) {}



// EVENT HANDLERS


function _VirtualDom_makeCallback(eventNode, initialHandler)
{
	function callback(event)
	{
		var handler = callback.q;
		var result = _Json_runHelp(handler.a, event);

		if (!$elm$core$Result$isOk(result))
		{
			return;
		}

		var tag = $elm$virtual_dom$VirtualDom$toHandlerInt(handler);

		// 0 = Normal
		// 1 = MayStopPropagation
		// 2 = MayPreventDefault
		// 3 = Custom

		var value = result.a;
		var message = !tag ? value : tag < 3 ? value.a : value.message;
		var stopPropagation = tag == 1 ? value.b : tag == 3 && value.stopPropagation;
		var currentEventNode = (
			stopPropagation && event.stopPropagation(),
			(tag == 2 ? value.b : tag == 3 && value.preventDefault) && event.preventDefault(),
			eventNode
		);
		var tagger;
		var i;
		while (tagger = currentEventNode.j)
		{
			if (typeof tagger == 'function')
			{
				message = tagger(message);
			}
			else
			{
				for (var i = tagger.length; i--; )
				{
					message = tagger[i](message);
				}
			}
			currentEventNode = currentEventNode.p;
		}
		currentEventNode(message, stopPropagation); // stopPropagation implies isSync
	}

	callback.q = initialHandler;

	return callback;
}

function _VirtualDom_equalEvents(x, y)
{
	return x.$ == y.$ && _Json_equality(x.a, y.a);
}



// DIFF


// TODO: Should we do patches like in iOS?
//
// type Patch
//   = At Int Patch
//   | Batch (List Patch)
//   | Change ...
//
// How could it not be better?
//
function _VirtualDom_diff(x, y)
{
	var patches = [];
	_VirtualDom_diffHelp(x, y, patches, 0);
	return patches;
}


function _VirtualDom_pushPatch(patches, type, index, data)
{
	var patch = {
		$: type,
		r: index,
		s: data,
		t: undefined,
		u: undefined
	};
	patches.push(patch);
	return patch;
}


function _VirtualDom_diffHelp(x, y, patches, index)
{
	if (x === y)
	{
		return;
	}

	var xType = x.$;
	var yType = y.$;

	// Bail if you run into different types of nodes. Implies that the
	// structure has changed significantly and it's not worth a diff.
	if (xType !== yType)
	{
		if (xType === 1 && yType === 2)
		{
			y = _VirtualDom_dekey(y);
			yType = 1;
		}
		else
		{
			_VirtualDom_pushPatch(patches, 0, index, y);
			return;
		}
	}

	// Now we know that both nodes are the same $.
	switch (yType)
	{
		case 5:
			var xRefs = x.l;
			var yRefs = y.l;
			var i = xRefs.length;
			var same = i === yRefs.length;
			while (same && i--)
			{
				same = xRefs[i] === yRefs[i];
			}
			if (same)
			{
				y.k = x.k;
				return;
			}
			y.k = y.m();
			var subPatches = [];
			_VirtualDom_diffHelp(x.k, y.k, subPatches, 0);
			subPatches.length > 0 && _VirtualDom_pushPatch(patches, 1, index, subPatches);
			return;

		case 4:
			// gather nested taggers
			var xTaggers = x.j;
			var yTaggers = y.j;
			var nesting = false;

			var xSubNode = x.k;
			while (xSubNode.$ === 4)
			{
				nesting = true;

				typeof xTaggers !== 'object'
					? xTaggers = [xTaggers, xSubNode.j]
					: xTaggers.push(xSubNode.j);

				xSubNode = xSubNode.k;
			}

			var ySubNode = y.k;
			while (ySubNode.$ === 4)
			{
				nesting = true;

				typeof yTaggers !== 'object'
					? yTaggers = [yTaggers, ySubNode.j]
					: yTaggers.push(ySubNode.j);

				ySubNode = ySubNode.k;
			}

			// Just bail if different numbers of taggers. This implies the
			// structure of the virtual DOM has changed.
			if (nesting && xTaggers.length !== yTaggers.length)
			{
				_VirtualDom_pushPatch(patches, 0, index, y);
				return;
			}

			// check if taggers are "the same"
			if (nesting ? !_VirtualDom_pairwiseRefEqual(xTaggers, yTaggers) : xTaggers !== yTaggers)
			{
				_VirtualDom_pushPatch(patches, 2, index, yTaggers);
			}

			// diff everything below the taggers
			_VirtualDom_diffHelp(xSubNode, ySubNode, patches, index + 1);
			return;

		case 0:
			if (x.a !== y.a)
			{
				_VirtualDom_pushPatch(patches, 3, index, y.a);
			}
			return;

		case 1:
			_VirtualDom_diffNodes(x, y, patches, index, _VirtualDom_diffKids);
			return;

		case 2:
			_VirtualDom_diffNodes(x, y, patches, index, _VirtualDom_diffKeyedKids);
			return;

		case 3:
			if (x.h !== y.h)
			{
				_VirtualDom_pushPatch(patches, 0, index, y);
				return;
			}

			var factsDiff = _VirtualDom_diffFacts(x.d, y.d);
			factsDiff && _VirtualDom_pushPatch(patches, 4, index, factsDiff);

			var patch = y.i(x.g, y.g);
			patch && _VirtualDom_pushPatch(patches, 5, index, patch);

			return;
	}
}

// assumes the incoming arrays are the same length
function _VirtualDom_pairwiseRefEqual(as, bs)
{
	for (var i = 0; i < as.length; i++)
	{
		if (as[i] !== bs[i])
		{
			return false;
		}
	}

	return true;
}

function _VirtualDom_diffNodes(x, y, patches, index, diffKids)
{
	// Bail if obvious indicators have changed. Implies more serious
	// structural changes such that it's not worth it to diff.
	if (x.c !== y.c || x.f !== y.f)
	{
		_VirtualDom_pushPatch(patches, 0, index, y);
		return;
	}

	var factsDiff = _VirtualDom_diffFacts(x.d, y.d);
	factsDiff && _VirtualDom_pushPatch(patches, 4, index, factsDiff);

	diffKids(x, y, patches, index);
}



// DIFF FACTS


// TODO Instead of creating a new diff object, it's possible to just test if
// there *is* a diff. During the actual patch, do the diff again and make the
// modifications directly. This way, there's no new allocations. Worth it?
function _VirtualDom_diffFacts(x, y, category)
{
	var diff;

	// look for changes and removals
	for (var xKey in x)
	{
		if (xKey === 'a1' || xKey === 'a0' || xKey === 'a3' || xKey === 'a4')
		{
			var subDiff = _VirtualDom_diffFacts(x[xKey], y[xKey] || {}, xKey);
			if (subDiff)
			{
				diff = diff || {};
				diff[xKey] = subDiff;
			}
			continue;
		}

		// remove if not in the new facts
		if (!(xKey in y))
		{
			diff = diff || {};
			diff[xKey] =
				!category
					? (typeof x[xKey] === 'string' ? '' : null)
					:
				(category === 'a1')
					? ''
					:
				(category === 'a0' || category === 'a3')
					? undefined
					:
				{ f: x[xKey].f, o: undefined };

			continue;
		}

		var xValue = x[xKey];
		var yValue = y[xKey];

		// reference equal, so don't worry about it
		if (xValue === yValue && xKey !== 'value' && xKey !== 'checked'
			|| category === 'a0' && _VirtualDom_equalEvents(xValue, yValue))
		{
			continue;
		}

		diff = diff || {};
		diff[xKey] = yValue;
	}

	// add new stuff
	for (var yKey in y)
	{
		if (!(yKey in x))
		{
			diff = diff || {};
			diff[yKey] = y[yKey];
		}
	}

	return diff;
}



// DIFF KIDS


function _VirtualDom_diffKids(xParent, yParent, patches, index)
{
	var xKids = xParent.e;
	var yKids = yParent.e;

	var xLen = xKids.length;
	var yLen = yKids.length;

	// FIGURE OUT IF THERE ARE INSERTS OR REMOVALS

	if (xLen > yLen)
	{
		_VirtualDom_pushPatch(patches, 6, index, {
			v: yLen,
			i: xLen - yLen
		});
	}
	else if (xLen < yLen)
	{
		_VirtualDom_pushPatch(patches, 7, index, {
			v: xLen,
			e: yKids
		});
	}

	// PAIRWISE DIFF EVERYTHING ELSE

	for (var minLen = xLen < yLen ? xLen : yLen, i = 0; i < minLen; i++)
	{
		var xKid = xKids[i];
		_VirtualDom_diffHelp(xKid, yKids[i], patches, ++index);
		index += xKid.b || 0;
	}
}



// KEYED DIFF


function _VirtualDom_diffKeyedKids(xParent, yParent, patches, rootIndex)
{
	var localPatches = [];

	var changes = {}; // Dict String Entry
	var inserts = []; // Array { index : Int, entry : Entry }
	// type Entry = { tag : String, vnode : VNode, index : Int, data : _ }

	var xKids = xParent.e;
	var yKids = yParent.e;
	var xLen = xKids.length;
	var yLen = yKids.length;
	var xIndex = 0;
	var yIndex = 0;

	var index = rootIndex;

	while (xIndex < xLen && yIndex < yLen)
	{
		var x = xKids[xIndex];
		var y = yKids[yIndex];

		var xKey = x.a;
		var yKey = y.a;
		var xNode = x.b;
		var yNode = y.b;

		var newMatch = undefined;
		var oldMatch = undefined;

		// check if keys match

		if (xKey === yKey)
		{
			index++;
			_VirtualDom_diffHelp(xNode, yNode, localPatches, index);
			index += xNode.b || 0;

			xIndex++;
			yIndex++;
			continue;
		}

		// look ahead 1 to detect insertions and removals.

		var xNext = xKids[xIndex + 1];
		var yNext = yKids[yIndex + 1];

		if (xNext)
		{
			var xNextKey = xNext.a;
			var xNextNode = xNext.b;
			oldMatch = yKey === xNextKey;
		}

		if (yNext)
		{
			var yNextKey = yNext.a;
			var yNextNode = yNext.b;
			newMatch = xKey === yNextKey;
		}


		// swap x and y
		if (newMatch && oldMatch)
		{
			index++;
			_VirtualDom_diffHelp(xNode, yNextNode, localPatches, index);
			_VirtualDom_insertNode(changes, localPatches, xKey, yNode, yIndex, inserts);
			index += xNode.b || 0;

			index++;
			_VirtualDom_removeNode(changes, localPatches, xKey, xNextNode, index);
			index += xNextNode.b || 0;

			xIndex += 2;
			yIndex += 2;
			continue;
		}

		// insert y
		if (newMatch)
		{
			index++;
			_VirtualDom_insertNode(changes, localPatches, yKey, yNode, yIndex, inserts);
			_VirtualDom_diffHelp(xNode, yNextNode, localPatches, index);
			index += xNode.b || 0;

			xIndex += 1;
			yIndex += 2;
			continue;
		}

		// remove x
		if (oldMatch)
		{
			index++;
			_VirtualDom_removeNode(changes, localPatches, xKey, xNode, index);
			index += xNode.b || 0;

			index++;
			_VirtualDom_diffHelp(xNextNode, yNode, localPatches, index);
			index += xNextNode.b || 0;

			xIndex += 2;
			yIndex += 1;
			continue;
		}

		// remove x, insert y
		if (xNext && xNextKey === yNextKey)
		{
			index++;
			_VirtualDom_removeNode(changes, localPatches, xKey, xNode, index);
			_VirtualDom_insertNode(changes, localPatches, yKey, yNode, yIndex, inserts);
			index += xNode.b || 0;

			index++;
			_VirtualDom_diffHelp(xNextNode, yNextNode, localPatches, index);
			index += xNextNode.b || 0;

			xIndex += 2;
			yIndex += 2;
			continue;
		}

		break;
	}

	// eat up any remaining nodes with removeNode and insertNode

	while (xIndex < xLen)
	{
		index++;
		var x = xKids[xIndex];
		var xNode = x.b;
		_VirtualDom_removeNode(changes, localPatches, x.a, xNode, index);
		index += xNode.b || 0;
		xIndex++;
	}

	while (yIndex < yLen)
	{
		var endInserts = endInserts || [];
		var y = yKids[yIndex];
		_VirtualDom_insertNode(changes, localPatches, y.a, y.b, undefined, endInserts);
		yIndex++;
	}

	if (localPatches.length > 0 || inserts.length > 0 || endInserts)
	{
		_VirtualDom_pushPatch(patches, 8, rootIndex, {
			w: localPatches,
			x: inserts,
			y: endInserts
		});
	}
}



// CHANGES FROM KEYED DIFF


var _VirtualDom_POSTFIX = '_elmW6BL';


function _VirtualDom_insertNode(changes, localPatches, key, vnode, yIndex, inserts)
{
	var entry = changes[key];

	// never seen this key before
	if (!entry)
	{
		entry = {
			c: 0,
			z: vnode,
			r: yIndex,
			s: undefined
		};

		inserts.push({ r: yIndex, A: entry });
		changes[key] = entry;

		return;
	}

	// this key was removed earlier, a match!
	if (entry.c === 1)
	{
		inserts.push({ r: yIndex, A: entry });

		entry.c = 2;
		var subPatches = [];
		_VirtualDom_diffHelp(entry.z, vnode, subPatches, entry.r);
		entry.r = yIndex;
		entry.s.s = {
			w: subPatches,
			A: entry
		};

		return;
	}

	// this key has already been inserted or moved, a duplicate!
	_VirtualDom_insertNode(changes, localPatches, key + _VirtualDom_POSTFIX, vnode, yIndex, inserts);
}


function _VirtualDom_removeNode(changes, localPatches, key, vnode, index)
{
	var entry = changes[key];

	// never seen this key before
	if (!entry)
	{
		var patch = _VirtualDom_pushPatch(localPatches, 9, index, undefined);

		changes[key] = {
			c: 1,
			z: vnode,
			r: index,
			s: patch
		};

		return;
	}

	// this key was inserted earlier, a match!
	if (entry.c === 0)
	{
		entry.c = 2;
		var subPatches = [];
		_VirtualDom_diffHelp(vnode, entry.z, subPatches, index);

		_VirtualDom_pushPatch(localPatches, 9, index, {
			w: subPatches,
			A: entry
		});

		return;
	}

	// this key has already been removed or moved, a duplicate!
	_VirtualDom_removeNode(changes, localPatches, key + _VirtualDom_POSTFIX, vnode, index);
}



// ADD DOM NODES
//
// Each DOM node has an "index" assigned in order of traversal. It is important
// to minimize our crawl over the actual DOM, so these indexes (along with the
// descendantsCount of virtual nodes) let us skip touching entire subtrees of
// the DOM if we know there are no patches there.


function _VirtualDom_addDomNodes(domNode, vNode, patches, eventNode)
{
	_VirtualDom_addDomNodesHelp(domNode, vNode, patches, 0, 0, vNode.b, eventNode);
}


// assumes `patches` is non-empty and indexes increase monotonically.
function _VirtualDom_addDomNodesHelp(domNode, vNode, patches, i, low, high, eventNode)
{
	var patch = patches[i];
	var index = patch.r;

	while (index === low)
	{
		var patchType = patch.$;

		if (patchType === 1)
		{
			_VirtualDom_addDomNodes(domNode, vNode.k, patch.s, eventNode);
		}
		else if (patchType === 8)
		{
			patch.t = domNode;
			patch.u = eventNode;

			var subPatches = patch.s.w;
			if (subPatches.length > 0)
			{
				_VirtualDom_addDomNodesHelp(domNode, vNode, subPatches, 0, low, high, eventNode);
			}
		}
		else if (patchType === 9)
		{
			patch.t = domNode;
			patch.u = eventNode;

			var data = patch.s;
			if (data)
			{
				data.A.s = domNode;
				var subPatches = data.w;
				if (subPatches.length > 0)
				{
					_VirtualDom_addDomNodesHelp(domNode, vNode, subPatches, 0, low, high, eventNode);
				}
			}
		}
		else
		{
			patch.t = domNode;
			patch.u = eventNode;
		}

		i++;

		if (!(patch = patches[i]) || (index = patch.r) > high)
		{
			return i;
		}
	}

	var tag = vNode.$;

	if (tag === 4)
	{
		var subNode = vNode.k;

		while (subNode.$ === 4)
		{
			subNode = subNode.k;
		}

		return _VirtualDom_addDomNodesHelp(domNode, subNode, patches, i, low + 1, high, domNode.elm_event_node_ref);
	}

	// tag must be 1 or 2 at this point

	var vKids = vNode.e;
	var childNodes = domNode.childNodes;
	for (var j = 0; j < vKids.length; j++)
	{
		low++;
		var vKid = tag === 1 ? vKids[j] : vKids[j].b;
		var nextLow = low + (vKid.b || 0);
		if (low <= index && index <= nextLow)
		{
			i = _VirtualDom_addDomNodesHelp(childNodes[j], vKid, patches, i, low, nextLow, eventNode);
			if (!(patch = patches[i]) || (index = patch.r) > high)
			{
				return i;
			}
		}
		low = nextLow;
	}
	return i;
}



// APPLY PATCHES


function _VirtualDom_applyPatches(rootDomNode, oldVirtualNode, patches, eventNode)
{
	if (patches.length === 0)
	{
		return rootDomNode;
	}

	_VirtualDom_addDomNodes(rootDomNode, oldVirtualNode, patches, eventNode);
	return _VirtualDom_applyPatchesHelp(rootDomNode, patches);
}

function _VirtualDom_applyPatchesHelp(rootDomNode, patches)
{
	for (var i = 0; i < patches.length; i++)
	{
		var patch = patches[i];
		var localDomNode = patch.t
		var newNode = _VirtualDom_applyPatch(localDomNode, patch);
		if (localDomNode === rootDomNode)
		{
			rootDomNode = newNode;
		}
	}
	return rootDomNode;
}

function _VirtualDom_applyPatch(domNode, patch)
{
	switch (patch.$)
	{
		case 0:
			return _VirtualDom_applyPatchRedraw(domNode, patch.s, patch.u);

		case 4:
			_VirtualDom_applyFacts(domNode, patch.u, patch.s);
			return domNode;

		case 3:
			domNode.replaceData(0, domNode.length, patch.s);
			return domNode;

		case 1:
			return _VirtualDom_applyPatchesHelp(domNode, patch.s);

		case 2:
			if (domNode.elm_event_node_ref)
			{
				domNode.elm_event_node_ref.j = patch.s;
			}
			else
			{
				domNode.elm_event_node_ref = { j: patch.s, p: patch.u };
			}
			return domNode;

		case 6:
			var data = patch.s;
			for (var i = 0; i < data.i; i++)
			{
				domNode.removeChild(domNode.childNodes[data.v]);
			}
			return domNode;

		case 7:
			var data = patch.s;
			var kids = data.e;
			var i = data.v;
			var theEnd = domNode.childNodes[i];
			for (; i < kids.length; i++)
			{
				domNode.insertBefore(_VirtualDom_render(kids[i], patch.u), theEnd);
			}
			return domNode;

		case 9:
			var data = patch.s;
			if (!data)
			{
				domNode.parentNode.removeChild(domNode);
				return domNode;
			}
			var entry = data.A;
			if (typeof entry.r !== 'undefined')
			{
				domNode.parentNode.removeChild(domNode);
			}
			entry.s = _VirtualDom_applyPatchesHelp(domNode, data.w);
			return domNode;

		case 8:
			return _VirtualDom_applyPatchReorder(domNode, patch);

		case 5:
			return patch.s(domNode);

		default:
			_Debug_crash(10); // 'Ran into an unknown patch!'
	}
}


function _VirtualDom_applyPatchRedraw(domNode, vNode, eventNode)
{
	var parentNode = domNode.parentNode;
	var newNode = _VirtualDom_render(vNode, eventNode);

	if (!newNode.elm_event_node_ref)
	{
		newNode.elm_event_node_ref = domNode.elm_event_node_ref;
	}

	if (parentNode && newNode !== domNode)
	{
		parentNode.replaceChild(newNode, domNode);
	}
	return newNode;
}


function _VirtualDom_applyPatchReorder(domNode, patch)
{
	var data = patch.s;

	// remove end inserts
	var frag = _VirtualDom_applyPatchReorderEndInsertsHelp(data.y, patch);

	// removals
	domNode = _VirtualDom_applyPatchesHelp(domNode, data.w);

	// inserts
	var inserts = data.x;
	for (var i = 0; i < inserts.length; i++)
	{
		var insert = inserts[i];
		var entry = insert.A;
		var node = entry.c === 2
			? entry.s
			: _VirtualDom_render(entry.z, patch.u);
		domNode.insertBefore(node, domNode.childNodes[insert.r]);
	}

	// add end inserts
	if (frag)
	{
		_VirtualDom_appendChild(domNode, frag);
	}

	return domNode;
}


function _VirtualDom_applyPatchReorderEndInsertsHelp(endInserts, patch)
{
	if (!endInserts)
	{
		return;
	}

	var frag = _VirtualDom_doc.createDocumentFragment();
	for (var i = 0; i < endInserts.length; i++)
	{
		var insert = endInserts[i];
		var entry = insert.A;
		_VirtualDom_appendChild(frag, entry.c === 2
			? entry.s
			: _VirtualDom_render(entry.z, patch.u)
		);
	}
	return frag;
}


function _VirtualDom_virtualize(node)
{
	// TEXT NODES

	if (node.nodeType === 3)
	{
		return _VirtualDom_text(node.textContent);
	}


	// WEIRD NODES

	if (node.nodeType !== 1)
	{
		return _VirtualDom_text('');
	}


	// ELEMENT NODES

	var attrList = _List_Nil;
	var attrs = node.attributes;
	for (var i = attrs.length; i--; )
	{
		var attr = attrs[i];
		var name = attr.name;
		var value = attr.value;
		attrList = _List_Cons( A2(_VirtualDom_attribute, name, value), attrList );
	}

	var tag = node.tagName.toLowerCase();
	var kidList = _List_Nil;
	var kids = node.childNodes;

	for (var i = kids.length; i--; )
	{
		kidList = _List_Cons(_VirtualDom_virtualize(kids[i]), kidList);
	}
	return A3(_VirtualDom_node, tag, attrList, kidList);
}

function _VirtualDom_dekey(keyedNode)
{
	var keyedKids = keyedNode.e;
	var len = keyedKids.length;
	var kids = new Array(len);
	for (var i = 0; i < len; i++)
	{
		kids[i] = keyedKids[i].b;
	}

	return {
		$: 1,
		c: keyedNode.c,
		d: keyedNode.d,
		e: kids,
		f: keyedNode.f,
		b: keyedNode.b
	};
}




// ELEMENT


var _Debugger_element;

var _Browser_element = _Debugger_element || F4(function(impl, flagDecoder, debugMetadata, args)
{
	return _Platform_initialize(
		flagDecoder,
		args,
		impl.init,
		impl.update,
		impl.subscriptions,
		function(sendToApp, initialModel) {
			var view = impl.view;
			/**_UNUSED/
			var domNode = args['node'];
			//*/
			/**/
			var domNode = args && args['node'] ? args['node'] : _Debug_crash(0);
			//*/
			var currNode = _VirtualDom_virtualize(domNode);

			return _Browser_makeAnimator(initialModel, function(model)
			{
				var nextNode = view(model);
				var patches = _VirtualDom_diff(currNode, nextNode);
				domNode = _VirtualDom_applyPatches(domNode, currNode, patches, sendToApp);
				currNode = nextNode;
			});
		}
	);
});



// DOCUMENT


var _Debugger_document;

var _Browser_document = _Debugger_document || F4(function(impl, flagDecoder, debugMetadata, args)
{
	return _Platform_initialize(
		flagDecoder,
		args,
		impl.init,
		impl.update,
		impl.subscriptions,
		function(sendToApp, initialModel) {
			var divertHrefToApp = impl.setup && impl.setup(sendToApp)
			var view = impl.view;
			var title = _VirtualDom_doc.title;
			var bodyNode = _VirtualDom_doc.body;
			var currNode = _VirtualDom_virtualize(bodyNode);
			return _Browser_makeAnimator(initialModel, function(model)
			{
				_VirtualDom_divertHrefToApp = divertHrefToApp;
				var doc = view(model);
				var nextNode = _VirtualDom_node('body')(_List_Nil)(doc.body);
				var patches = _VirtualDom_diff(currNode, nextNode);
				bodyNode = _VirtualDom_applyPatches(bodyNode, currNode, patches, sendToApp);
				currNode = nextNode;
				_VirtualDom_divertHrefToApp = 0;
				(title !== doc.title) && (_VirtualDom_doc.title = title = doc.title);
			});
		}
	);
});



// ANIMATION


var _Browser_cancelAnimationFrame =
	typeof cancelAnimationFrame !== 'undefined'
		? cancelAnimationFrame
		: function(id) { clearTimeout(id); };

var _Browser_requestAnimationFrame =
	typeof requestAnimationFrame !== 'undefined'
		? requestAnimationFrame
		: function(callback) { return setTimeout(callback, 1000 / 60); };


function _Browser_makeAnimator(model, draw)
{
	draw(model);

	var state = 0;

	function updateIfNeeded()
	{
		state = state === 1
			? 0
			: ( _Browser_requestAnimationFrame(updateIfNeeded), draw(model), 1 );
	}

	return function(nextModel, isSync)
	{
		model = nextModel;

		isSync
			? ( draw(model),
				state === 2 && (state = 1)
				)
			: ( state === 0 && _Browser_requestAnimationFrame(updateIfNeeded),
				state = 2
				);
	};
}



// APPLICATION


function _Browser_application(impl)
{
	var onUrlChange = impl.onUrlChange;
	var onUrlRequest = impl.onUrlRequest;
	var key = function() { key.a(onUrlChange(_Browser_getUrl())); };

	return _Browser_document({
		setup: function(sendToApp)
		{
			key.a = sendToApp;
			_Browser_window.addEventListener('popstate', key);
			_Browser_window.navigator.userAgent.indexOf('Trident') < 0 || _Browser_window.addEventListener('hashchange', key);

			return F2(function(domNode, event)
			{
				if (!event.ctrlKey && !event.metaKey && !event.shiftKey && event.button < 1 && !domNode.target && !domNode.hasAttribute('download'))
				{
					event.preventDefault();
					var href = domNode.href;
					var curr = _Browser_getUrl();
					var next = $elm$url$Url$fromString(href).a;
					sendToApp(onUrlRequest(
						(next
							&& curr.protocol === next.protocol
							&& curr.host === next.host
							&& curr.port_.a === next.port_.a
						)
							? $elm$browser$Browser$Internal(next)
							: $elm$browser$Browser$External(href)
					));
				}
			});
		},
		init: function(flags)
		{
			return A3(impl.init, flags, _Browser_getUrl(), key);
		},
		view: impl.view,
		update: impl.update,
		subscriptions: impl.subscriptions
	});
}

function _Browser_getUrl()
{
	return $elm$url$Url$fromString(_VirtualDom_doc.location.href).a || _Debug_crash(1);
}

var _Browser_go = F2(function(key, n)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function() {
		n && history.go(n);
		key();
	}));
});

var _Browser_pushUrl = F2(function(key, url)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function() {
		history.pushState({}, '', url);
		key();
	}));
});

var _Browser_replaceUrl = F2(function(key, url)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function() {
		history.replaceState({}, '', url);
		key();
	}));
});



// GLOBAL EVENTS


var _Browser_fakeNode = { addEventListener: function() {}, removeEventListener: function() {} };
var _Browser_doc = typeof document !== 'undefined' ? document : _Browser_fakeNode;
var _Browser_window = typeof window !== 'undefined' ? window : _Browser_fakeNode;

var _Browser_on = F3(function(node, eventName, sendToSelf)
{
	return _Scheduler_spawn(_Scheduler_binding(function(callback)
	{
		function handler(event)	{ _Scheduler_rawSpawn(sendToSelf(event)); }
		node.addEventListener(eventName, handler, _VirtualDom_passiveSupported && { passive: true });
		return function() { node.removeEventListener(eventName, handler); };
	}));
});

var _Browser_decodeEvent = F2(function(decoder, event)
{
	var result = _Json_runHelp(decoder, event);
	return $elm$core$Result$isOk(result) ? $elm$core$Maybe$Just(result.a) : $elm$core$Maybe$Nothing;
});



// PAGE VISIBILITY


function _Browser_visibilityInfo()
{
	return (typeof _VirtualDom_doc.hidden !== 'undefined')
		? { hidden: 'hidden', change: 'visibilitychange' }
		:
	(typeof _VirtualDom_doc.mozHidden !== 'undefined')
		? { hidden: 'mozHidden', change: 'mozvisibilitychange' }
		:
	(typeof _VirtualDom_doc.msHidden !== 'undefined')
		? { hidden: 'msHidden', change: 'msvisibilitychange' }
		:
	(typeof _VirtualDom_doc.webkitHidden !== 'undefined')
		? { hidden: 'webkitHidden', change: 'webkitvisibilitychange' }
		: { hidden: 'hidden', change: 'visibilitychange' };
}



// ANIMATION FRAMES


function _Browser_rAF()
{
	return _Scheduler_binding(function(callback)
	{
		var id = _Browser_requestAnimationFrame(function() {
			callback(_Scheduler_succeed(Date.now()));
		});

		return function() {
			_Browser_cancelAnimationFrame(id);
		};
	});
}


function _Browser_now()
{
	return _Scheduler_binding(function(callback)
	{
		callback(_Scheduler_succeed(Date.now()));
	});
}



// DOM STUFF


function _Browser_withNode(id, doStuff)
{
	return _Scheduler_binding(function(callback)
	{
		_Browser_requestAnimationFrame(function() {
			var node = document.getElementById(id);
			callback(node
				? _Scheduler_succeed(doStuff(node))
				: _Scheduler_fail($elm$browser$Browser$Dom$NotFound(id))
			);
		});
	});
}


function _Browser_withWindow(doStuff)
{
	return _Scheduler_binding(function(callback)
	{
		_Browser_requestAnimationFrame(function() {
			callback(_Scheduler_succeed(doStuff()));
		});
	});
}


// FOCUS and BLUR


var _Browser_call = F2(function(functionName, id)
{
	return _Browser_withNode(id, function(node) {
		node[functionName]();
		return _Utils_Tuple0;
	});
});



// WINDOW VIEWPORT


function _Browser_getViewport()
{
	return {
		scene: _Browser_getScene(),
		viewport: {
			x: _Browser_window.pageXOffset,
			y: _Browser_window.pageYOffset,
			width: _Browser_doc.documentElement.clientWidth,
			height: _Browser_doc.documentElement.clientHeight
		}
	};
}

function _Browser_getScene()
{
	var body = _Browser_doc.body;
	var elem = _Browser_doc.documentElement;
	return {
		width: Math.max(body.scrollWidth, body.offsetWidth, elem.scrollWidth, elem.offsetWidth, elem.clientWidth),
		height: Math.max(body.scrollHeight, body.offsetHeight, elem.scrollHeight, elem.offsetHeight, elem.clientHeight)
	};
}

var _Browser_setViewport = F2(function(x, y)
{
	return _Browser_withWindow(function()
	{
		_Browser_window.scroll(x, y);
		return _Utils_Tuple0;
	});
});



// ELEMENT VIEWPORT


function _Browser_getViewportOf(id)
{
	return _Browser_withNode(id, function(node)
	{
		return {
			scene: {
				width: node.scrollWidth,
				height: node.scrollHeight
			},
			viewport: {
				x: node.scrollLeft,
				y: node.scrollTop,
				width: node.clientWidth,
				height: node.clientHeight
			}
		};
	});
}


var _Browser_setViewportOf = F3(function(id, x, y)
{
	return _Browser_withNode(id, function(node)
	{
		node.scrollLeft = x;
		node.scrollTop = y;
		return _Utils_Tuple0;
	});
});



// ELEMENT


function _Browser_getElement(id)
{
	return _Browser_withNode(id, function(node)
	{
		var rect = node.getBoundingClientRect();
		var x = _Browser_window.pageXOffset;
		var y = _Browser_window.pageYOffset;
		return {
			scene: _Browser_getScene(),
			viewport: {
				x: x,
				y: y,
				width: _Browser_doc.documentElement.clientWidth,
				height: _Browser_doc.documentElement.clientHeight
			},
			element: {
				x: x + rect.left,
				y: y + rect.top,
				width: rect.width,
				height: rect.height
			}
		};
	});
}



// LOAD and RELOAD


function _Browser_reload(skipCache)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function(callback)
	{
		_VirtualDom_doc.location.reload(skipCache);
	}));
}

function _Browser_load(url)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function(callback)
	{
		try
		{
			_Browser_window.location = url;
		}
		catch(err)
		{
			// Only Firefox can throw a NS_ERROR_MALFORMED_URI exception here.
			// Other browsers reload the page, so let's be consistent about that.
			_VirtualDom_doc.location.reload(false);
		}
	}));
}


/*
 * Copyright (c) 2010 Mozilla Corporation
 * Copyright (c) 2010 Vladimir Vukicevic
 * Copyright (c) 2013 John Mayer
 * Copyright (c) 2018 Andrey Kuzmin
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

// Vector2

var _MJS_v2 = F2(function(x, y) {
    return new Float64Array([x, y]);
});

var _MJS_v2getX = function(a) {
    return a[0];
};

var _MJS_v2getY = function(a) {
    return a[1];
};

var _MJS_v2setX = F2(function(x, a) {
    return new Float64Array([x, a[1]]);
});

var _MJS_v2setY = F2(function(y, a) {
    return new Float64Array([a[0], y]);
});

var _MJS_v2toRecord = function(a) {
    return { x: a[0], y: a[1] };
};

var _MJS_v2fromRecord = function(r) {
    return new Float64Array([r.x, r.y]);
};

var _MJS_v2add = F2(function(a, b) {
    var r = new Float64Array(2);
    r[0] = a[0] + b[0];
    r[1] = a[1] + b[1];
    return r;
});

var _MJS_v2sub = F2(function(a, b) {
    var r = new Float64Array(2);
    r[0] = a[0] - b[0];
    r[1] = a[1] - b[1];
    return r;
});

var _MJS_v2negate = function(a) {
    var r = new Float64Array(2);
    r[0] = -a[0];
    r[1] = -a[1];
    return r;
};

var _MJS_v2direction = F2(function(a, b) {
    var r = new Float64Array(2);
    r[0] = a[0] - b[0];
    r[1] = a[1] - b[1];
    var im = 1.0 / _MJS_v2lengthLocal(r);
    r[0] = r[0] * im;
    r[1] = r[1] * im;
    return r;
});

function _MJS_v2lengthLocal(a) {
    return Math.sqrt(a[0] * a[0] + a[1] * a[1]);
}
var _MJS_v2length = _MJS_v2lengthLocal;

var _MJS_v2lengthSquared = function(a) {
    return a[0] * a[0] + a[1] * a[1];
};

var _MJS_v2distance = F2(function(a, b) {
    var dx = a[0] - b[0];
    var dy = a[1] - b[1];
    return Math.sqrt(dx * dx + dy * dy);
});

var _MJS_v2distanceSquared = F2(function(a, b) {
    var dx = a[0] - b[0];
    var dy = a[1] - b[1];
    return dx * dx + dy * dy;
});

var _MJS_v2normalize = function(a) {
    var r = new Float64Array(2);
    var im = 1.0 / _MJS_v2lengthLocal(a);
    r[0] = a[0] * im;
    r[1] = a[1] * im;
    return r;
};

var _MJS_v2scale = F2(function(k, a) {
    var r = new Float64Array(2);
    r[0] = a[0] * k;
    r[1] = a[1] * k;
    return r;
});

var _MJS_v2dot = F2(function(a, b) {
    return a[0] * b[0] + a[1] * b[1];
});

// Vector3

var _MJS_v3temp1Local = new Float64Array(3);
var _MJS_v3temp2Local = new Float64Array(3);
var _MJS_v3temp3Local = new Float64Array(3);

var _MJS_v3 = F3(function(x, y, z) {
    return new Float64Array([x, y, z]);
});

var _MJS_v3getX = function(a) {
    return a[0];
};

var _MJS_v3getY = function(a) {
    return a[1];
};

var _MJS_v3getZ = function(a) {
    return a[2];
};

var _MJS_v3setX = F2(function(x, a) {
    return new Float64Array([x, a[1], a[2]]);
});

var _MJS_v3setY = F2(function(y, a) {
    return new Float64Array([a[0], y, a[2]]);
});

var _MJS_v3setZ = F2(function(z, a) {
    return new Float64Array([a[0], a[1], z]);
});

var _MJS_v3toRecord = function(a) {
    return { x: a[0], y: a[1], z: a[2] };
};

var _MJS_v3fromRecord = function(r) {
    return new Float64Array([r.x, r.y, r.z]);
};

var _MJS_v3add = F2(function(a, b) {
    var r = new Float64Array(3);
    r[0] = a[0] + b[0];
    r[1] = a[1] + b[1];
    r[2] = a[2] + b[2];
    return r;
});

function _MJS_v3subLocal(a, b, r) {
    if (r === undefined) {
        r = new Float64Array(3);
    }
    r[0] = a[0] - b[0];
    r[1] = a[1] - b[1];
    r[2] = a[2] - b[2];
    return r;
}
var _MJS_v3sub = F2(_MJS_v3subLocal);

var _MJS_v3negate = function(a) {
    var r = new Float64Array(3);
    r[0] = -a[0];
    r[1] = -a[1];
    r[2] = -a[2];
    return r;
};

function _MJS_v3directionLocal(a, b, r) {
    if (r === undefined) {
        r = new Float64Array(3);
    }
    return _MJS_v3normalizeLocal(_MJS_v3subLocal(a, b, r), r);
}
var _MJS_v3direction = F2(_MJS_v3directionLocal);

function _MJS_v3lengthLocal(a) {
    return Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
}
var _MJS_v3length = _MJS_v3lengthLocal;

var _MJS_v3lengthSquared = function(a) {
    return a[0] * a[0] + a[1] * a[1] + a[2] * a[2];
};

var _MJS_v3distance = F2(function(a, b) {
    var dx = a[0] - b[0];
    var dy = a[1] - b[1];
    var dz = a[2] - b[2];
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
});

var _MJS_v3distanceSquared = F2(function(a, b) {
    var dx = a[0] - b[0];
    var dy = a[1] - b[1];
    var dz = a[2] - b[2];
    return dx * dx + dy * dy + dz * dz;
});

function _MJS_v3normalizeLocal(a, r) {
    if (r === undefined) {
        r = new Float64Array(3);
    }
    var im = 1.0 / _MJS_v3lengthLocal(a);
    r[0] = a[0] * im;
    r[1] = a[1] * im;
    r[2] = a[2] * im;
    return r;
}
var _MJS_v3normalize = _MJS_v3normalizeLocal;

var _MJS_v3scale = F2(function(k, a) {
    return new Float64Array([a[0] * k, a[1] * k, a[2] * k]);
});

var _MJS_v3dotLocal = function(a, b) {
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
};
var _MJS_v3dot = F2(_MJS_v3dotLocal);

function _MJS_v3crossLocal(a, b, r) {
    if (r === undefined) {
        r = new Float64Array(3);
    }
    r[0] = a[1] * b[2] - a[2] * b[1];
    r[1] = a[2] * b[0] - a[0] * b[2];
    r[2] = a[0] * b[1] - a[1] * b[0];
    return r;
}
var _MJS_v3cross = F2(_MJS_v3crossLocal);

var _MJS_v3mul4x4 = F2(function(m, v) {
    var w;
    var tmp = _MJS_v3temp1Local;
    var r = new Float64Array(3);

    tmp[0] = m[3];
    tmp[1] = m[7];
    tmp[2] = m[11];
    w = _MJS_v3dotLocal(v, tmp) + m[15];
    tmp[0] = m[0];
    tmp[1] = m[4];
    tmp[2] = m[8];
    r[0] = (_MJS_v3dotLocal(v, tmp) + m[12]) / w;
    tmp[0] = m[1];
    tmp[1] = m[5];
    tmp[2] = m[9];
    r[1] = (_MJS_v3dotLocal(v, tmp) + m[13]) / w;
    tmp[0] = m[2];
    tmp[1] = m[6];
    tmp[2] = m[10];
    r[2] = (_MJS_v3dotLocal(v, tmp) + m[14]) / w;
    return r;
});

// Vector4

var _MJS_v4 = F4(function(x, y, z, w) {
    return new Float64Array([x, y, z, w]);
});

var _MJS_v4getX = function(a) {
    return a[0];
};

var _MJS_v4getY = function(a) {
    return a[1];
};

var _MJS_v4getZ = function(a) {
    return a[2];
};

var _MJS_v4getW = function(a) {
    return a[3];
};

var _MJS_v4setX = F2(function(x, a) {
    return new Float64Array([x, a[1], a[2], a[3]]);
});

var _MJS_v4setY = F2(function(y, a) {
    return new Float64Array([a[0], y, a[2], a[3]]);
});

var _MJS_v4setZ = F2(function(z, a) {
    return new Float64Array([a[0], a[1], z, a[3]]);
});

var _MJS_v4setW = F2(function(w, a) {
    return new Float64Array([a[0], a[1], a[2], w]);
});

var _MJS_v4toRecord = function(a) {
    return { x: a[0], y: a[1], z: a[2], w: a[3] };
};

var _MJS_v4fromRecord = function(r) {
    return new Float64Array([r.x, r.y, r.z, r.w]);
};

var _MJS_v4add = F2(function(a, b) {
    var r = new Float64Array(4);
    r[0] = a[0] + b[0];
    r[1] = a[1] + b[1];
    r[2] = a[2] + b[2];
    r[3] = a[3] + b[3];
    return r;
});

var _MJS_v4sub = F2(function(a, b) {
    var r = new Float64Array(4);
    r[0] = a[0] - b[0];
    r[1] = a[1] - b[1];
    r[2] = a[2] - b[2];
    r[3] = a[3] - b[3];
    return r;
});

var _MJS_v4negate = function(a) {
    var r = new Float64Array(4);
    r[0] = -a[0];
    r[1] = -a[1];
    r[2] = -a[2];
    r[3] = -a[3];
    return r;
};

var _MJS_v4direction = F2(function(a, b) {
    var r = new Float64Array(4);
    r[0] = a[0] - b[0];
    r[1] = a[1] - b[1];
    r[2] = a[2] - b[2];
    r[3] = a[3] - b[3];
    var im = 1.0 / _MJS_v4lengthLocal(r);
    r[0] = r[0] * im;
    r[1] = r[1] * im;
    r[2] = r[2] * im;
    r[3] = r[3] * im;
    return r;
});

function _MJS_v4lengthLocal(a) {
    return Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2] + a[3] * a[3]);
}
var _MJS_v4length = _MJS_v4lengthLocal;

var _MJS_v4lengthSquared = function(a) {
    return a[0] * a[0] + a[1] * a[1] + a[2] * a[2] + a[3] * a[3];
};

var _MJS_v4distance = F2(function(a, b) {
    var dx = a[0] - b[0];
    var dy = a[1] - b[1];
    var dz = a[2] - b[2];
    var dw = a[3] - b[3];
    return Math.sqrt(dx * dx + dy * dy + dz * dz + dw * dw);
});

var _MJS_v4distanceSquared = F2(function(a, b) {
    var dx = a[0] - b[0];
    var dy = a[1] - b[1];
    var dz = a[2] - b[2];
    var dw = a[3] - b[3];
    return dx * dx + dy * dy + dz * dz + dw * dw;
});

var _MJS_v4normalize = function(a) {
    var r = new Float64Array(4);
    var im = 1.0 / _MJS_v4lengthLocal(a);
    r[0] = a[0] * im;
    r[1] = a[1] * im;
    r[2] = a[2] * im;
    r[3] = a[3] * im;
    return r;
};

var _MJS_v4scale = F2(function(k, a) {
    var r = new Float64Array(4);
    r[0] = a[0] * k;
    r[1] = a[1] * k;
    r[2] = a[2] * k;
    r[3] = a[3] * k;
    return r;
});

var _MJS_v4dot = F2(function(a, b) {
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3];
});

// Matrix4

var _MJS_m4x4temp1Local = new Float64Array(16);
var _MJS_m4x4temp2Local = new Float64Array(16);

var _MJS_m4x4identity = new Float64Array([
    1.0, 0.0, 0.0, 0.0,
    0.0, 1.0, 0.0, 0.0,
    0.0, 0.0, 1.0, 0.0,
    0.0, 0.0, 0.0, 1.0
]);

var _MJS_m4x4fromRecord = function(r) {
    var m = new Float64Array(16);
    m[0] = r.m11;
    m[1] = r.m21;
    m[2] = r.m31;
    m[3] = r.m41;
    m[4] = r.m12;
    m[5] = r.m22;
    m[6] = r.m32;
    m[7] = r.m42;
    m[8] = r.m13;
    m[9] = r.m23;
    m[10] = r.m33;
    m[11] = r.m43;
    m[12] = r.m14;
    m[13] = r.m24;
    m[14] = r.m34;
    m[15] = r.m44;
    return m;
};

var _MJS_m4x4toRecord = function(m) {
    return {
        m11: m[0], m21: m[1], m31: m[2], m41: m[3],
        m12: m[4], m22: m[5], m32: m[6], m42: m[7],
        m13: m[8], m23: m[9], m33: m[10], m43: m[11],
        m14: m[12], m24: m[13], m34: m[14], m44: m[15]
    };
};

var _MJS_m4x4inverse = function(m) {
    var r = new Float64Array(16);

    r[0] = m[5] * m[10] * m[15] - m[5] * m[11] * m[14] - m[9] * m[6] * m[15] +
        m[9] * m[7] * m[14] + m[13] * m[6] * m[11] - m[13] * m[7] * m[10];
    r[4] = -m[4] * m[10] * m[15] + m[4] * m[11] * m[14] + m[8] * m[6] * m[15] -
        m[8] * m[7] * m[14] - m[12] * m[6] * m[11] + m[12] * m[7] * m[10];
    r[8] = m[4] * m[9] * m[15] - m[4] * m[11] * m[13] - m[8] * m[5] * m[15] +
        m[8] * m[7] * m[13] + m[12] * m[5] * m[11] - m[12] * m[7] * m[9];
    r[12] = -m[4] * m[9] * m[14] + m[4] * m[10] * m[13] + m[8] * m[5] * m[14] -
        m[8] * m[6] * m[13] - m[12] * m[5] * m[10] + m[12] * m[6] * m[9];
    r[1] = -m[1] * m[10] * m[15] + m[1] * m[11] * m[14] + m[9] * m[2] * m[15] -
        m[9] * m[3] * m[14] - m[13] * m[2] * m[11] + m[13] * m[3] * m[10];
    r[5] = m[0] * m[10] * m[15] - m[0] * m[11] * m[14] - m[8] * m[2] * m[15] +
        m[8] * m[3] * m[14] + m[12] * m[2] * m[11] - m[12] * m[3] * m[10];
    r[9] = -m[0] * m[9] * m[15] + m[0] * m[11] * m[13] + m[8] * m[1] * m[15] -
        m[8] * m[3] * m[13] - m[12] * m[1] * m[11] + m[12] * m[3] * m[9];
    r[13] = m[0] * m[9] * m[14] - m[0] * m[10] * m[13] - m[8] * m[1] * m[14] +
        m[8] * m[2] * m[13] + m[12] * m[1] * m[10] - m[12] * m[2] * m[9];
    r[2] = m[1] * m[6] * m[15] - m[1] * m[7] * m[14] - m[5] * m[2] * m[15] +
        m[5] * m[3] * m[14] + m[13] * m[2] * m[7] - m[13] * m[3] * m[6];
    r[6] = -m[0] * m[6] * m[15] + m[0] * m[7] * m[14] + m[4] * m[2] * m[15] -
        m[4] * m[3] * m[14] - m[12] * m[2] * m[7] + m[12] * m[3] * m[6];
    r[10] = m[0] * m[5] * m[15] - m[0] * m[7] * m[13] - m[4] * m[1] * m[15] +
        m[4] * m[3] * m[13] + m[12] * m[1] * m[7] - m[12] * m[3] * m[5];
    r[14] = -m[0] * m[5] * m[14] + m[0] * m[6] * m[13] + m[4] * m[1] * m[14] -
        m[4] * m[2] * m[13] - m[12] * m[1] * m[6] + m[12] * m[2] * m[5];
    r[3] = -m[1] * m[6] * m[11] + m[1] * m[7] * m[10] + m[5] * m[2] * m[11] -
        m[5] * m[3] * m[10] - m[9] * m[2] * m[7] + m[9] * m[3] * m[6];
    r[7] = m[0] * m[6] * m[11] - m[0] * m[7] * m[10] - m[4] * m[2] * m[11] +
        m[4] * m[3] * m[10] + m[8] * m[2] * m[7] - m[8] * m[3] * m[6];
    r[11] = -m[0] * m[5] * m[11] + m[0] * m[7] * m[9] + m[4] * m[1] * m[11] -
        m[4] * m[3] * m[9] - m[8] * m[1] * m[7] + m[8] * m[3] * m[5];
    r[15] = m[0] * m[5] * m[10] - m[0] * m[6] * m[9] - m[4] * m[1] * m[10] +
        m[4] * m[2] * m[9] + m[8] * m[1] * m[6] - m[8] * m[2] * m[5];

    var det = m[0] * r[0] + m[1] * r[4] + m[2] * r[8] + m[3] * r[12];

    if (det === 0) {
        return $elm$core$Maybe$Nothing;
    }

    det = 1.0 / det;

    for (var i = 0; i < 16; i = i + 1) {
        r[i] = r[i] * det;
    }

    return $elm$core$Maybe$Just(r);
};

var _MJS_m4x4inverseOrthonormal = function(m) {
    var r = _MJS_m4x4transposeLocal(m);
    var t = [m[12], m[13], m[14]];
    r[3] = r[7] = r[11] = 0;
    r[12] = -_MJS_v3dotLocal([r[0], r[4], r[8]], t);
    r[13] = -_MJS_v3dotLocal([r[1], r[5], r[9]], t);
    r[14] = -_MJS_v3dotLocal([r[2], r[6], r[10]], t);
    return r;
};

function _MJS_m4x4makeFrustumLocal(left, right, bottom, top, znear, zfar) {
    var r = new Float64Array(16);

    r[0] = 2 * znear / (right - left);
    r[1] = 0;
    r[2] = 0;
    r[3] = 0;
    r[4] = 0;
    r[5] = 2 * znear / (top - bottom);
    r[6] = 0;
    r[7] = 0;
    r[8] = (right + left) / (right - left);
    r[9] = (top + bottom) / (top - bottom);
    r[10] = -(zfar + znear) / (zfar - znear);
    r[11] = -1;
    r[12] = 0;
    r[13] = 0;
    r[14] = -2 * zfar * znear / (zfar - znear);
    r[15] = 0;

    return r;
}
var _MJS_m4x4makeFrustum = F6(_MJS_m4x4makeFrustumLocal);

var _MJS_m4x4makePerspective = F4(function(fovy, aspect, znear, zfar) {
    var ymax = znear * Math.tan(fovy * Math.PI / 360.0);
    var ymin = -ymax;
    var xmin = ymin * aspect;
    var xmax = ymax * aspect;

    return _MJS_m4x4makeFrustumLocal(xmin, xmax, ymin, ymax, znear, zfar);
});

function _MJS_m4x4makeOrthoLocal(left, right, bottom, top, znear, zfar) {
    var r = new Float64Array(16);

    r[0] = 2 / (right - left);
    r[1] = 0;
    r[2] = 0;
    r[3] = 0;
    r[4] = 0;
    r[5] = 2 / (top - bottom);
    r[6] = 0;
    r[7] = 0;
    r[8] = 0;
    r[9] = 0;
    r[10] = -2 / (zfar - znear);
    r[11] = 0;
    r[12] = -(right + left) / (right - left);
    r[13] = -(top + bottom) / (top - bottom);
    r[14] = -(zfar + znear) / (zfar - znear);
    r[15] = 1;

    return r;
}
var _MJS_m4x4makeOrtho = F6(_MJS_m4x4makeOrthoLocal);

var _MJS_m4x4makeOrtho2D = F4(function(left, right, bottom, top) {
    return _MJS_m4x4makeOrthoLocal(left, right, bottom, top, -1, 1);
});

function _MJS_m4x4mulLocal(a, b) {
    var r = new Float64Array(16);
    var a11 = a[0];
    var a21 = a[1];
    var a31 = a[2];
    var a41 = a[3];
    var a12 = a[4];
    var a22 = a[5];
    var a32 = a[6];
    var a42 = a[7];
    var a13 = a[8];
    var a23 = a[9];
    var a33 = a[10];
    var a43 = a[11];
    var a14 = a[12];
    var a24 = a[13];
    var a34 = a[14];
    var a44 = a[15];
    var b11 = b[0];
    var b21 = b[1];
    var b31 = b[2];
    var b41 = b[3];
    var b12 = b[4];
    var b22 = b[5];
    var b32 = b[6];
    var b42 = b[7];
    var b13 = b[8];
    var b23 = b[9];
    var b33 = b[10];
    var b43 = b[11];
    var b14 = b[12];
    var b24 = b[13];
    var b34 = b[14];
    var b44 = b[15];

    r[0] = a11 * b11 + a12 * b21 + a13 * b31 + a14 * b41;
    r[1] = a21 * b11 + a22 * b21 + a23 * b31 + a24 * b41;
    r[2] = a31 * b11 + a32 * b21 + a33 * b31 + a34 * b41;
    r[3] = a41 * b11 + a42 * b21 + a43 * b31 + a44 * b41;
    r[4] = a11 * b12 + a12 * b22 + a13 * b32 + a14 * b42;
    r[5] = a21 * b12 + a22 * b22 + a23 * b32 + a24 * b42;
    r[6] = a31 * b12 + a32 * b22 + a33 * b32 + a34 * b42;
    r[7] = a41 * b12 + a42 * b22 + a43 * b32 + a44 * b42;
    r[8] = a11 * b13 + a12 * b23 + a13 * b33 + a14 * b43;
    r[9] = a21 * b13 + a22 * b23 + a23 * b33 + a24 * b43;
    r[10] = a31 * b13 + a32 * b23 + a33 * b33 + a34 * b43;
    r[11] = a41 * b13 + a42 * b23 + a43 * b33 + a44 * b43;
    r[12] = a11 * b14 + a12 * b24 + a13 * b34 + a14 * b44;
    r[13] = a21 * b14 + a22 * b24 + a23 * b34 + a24 * b44;
    r[14] = a31 * b14 + a32 * b24 + a33 * b34 + a34 * b44;
    r[15] = a41 * b14 + a42 * b24 + a43 * b34 + a44 * b44;

    return r;
}
var _MJS_m4x4mul = F2(_MJS_m4x4mulLocal);

var _MJS_m4x4mulAffine = F2(function(a, b) {
    var r = new Float64Array(16);
    var a11 = a[0];
    var a21 = a[1];
    var a31 = a[2];
    var a12 = a[4];
    var a22 = a[5];
    var a32 = a[6];
    var a13 = a[8];
    var a23 = a[9];
    var a33 = a[10];
    var a14 = a[12];
    var a24 = a[13];
    var a34 = a[14];

    var b11 = b[0];
    var b21 = b[1];
    var b31 = b[2];
    var b12 = b[4];
    var b22 = b[5];
    var b32 = b[6];
    var b13 = b[8];
    var b23 = b[9];
    var b33 = b[10];
    var b14 = b[12];
    var b24 = b[13];
    var b34 = b[14];

    r[0] = a11 * b11 + a12 * b21 + a13 * b31;
    r[1] = a21 * b11 + a22 * b21 + a23 * b31;
    r[2] = a31 * b11 + a32 * b21 + a33 * b31;
    r[3] = 0;
    r[4] = a11 * b12 + a12 * b22 + a13 * b32;
    r[5] = a21 * b12 + a22 * b22 + a23 * b32;
    r[6] = a31 * b12 + a32 * b22 + a33 * b32;
    r[7] = 0;
    r[8] = a11 * b13 + a12 * b23 + a13 * b33;
    r[9] = a21 * b13 + a22 * b23 + a23 * b33;
    r[10] = a31 * b13 + a32 * b23 + a33 * b33;
    r[11] = 0;
    r[12] = a11 * b14 + a12 * b24 + a13 * b34 + a14;
    r[13] = a21 * b14 + a22 * b24 + a23 * b34 + a24;
    r[14] = a31 * b14 + a32 * b24 + a33 * b34 + a34;
    r[15] = 1;

    return r;
});

var _MJS_m4x4makeRotate = F2(function(angle, axis) {
    var r = new Float64Array(16);
    axis = _MJS_v3normalizeLocal(axis, _MJS_v3temp1Local);
    var x = axis[0];
    var y = axis[1];
    var z = axis[2];
    var c = Math.cos(angle);
    var c1 = 1 - c;
    var s = Math.sin(angle);

    r[0] = x * x * c1 + c;
    r[1] = y * x * c1 + z * s;
    r[2] = z * x * c1 - y * s;
    r[3] = 0;
    r[4] = x * y * c1 - z * s;
    r[5] = y * y * c1 + c;
    r[6] = y * z * c1 + x * s;
    r[7] = 0;
    r[8] = x * z * c1 + y * s;
    r[9] = y * z * c1 - x * s;
    r[10] = z * z * c1 + c;
    r[11] = 0;
    r[12] = 0;
    r[13] = 0;
    r[14] = 0;
    r[15] = 1;

    return r;
});

var _MJS_m4x4rotate = F3(function(angle, axis, m) {
    var r = new Float64Array(16);
    var im = 1.0 / _MJS_v3lengthLocal(axis);
    var x = axis[0] * im;
    var y = axis[1] * im;
    var z = axis[2] * im;
    var c = Math.cos(angle);
    var c1 = 1 - c;
    var s = Math.sin(angle);
    var xs = x * s;
    var ys = y * s;
    var zs = z * s;
    var xyc1 = x * y * c1;
    var xzc1 = x * z * c1;
    var yzc1 = y * z * c1;
    var t11 = x * x * c1 + c;
    var t21 = xyc1 + zs;
    var t31 = xzc1 - ys;
    var t12 = xyc1 - zs;
    var t22 = y * y * c1 + c;
    var t32 = yzc1 + xs;
    var t13 = xzc1 + ys;
    var t23 = yzc1 - xs;
    var t33 = z * z * c1 + c;
    var m11 = m[0], m21 = m[1], m31 = m[2], m41 = m[3];
    var m12 = m[4], m22 = m[5], m32 = m[6], m42 = m[7];
    var m13 = m[8], m23 = m[9], m33 = m[10], m43 = m[11];
    var m14 = m[12], m24 = m[13], m34 = m[14], m44 = m[15];

    r[0] = m11 * t11 + m12 * t21 + m13 * t31;
    r[1] = m21 * t11 + m22 * t21 + m23 * t31;
    r[2] = m31 * t11 + m32 * t21 + m33 * t31;
    r[3] = m41 * t11 + m42 * t21 + m43 * t31;
    r[4] = m11 * t12 + m12 * t22 + m13 * t32;
    r[5] = m21 * t12 + m22 * t22 + m23 * t32;
    r[6] = m31 * t12 + m32 * t22 + m33 * t32;
    r[7] = m41 * t12 + m42 * t22 + m43 * t32;
    r[8] = m11 * t13 + m12 * t23 + m13 * t33;
    r[9] = m21 * t13 + m22 * t23 + m23 * t33;
    r[10] = m31 * t13 + m32 * t23 + m33 * t33;
    r[11] = m41 * t13 + m42 * t23 + m43 * t33;
    r[12] = m14,
    r[13] = m24;
    r[14] = m34;
    r[15] = m44;

    return r;
});

function _MJS_m4x4makeScale3Local(x, y, z) {
    var r = new Float64Array(16);

    r[0] = x;
    r[1] = 0;
    r[2] = 0;
    r[3] = 0;
    r[4] = 0;
    r[5] = y;
    r[6] = 0;
    r[7] = 0;
    r[8] = 0;
    r[9] = 0;
    r[10] = z;
    r[11] = 0;
    r[12] = 0;
    r[13] = 0;
    r[14] = 0;
    r[15] = 1;

    return r;
}
var _MJS_m4x4makeScale3 = F3(_MJS_m4x4makeScale3Local);

var _MJS_m4x4makeScale = function(v) {
    return _MJS_m4x4makeScale3Local(v[0], v[1], v[2]);
};

var _MJS_m4x4scale3 = F4(function(x, y, z, m) {
    var r = new Float64Array(16);

    r[0] = m[0] * x;
    r[1] = m[1] * x;
    r[2] = m[2] * x;
    r[3] = m[3] * x;
    r[4] = m[4] * y;
    r[5] = m[5] * y;
    r[6] = m[6] * y;
    r[7] = m[7] * y;
    r[8] = m[8] * z;
    r[9] = m[9] * z;
    r[10] = m[10] * z;
    r[11] = m[11] * z;
    r[12] = m[12];
    r[13] = m[13];
    r[14] = m[14];
    r[15] = m[15];

    return r;
});

var _MJS_m4x4scale = F2(function(v, m) {
    var r = new Float64Array(16);
    var x = v[0];
    var y = v[1];
    var z = v[2];

    r[0] = m[0] * x;
    r[1] = m[1] * x;
    r[2] = m[2] * x;
    r[3] = m[3] * x;
    r[4] = m[4] * y;
    r[5] = m[5] * y;
    r[6] = m[6] * y;
    r[7] = m[7] * y;
    r[8] = m[8] * z;
    r[9] = m[9] * z;
    r[10] = m[10] * z;
    r[11] = m[11] * z;
    r[12] = m[12];
    r[13] = m[13];
    r[14] = m[14];
    r[15] = m[15];

    return r;
});

function _MJS_m4x4makeTranslate3Local(x, y, z) {
    var r = new Float64Array(16);

    r[0] = 1;
    r[1] = 0;
    r[2] = 0;
    r[3] = 0;
    r[4] = 0;
    r[5] = 1;
    r[6] = 0;
    r[7] = 0;
    r[8] = 0;
    r[9] = 0;
    r[10] = 1;
    r[11] = 0;
    r[12] = x;
    r[13] = y;
    r[14] = z;
    r[15] = 1;

    return r;
}
var _MJS_m4x4makeTranslate3 = F3(_MJS_m4x4makeTranslate3Local);

var _MJS_m4x4makeTranslate = function(v) {
    return _MJS_m4x4makeTranslate3Local(v[0], v[1], v[2]);
};

var _MJS_m4x4translate3 = F4(function(x, y, z, m) {
    var r = new Float64Array(16);
    var m11 = m[0];
    var m21 = m[1];
    var m31 = m[2];
    var m41 = m[3];
    var m12 = m[4];
    var m22 = m[5];
    var m32 = m[6];
    var m42 = m[7];
    var m13 = m[8];
    var m23 = m[9];
    var m33 = m[10];
    var m43 = m[11];

    r[0] = m11;
    r[1] = m21;
    r[2] = m31;
    r[3] = m41;
    r[4] = m12;
    r[5] = m22;
    r[6] = m32;
    r[7] = m42;
    r[8] = m13;
    r[9] = m23;
    r[10] = m33;
    r[11] = m43;
    r[12] = m11 * x + m12 * y + m13 * z + m[12];
    r[13] = m21 * x + m22 * y + m23 * z + m[13];
    r[14] = m31 * x + m32 * y + m33 * z + m[14];
    r[15] = m41 * x + m42 * y + m43 * z + m[15];

    return r;
});

var _MJS_m4x4translate = F2(function(v, m) {
    var r = new Float64Array(16);
    var x = v[0];
    var y = v[1];
    var z = v[2];
    var m11 = m[0];
    var m21 = m[1];
    var m31 = m[2];
    var m41 = m[3];
    var m12 = m[4];
    var m22 = m[5];
    var m32 = m[6];
    var m42 = m[7];
    var m13 = m[8];
    var m23 = m[9];
    var m33 = m[10];
    var m43 = m[11];

    r[0] = m11;
    r[1] = m21;
    r[2] = m31;
    r[3] = m41;
    r[4] = m12;
    r[5] = m22;
    r[6] = m32;
    r[7] = m42;
    r[8] = m13;
    r[9] = m23;
    r[10] = m33;
    r[11] = m43;
    r[12] = m11 * x + m12 * y + m13 * z + m[12];
    r[13] = m21 * x + m22 * y + m23 * z + m[13];
    r[14] = m31 * x + m32 * y + m33 * z + m[14];
    r[15] = m41 * x + m42 * y + m43 * z + m[15];

    return r;
});

var _MJS_m4x4makeLookAt = F3(function(eye, center, up) {
    var z = _MJS_v3directionLocal(eye, center, _MJS_v3temp1Local);
    var x = _MJS_v3normalizeLocal(_MJS_v3crossLocal(up, z, _MJS_v3temp2Local), _MJS_v3temp2Local);
    var y = _MJS_v3normalizeLocal(_MJS_v3crossLocal(z, x, _MJS_v3temp3Local), _MJS_v3temp3Local);
    var tm1 = _MJS_m4x4temp1Local;
    var tm2 = _MJS_m4x4temp2Local;

    tm1[0] = x[0];
    tm1[1] = y[0];
    tm1[2] = z[0];
    tm1[3] = 0;
    tm1[4] = x[1];
    tm1[5] = y[1];
    tm1[6] = z[1];
    tm1[7] = 0;
    tm1[8] = x[2];
    tm1[9] = y[2];
    tm1[10] = z[2];
    tm1[11] = 0;
    tm1[12] = 0;
    tm1[13] = 0;
    tm1[14] = 0;
    tm1[15] = 1;

    tm2[0] = 1; tm2[1] = 0; tm2[2] = 0; tm2[3] = 0;
    tm2[4] = 0; tm2[5] = 1; tm2[6] = 0; tm2[7] = 0;
    tm2[8] = 0; tm2[9] = 0; tm2[10] = 1; tm2[11] = 0;
    tm2[12] = -eye[0]; tm2[13] = -eye[1]; tm2[14] = -eye[2]; tm2[15] = 1;

    return _MJS_m4x4mulLocal(tm1, tm2);
});


function _MJS_m4x4transposeLocal(m) {
    var r = new Float64Array(16);

    r[0] = m[0]; r[1] = m[4]; r[2] = m[8]; r[3] = m[12];
    r[4] = m[1]; r[5] = m[5]; r[6] = m[9]; r[7] = m[13];
    r[8] = m[2]; r[9] = m[6]; r[10] = m[10]; r[11] = m[14];
    r[12] = m[3]; r[13] = m[7]; r[14] = m[11]; r[15] = m[15];

    return r;
}
var _MJS_m4x4transpose = _MJS_m4x4transposeLocal;

var _MJS_m4x4makeBasis = F3(function(vx, vy, vz) {
    var r = new Float64Array(16);

    r[0] = vx[0];
    r[1] = vx[1];
    r[2] = vx[2];
    r[3] = 0;
    r[4] = vy[0];
    r[5] = vy[1];
    r[6] = vy[2];
    r[7] = 0;
    r[8] = vz[0];
    r[9] = vz[1];
    r[10] = vz[2];
    r[11] = 0;
    r[12] = 0;
    r[13] = 0;
    r[14] = 0;
    r[15] = 1;

    return r;
});



var _Bitwise_and = F2(function(a, b)
{
	return a & b;
});

var _Bitwise_or = F2(function(a, b)
{
	return a | b;
});

var _Bitwise_xor = F2(function(a, b)
{
	return a ^ b;
});

function _Bitwise_complement(a)
{
	return ~a;
};

var _Bitwise_shiftLeftBy = F2(function(offset, a)
{
	return a << offset;
});

var _Bitwise_shiftRightBy = F2(function(offset, a)
{
	return a >> offset;
});

var _Bitwise_shiftRightZfBy = F2(function(offset, a)
{
	return a >>> offset;
});


// CREATE

var _Regex_never = /.^/;

var _Regex_fromStringWith = F2(function(options, string)
{
	var flags = 'g';
	if (options.multiline) { flags += 'm'; }
	if (options.caseInsensitive) { flags += 'i'; }

	try
	{
		return $elm$core$Maybe$Just(new RegExp(string, flags));
	}
	catch(error)
	{
		return $elm$core$Maybe$Nothing;
	}
});


// USE

var _Regex_contains = F2(function(re, string)
{
	return string.match(re) !== null;
});


var _Regex_findAtMost = F3(function(n, re, str)
{
	var out = [];
	var number = 0;
	var string = str;
	var lastIndex = re.lastIndex;
	var prevLastIndex = -1;
	var result;
	while (number++ < n && (result = re.exec(string)))
	{
		if (prevLastIndex == re.lastIndex) break;
		var i = result.length - 1;
		var subs = new Array(i);
		while (i > 0)
		{
			var submatch = result[i];
			subs[--i] = submatch
				? $elm$core$Maybe$Just(submatch)
				: $elm$core$Maybe$Nothing;
		}
		out.push(A4($elm$regex$Regex$Match, result[0], result.index, number, _List_fromArray(subs)));
		prevLastIndex = re.lastIndex;
	}
	re.lastIndex = lastIndex;
	return _List_fromArray(out);
});


var _Regex_replaceAtMost = F4(function(n, re, replacer, string)
{
	var count = 0;
	function jsReplacer(match)
	{
		if (count++ >= n)
		{
			return match;
		}
		var i = arguments.length - 3;
		var submatches = new Array(i);
		while (i > 0)
		{
			var submatch = arguments[i];
			submatches[--i] = submatch
				? $elm$core$Maybe$Just(submatch)
				: $elm$core$Maybe$Nothing;
		}
		return replacer(A4($elm$regex$Regex$Match, match, arguments[arguments.length - 2], count, _List_fromArray(submatches)));
	}
	return string.replace(re, jsReplacer);
});

var _Regex_splitAtMost = F3(function(n, re, str)
{
	var string = str;
	var out = [];
	var start = re.lastIndex;
	var restoreLastIndex = re.lastIndex;
	while (n--)
	{
		var result = re.exec(string);
		if (!result) break;
		out.push(string.slice(start, result.index));
		start = re.lastIndex;
	}
	out.push(string.slice(start));
	re.lastIndex = restoreLastIndex;
	return _List_fromArray(out);
});

var _Regex_infinity = Infinity;
var $author$project$Messages$LinkClicked = function (a) {
	return {$: 'LinkClicked', a: a};
};
var $author$project$Messages$UrlChanged = function (a) {
	return {$: 'UrlChanged', a: a};
};
var $elm$core$List$cons = _List_cons;
var $elm$core$Elm$JsArray$foldr = _JsArray_foldr;
var $elm$core$Array$foldr = F3(
	function (func, baseCase, _v0) {
		var tree = _v0.c;
		var tail = _v0.d;
		var helper = F2(
			function (node, acc) {
				if (node.$ === 'SubTree') {
					var subTree = node.a;
					return A3($elm$core$Elm$JsArray$foldr, helper, acc, subTree);
				} else {
					var values = node.a;
					return A3($elm$core$Elm$JsArray$foldr, func, acc, values);
				}
			});
		return A3(
			$elm$core$Elm$JsArray$foldr,
			helper,
			A3($elm$core$Elm$JsArray$foldr, func, baseCase, tail),
			tree);
	});
var $elm$core$Array$toList = function (array) {
	return A3($elm$core$Array$foldr, $elm$core$List$cons, _List_Nil, array);
};
var $elm$core$Dict$foldr = F3(
	function (func, acc, t) {
		foldr:
		while (true) {
			if (t.$ === 'RBEmpty_elm_builtin') {
				return acc;
			} else {
				var key = t.b;
				var value = t.c;
				var left = t.d;
				var right = t.e;
				var $temp$func = func,
					$temp$acc = A3(
					func,
					key,
					value,
					A3($elm$core$Dict$foldr, func, acc, right)),
					$temp$t = left;
				func = $temp$func;
				acc = $temp$acc;
				t = $temp$t;
				continue foldr;
			}
		}
	});
var $elm$core$Dict$toList = function (dict) {
	return A3(
		$elm$core$Dict$foldr,
		F3(
			function (key, value, list) {
				return A2(
					$elm$core$List$cons,
					_Utils_Tuple2(key, value),
					list);
			}),
		_List_Nil,
		dict);
};
var $elm$core$Dict$keys = function (dict) {
	return A3(
		$elm$core$Dict$foldr,
		F3(
			function (key, value, keyList) {
				return A2($elm$core$List$cons, key, keyList);
			}),
		_List_Nil,
		dict);
};
var $elm$core$Set$toList = function (_v0) {
	var dict = _v0.a;
	return $elm$core$Dict$keys(dict);
};
var $elm$core$Basics$EQ = {$: 'EQ'};
var $elm$core$Basics$GT = {$: 'GT'};
var $elm$core$Basics$LT = {$: 'LT'};
var $elm$core$Result$Err = function (a) {
	return {$: 'Err', a: a};
};
var $elm$json$Json$Decode$Failure = F2(
	function (a, b) {
		return {$: 'Failure', a: a, b: b};
	});
var $elm$json$Json$Decode$Field = F2(
	function (a, b) {
		return {$: 'Field', a: a, b: b};
	});
var $elm$json$Json$Decode$Index = F2(
	function (a, b) {
		return {$: 'Index', a: a, b: b};
	});
var $elm$core$Result$Ok = function (a) {
	return {$: 'Ok', a: a};
};
var $elm$json$Json$Decode$OneOf = function (a) {
	return {$: 'OneOf', a: a};
};
var $elm$core$Basics$False = {$: 'False'};
var $elm$core$Basics$add = _Basics_add;
var $elm$core$Maybe$Just = function (a) {
	return {$: 'Just', a: a};
};
var $elm$core$Maybe$Nothing = {$: 'Nothing'};
var $elm$core$String$all = _String_all;
var $elm$core$Basics$and = _Basics_and;
var $elm$core$Basics$append = _Utils_append;
var $elm$json$Json$Encode$encode = _Json_encode;
var $elm$core$String$fromInt = _String_fromNumber;
var $elm$core$String$join = F2(
	function (sep, chunks) {
		return A2(
			_String_join,
			sep,
			_List_toArray(chunks));
	});
var $elm$core$String$split = F2(
	function (sep, string) {
		return _List_fromArray(
			A2(_String_split, sep, string));
	});
var $elm$json$Json$Decode$indent = function (str) {
	return A2(
		$elm$core$String$join,
		'\n    ',
		A2($elm$core$String$split, '\n', str));
};
var $elm$core$List$foldl = F3(
	function (func, acc, list) {
		foldl:
		while (true) {
			if (!list.b) {
				return acc;
			} else {
				var x = list.a;
				var xs = list.b;
				var $temp$func = func,
					$temp$acc = A2(func, x, acc),
					$temp$list = xs;
				func = $temp$func;
				acc = $temp$acc;
				list = $temp$list;
				continue foldl;
			}
		}
	});
var $elm$core$List$length = function (xs) {
	return A3(
		$elm$core$List$foldl,
		F2(
			function (_v0, i) {
				return i + 1;
			}),
		0,
		xs);
};
var $elm$core$List$map2 = _List_map2;
var $elm$core$Basics$le = _Utils_le;
var $elm$core$Basics$sub = _Basics_sub;
var $elm$core$List$rangeHelp = F3(
	function (lo, hi, list) {
		rangeHelp:
		while (true) {
			if (_Utils_cmp(lo, hi) < 1) {
				var $temp$lo = lo,
					$temp$hi = hi - 1,
					$temp$list = A2($elm$core$List$cons, hi, list);
				lo = $temp$lo;
				hi = $temp$hi;
				list = $temp$list;
				continue rangeHelp;
			} else {
				return list;
			}
		}
	});
var $elm$core$List$range = F2(
	function (lo, hi) {
		return A3($elm$core$List$rangeHelp, lo, hi, _List_Nil);
	});
var $elm$core$List$indexedMap = F2(
	function (f, xs) {
		return A3(
			$elm$core$List$map2,
			f,
			A2(
				$elm$core$List$range,
				0,
				$elm$core$List$length(xs) - 1),
			xs);
	});
var $elm$core$Char$toCode = _Char_toCode;
var $elm$core$Char$isLower = function (_char) {
	var code = $elm$core$Char$toCode(_char);
	return (97 <= code) && (code <= 122);
};
var $elm$core$Char$isUpper = function (_char) {
	var code = $elm$core$Char$toCode(_char);
	return (code <= 90) && (65 <= code);
};
var $elm$core$Basics$or = _Basics_or;
var $elm$core$Char$isAlpha = function (_char) {
	return $elm$core$Char$isLower(_char) || $elm$core$Char$isUpper(_char);
};
var $elm$core$Char$isDigit = function (_char) {
	var code = $elm$core$Char$toCode(_char);
	return (code <= 57) && (48 <= code);
};
var $elm$core$Char$isAlphaNum = function (_char) {
	return $elm$core$Char$isLower(_char) || ($elm$core$Char$isUpper(_char) || $elm$core$Char$isDigit(_char));
};
var $elm$core$List$reverse = function (list) {
	return A3($elm$core$List$foldl, $elm$core$List$cons, _List_Nil, list);
};
var $elm$core$String$uncons = _String_uncons;
var $elm$json$Json$Decode$errorOneOf = F2(
	function (i, error) {
		return '\n\n(' + ($elm$core$String$fromInt(i + 1) + (') ' + $elm$json$Json$Decode$indent(
			$elm$json$Json$Decode$errorToString(error))));
	});
var $elm$json$Json$Decode$errorToString = function (error) {
	return A2($elm$json$Json$Decode$errorToStringHelp, error, _List_Nil);
};
var $elm$json$Json$Decode$errorToStringHelp = F2(
	function (error, context) {
		errorToStringHelp:
		while (true) {
			switch (error.$) {
				case 'Field':
					var f = error.a;
					var err = error.b;
					var isSimple = function () {
						var _v1 = $elm$core$String$uncons(f);
						if (_v1.$ === 'Nothing') {
							return false;
						} else {
							var _v2 = _v1.a;
							var _char = _v2.a;
							var rest = _v2.b;
							return $elm$core$Char$isAlpha(_char) && A2($elm$core$String$all, $elm$core$Char$isAlphaNum, rest);
						}
					}();
					var fieldName = isSimple ? ('.' + f) : ('[\'' + (f + '\']'));
					var $temp$error = err,
						$temp$context = A2($elm$core$List$cons, fieldName, context);
					error = $temp$error;
					context = $temp$context;
					continue errorToStringHelp;
				case 'Index':
					var i = error.a;
					var err = error.b;
					var indexName = '[' + ($elm$core$String$fromInt(i) + ']');
					var $temp$error = err,
						$temp$context = A2($elm$core$List$cons, indexName, context);
					error = $temp$error;
					context = $temp$context;
					continue errorToStringHelp;
				case 'OneOf':
					var errors = error.a;
					if (!errors.b) {
						return 'Ran into a Json.Decode.oneOf with no possibilities' + function () {
							if (!context.b) {
								return '!';
							} else {
								return ' at json' + A2(
									$elm$core$String$join,
									'',
									$elm$core$List$reverse(context));
							}
						}();
					} else {
						if (!errors.b.b) {
							var err = errors.a;
							var $temp$error = err,
								$temp$context = context;
							error = $temp$error;
							context = $temp$context;
							continue errorToStringHelp;
						} else {
							var starter = function () {
								if (!context.b) {
									return 'Json.Decode.oneOf';
								} else {
									return 'The Json.Decode.oneOf at json' + A2(
										$elm$core$String$join,
										'',
										$elm$core$List$reverse(context));
								}
							}();
							var introduction = starter + (' failed in the following ' + ($elm$core$String$fromInt(
								$elm$core$List$length(errors)) + ' ways:'));
							return A2(
								$elm$core$String$join,
								'\n\n',
								A2(
									$elm$core$List$cons,
									introduction,
									A2($elm$core$List$indexedMap, $elm$json$Json$Decode$errorOneOf, errors)));
						}
					}
				default:
					var msg = error.a;
					var json = error.b;
					var introduction = function () {
						if (!context.b) {
							return 'Problem with the given value:\n\n';
						} else {
							return 'Problem with the value at json' + (A2(
								$elm$core$String$join,
								'',
								$elm$core$List$reverse(context)) + ':\n\n    ');
						}
					}();
					return introduction + ($elm$json$Json$Decode$indent(
						A2($elm$json$Json$Encode$encode, 4, json)) + ('\n\n' + msg));
			}
		}
	});
var $elm$core$Array$branchFactor = 32;
var $elm$core$Array$Array_elm_builtin = F4(
	function (a, b, c, d) {
		return {$: 'Array_elm_builtin', a: a, b: b, c: c, d: d};
	});
var $elm$core$Elm$JsArray$empty = _JsArray_empty;
var $elm$core$Basics$ceiling = _Basics_ceiling;
var $elm$core$Basics$fdiv = _Basics_fdiv;
var $elm$core$Basics$logBase = F2(
	function (base, number) {
		return _Basics_log(number) / _Basics_log(base);
	});
var $elm$core$Basics$toFloat = _Basics_toFloat;
var $elm$core$Array$shiftStep = $elm$core$Basics$ceiling(
	A2($elm$core$Basics$logBase, 2, $elm$core$Array$branchFactor));
var $elm$core$Array$empty = A4($elm$core$Array$Array_elm_builtin, 0, $elm$core$Array$shiftStep, $elm$core$Elm$JsArray$empty, $elm$core$Elm$JsArray$empty);
var $elm$core$Elm$JsArray$initialize = _JsArray_initialize;
var $elm$core$Array$Leaf = function (a) {
	return {$: 'Leaf', a: a};
};
var $elm$core$Basics$apL = F2(
	function (f, x) {
		return f(x);
	});
var $elm$core$Basics$apR = F2(
	function (x, f) {
		return f(x);
	});
var $elm$core$Basics$eq = _Utils_equal;
var $elm$core$Basics$floor = _Basics_floor;
var $elm$core$Elm$JsArray$length = _JsArray_length;
var $elm$core$Basics$gt = _Utils_gt;
var $elm$core$Basics$max = F2(
	function (x, y) {
		return (_Utils_cmp(x, y) > 0) ? x : y;
	});
var $elm$core$Basics$mul = _Basics_mul;
var $elm$core$Array$SubTree = function (a) {
	return {$: 'SubTree', a: a};
};
var $elm$core$Elm$JsArray$initializeFromList = _JsArray_initializeFromList;
var $elm$core$Array$compressNodes = F2(
	function (nodes, acc) {
		compressNodes:
		while (true) {
			var _v0 = A2($elm$core$Elm$JsArray$initializeFromList, $elm$core$Array$branchFactor, nodes);
			var node = _v0.a;
			var remainingNodes = _v0.b;
			var newAcc = A2(
				$elm$core$List$cons,
				$elm$core$Array$SubTree(node),
				acc);
			if (!remainingNodes.b) {
				return $elm$core$List$reverse(newAcc);
			} else {
				var $temp$nodes = remainingNodes,
					$temp$acc = newAcc;
				nodes = $temp$nodes;
				acc = $temp$acc;
				continue compressNodes;
			}
		}
	});
var $elm$core$Tuple$first = function (_v0) {
	var x = _v0.a;
	return x;
};
var $elm$core$Array$treeFromBuilder = F2(
	function (nodeList, nodeListSize) {
		treeFromBuilder:
		while (true) {
			var newNodeSize = $elm$core$Basics$ceiling(nodeListSize / $elm$core$Array$branchFactor);
			if (newNodeSize === 1) {
				return A2($elm$core$Elm$JsArray$initializeFromList, $elm$core$Array$branchFactor, nodeList).a;
			} else {
				var $temp$nodeList = A2($elm$core$Array$compressNodes, nodeList, _List_Nil),
					$temp$nodeListSize = newNodeSize;
				nodeList = $temp$nodeList;
				nodeListSize = $temp$nodeListSize;
				continue treeFromBuilder;
			}
		}
	});
var $elm$core$Array$builderToArray = F2(
	function (reverseNodeList, builder) {
		if (!builder.nodeListSize) {
			return A4(
				$elm$core$Array$Array_elm_builtin,
				$elm$core$Elm$JsArray$length(builder.tail),
				$elm$core$Array$shiftStep,
				$elm$core$Elm$JsArray$empty,
				builder.tail);
		} else {
			var treeLen = builder.nodeListSize * $elm$core$Array$branchFactor;
			var depth = $elm$core$Basics$floor(
				A2($elm$core$Basics$logBase, $elm$core$Array$branchFactor, treeLen - 1));
			var correctNodeList = reverseNodeList ? $elm$core$List$reverse(builder.nodeList) : builder.nodeList;
			var tree = A2($elm$core$Array$treeFromBuilder, correctNodeList, builder.nodeListSize);
			return A4(
				$elm$core$Array$Array_elm_builtin,
				$elm$core$Elm$JsArray$length(builder.tail) + treeLen,
				A2($elm$core$Basics$max, 5, depth * $elm$core$Array$shiftStep),
				tree,
				builder.tail);
		}
	});
var $elm$core$Basics$idiv = _Basics_idiv;
var $elm$core$Basics$lt = _Utils_lt;
var $elm$core$Array$initializeHelp = F5(
	function (fn, fromIndex, len, nodeList, tail) {
		initializeHelp:
		while (true) {
			if (fromIndex < 0) {
				return A2(
					$elm$core$Array$builderToArray,
					false,
					{nodeList: nodeList, nodeListSize: (len / $elm$core$Array$branchFactor) | 0, tail: tail});
			} else {
				var leaf = $elm$core$Array$Leaf(
					A3($elm$core$Elm$JsArray$initialize, $elm$core$Array$branchFactor, fromIndex, fn));
				var $temp$fn = fn,
					$temp$fromIndex = fromIndex - $elm$core$Array$branchFactor,
					$temp$len = len,
					$temp$nodeList = A2($elm$core$List$cons, leaf, nodeList),
					$temp$tail = tail;
				fn = $temp$fn;
				fromIndex = $temp$fromIndex;
				len = $temp$len;
				nodeList = $temp$nodeList;
				tail = $temp$tail;
				continue initializeHelp;
			}
		}
	});
var $elm$core$Basics$remainderBy = _Basics_remainderBy;
var $elm$core$Array$initialize = F2(
	function (len, fn) {
		if (len <= 0) {
			return $elm$core$Array$empty;
		} else {
			var tailLen = len % $elm$core$Array$branchFactor;
			var tail = A3($elm$core$Elm$JsArray$initialize, tailLen, len - tailLen, fn);
			var initialFromIndex = (len - tailLen) - $elm$core$Array$branchFactor;
			return A5($elm$core$Array$initializeHelp, fn, initialFromIndex, len, _List_Nil, tail);
		}
	});
var $elm$core$Basics$True = {$: 'True'};
var $elm$core$Result$isOk = function (result) {
	if (result.$ === 'Ok') {
		return true;
	} else {
		return false;
	}
};
var $elm$json$Json$Decode$andThen = _Json_andThen;
var $elm$json$Json$Decode$map = _Json_map1;
var $elm$json$Json$Decode$map2 = _Json_map2;
var $elm$json$Json$Decode$succeed = _Json_succeed;
var $elm$virtual_dom$VirtualDom$toHandlerInt = function (handler) {
	switch (handler.$) {
		case 'Normal':
			return 0;
		case 'MayStopPropagation':
			return 1;
		case 'MayPreventDefault':
			return 2;
		default:
			return 3;
	}
};
var $elm$browser$Browser$External = function (a) {
	return {$: 'External', a: a};
};
var $elm$browser$Browser$Internal = function (a) {
	return {$: 'Internal', a: a};
};
var $elm$core$Basics$identity = function (x) {
	return x;
};
var $elm$browser$Browser$Dom$NotFound = function (a) {
	return {$: 'NotFound', a: a};
};
var $elm$url$Url$Http = {$: 'Http'};
var $elm$url$Url$Https = {$: 'Https'};
var $elm$url$Url$Url = F6(
	function (protocol, host, port_, path, query, fragment) {
		return {fragment: fragment, host: host, path: path, port_: port_, protocol: protocol, query: query};
	});
var $elm$core$String$contains = _String_contains;
var $elm$core$String$length = _String_length;
var $elm$core$String$slice = _String_slice;
var $elm$core$String$dropLeft = F2(
	function (n, string) {
		return (n < 1) ? string : A3(
			$elm$core$String$slice,
			n,
			$elm$core$String$length(string),
			string);
	});
var $elm$core$String$indexes = _String_indexes;
var $elm$core$String$isEmpty = function (string) {
	return string === '';
};
var $elm$core$String$left = F2(
	function (n, string) {
		return (n < 1) ? '' : A3($elm$core$String$slice, 0, n, string);
	});
var $elm$core$String$toInt = _String_toInt;
var $elm$url$Url$chompBeforePath = F5(
	function (protocol, path, params, frag, str) {
		if ($elm$core$String$isEmpty(str) || A2($elm$core$String$contains, '@', str)) {
			return $elm$core$Maybe$Nothing;
		} else {
			var _v0 = A2($elm$core$String$indexes, ':', str);
			if (!_v0.b) {
				return $elm$core$Maybe$Just(
					A6($elm$url$Url$Url, protocol, str, $elm$core$Maybe$Nothing, path, params, frag));
			} else {
				if (!_v0.b.b) {
					var i = _v0.a;
					var _v1 = $elm$core$String$toInt(
						A2($elm$core$String$dropLeft, i + 1, str));
					if (_v1.$ === 'Nothing') {
						return $elm$core$Maybe$Nothing;
					} else {
						var port_ = _v1;
						return $elm$core$Maybe$Just(
							A6(
								$elm$url$Url$Url,
								protocol,
								A2($elm$core$String$left, i, str),
								port_,
								path,
								params,
								frag));
					}
				} else {
					return $elm$core$Maybe$Nothing;
				}
			}
		}
	});
var $elm$url$Url$chompBeforeQuery = F4(
	function (protocol, params, frag, str) {
		if ($elm$core$String$isEmpty(str)) {
			return $elm$core$Maybe$Nothing;
		} else {
			var _v0 = A2($elm$core$String$indexes, '/', str);
			if (!_v0.b) {
				return A5($elm$url$Url$chompBeforePath, protocol, '/', params, frag, str);
			} else {
				var i = _v0.a;
				return A5(
					$elm$url$Url$chompBeforePath,
					protocol,
					A2($elm$core$String$dropLeft, i, str),
					params,
					frag,
					A2($elm$core$String$left, i, str));
			}
		}
	});
var $elm$url$Url$chompBeforeFragment = F3(
	function (protocol, frag, str) {
		if ($elm$core$String$isEmpty(str)) {
			return $elm$core$Maybe$Nothing;
		} else {
			var _v0 = A2($elm$core$String$indexes, '?', str);
			if (!_v0.b) {
				return A4($elm$url$Url$chompBeforeQuery, protocol, $elm$core$Maybe$Nothing, frag, str);
			} else {
				var i = _v0.a;
				return A4(
					$elm$url$Url$chompBeforeQuery,
					protocol,
					$elm$core$Maybe$Just(
						A2($elm$core$String$dropLeft, i + 1, str)),
					frag,
					A2($elm$core$String$left, i, str));
			}
		}
	});
var $elm$url$Url$chompAfterProtocol = F2(
	function (protocol, str) {
		if ($elm$core$String$isEmpty(str)) {
			return $elm$core$Maybe$Nothing;
		} else {
			var _v0 = A2($elm$core$String$indexes, '#', str);
			if (!_v0.b) {
				return A3($elm$url$Url$chompBeforeFragment, protocol, $elm$core$Maybe$Nothing, str);
			} else {
				var i = _v0.a;
				return A3(
					$elm$url$Url$chompBeforeFragment,
					protocol,
					$elm$core$Maybe$Just(
						A2($elm$core$String$dropLeft, i + 1, str)),
					A2($elm$core$String$left, i, str));
			}
		}
	});
var $elm$core$String$startsWith = _String_startsWith;
var $elm$url$Url$fromString = function (str) {
	return A2($elm$core$String$startsWith, 'http://', str) ? A2(
		$elm$url$Url$chompAfterProtocol,
		$elm$url$Url$Http,
		A2($elm$core$String$dropLeft, 7, str)) : (A2($elm$core$String$startsWith, 'https://', str) ? A2(
		$elm$url$Url$chompAfterProtocol,
		$elm$url$Url$Https,
		A2($elm$core$String$dropLeft, 8, str)) : $elm$core$Maybe$Nothing);
};
var $elm$core$Basics$never = function (_v0) {
	never:
	while (true) {
		var nvr = _v0.a;
		var $temp$_v0 = nvr;
		_v0 = $temp$_v0;
		continue never;
	}
};
var $elm$core$Task$Perform = function (a) {
	return {$: 'Perform', a: a};
};
var $elm$core$Task$succeed = _Scheduler_succeed;
var $elm$core$Task$init = $elm$core$Task$succeed(_Utils_Tuple0);
var $elm$core$List$foldrHelper = F4(
	function (fn, acc, ctr, ls) {
		if (!ls.b) {
			return acc;
		} else {
			var a = ls.a;
			var r1 = ls.b;
			if (!r1.b) {
				return A2(fn, a, acc);
			} else {
				var b = r1.a;
				var r2 = r1.b;
				if (!r2.b) {
					return A2(
						fn,
						a,
						A2(fn, b, acc));
				} else {
					var c = r2.a;
					var r3 = r2.b;
					if (!r3.b) {
						return A2(
							fn,
							a,
							A2(
								fn,
								b,
								A2(fn, c, acc)));
					} else {
						var d = r3.a;
						var r4 = r3.b;
						var res = (ctr > 500) ? A3(
							$elm$core$List$foldl,
							fn,
							acc,
							$elm$core$List$reverse(r4)) : A4($elm$core$List$foldrHelper, fn, acc, ctr + 1, r4);
						return A2(
							fn,
							a,
							A2(
								fn,
								b,
								A2(
									fn,
									c,
									A2(fn, d, res))));
					}
				}
			}
		}
	});
var $elm$core$List$foldr = F3(
	function (fn, acc, ls) {
		return A4($elm$core$List$foldrHelper, fn, acc, 0, ls);
	});
var $elm$core$List$map = F2(
	function (f, xs) {
		return A3(
			$elm$core$List$foldr,
			F2(
				function (x, acc) {
					return A2(
						$elm$core$List$cons,
						f(x),
						acc);
				}),
			_List_Nil,
			xs);
	});
var $elm$core$Task$andThen = _Scheduler_andThen;
var $elm$core$Task$map = F2(
	function (func, taskA) {
		return A2(
			$elm$core$Task$andThen,
			function (a) {
				return $elm$core$Task$succeed(
					func(a));
			},
			taskA);
	});
var $elm$core$Task$map2 = F3(
	function (func, taskA, taskB) {
		return A2(
			$elm$core$Task$andThen,
			function (a) {
				return A2(
					$elm$core$Task$andThen,
					function (b) {
						return $elm$core$Task$succeed(
							A2(func, a, b));
					},
					taskB);
			},
			taskA);
	});
var $elm$core$Task$sequence = function (tasks) {
	return A3(
		$elm$core$List$foldr,
		$elm$core$Task$map2($elm$core$List$cons),
		$elm$core$Task$succeed(_List_Nil),
		tasks);
};
var $elm$core$Platform$sendToApp = _Platform_sendToApp;
var $elm$core$Task$spawnCmd = F2(
	function (router, _v0) {
		var task = _v0.a;
		return _Scheduler_spawn(
			A2(
				$elm$core$Task$andThen,
				$elm$core$Platform$sendToApp(router),
				task));
	});
var $elm$core$Task$onEffects = F3(
	function (router, commands, state) {
		return A2(
			$elm$core$Task$map,
			function (_v0) {
				return _Utils_Tuple0;
			},
			$elm$core$Task$sequence(
				A2(
					$elm$core$List$map,
					$elm$core$Task$spawnCmd(router),
					commands)));
	});
var $elm$core$Task$onSelfMsg = F3(
	function (_v0, _v1, _v2) {
		return $elm$core$Task$succeed(_Utils_Tuple0);
	});
var $elm$core$Task$cmdMap = F2(
	function (tagger, _v0) {
		var task = _v0.a;
		return $elm$core$Task$Perform(
			A2($elm$core$Task$map, tagger, task));
	});
_Platform_effectManagers['Task'] = _Platform_createManager($elm$core$Task$init, $elm$core$Task$onEffects, $elm$core$Task$onSelfMsg, $elm$core$Task$cmdMap);
var $elm$core$Task$command = _Platform_leaf('Task');
var $elm$core$Task$perform = F2(
	function (toMessage, task) {
		return $elm$core$Task$command(
			$elm$core$Task$Perform(
				A2($elm$core$Task$map, toMessage, task)));
	});
var $elm$browser$Browser$application = _Browser_application;
var $elm$json$Json$Decode$field = _Json_decodeField;
var $author$project$FontSize$Large = {$: 'Large'};
var $author$project$FontSize$Small = {$: 'Small'};
var $author$project$FontSize$XL = {$: 'XL'};
var $author$project$FontSize$XS = {$: 'XS'};
var $author$project$FontSize$XXL = {$: 'XXL'};
var $author$project$FontSize$getDeviceType = function (width) {
	return (width > 1800) ? $author$project$FontSize$XXL : ((width > 1500) ? $author$project$FontSize$XL : ((width > 1100) ? $author$project$FontSize$Large : ((width > 800) ? $author$project$FontSize$Small : $author$project$FontSize$XS)));
};
var $author$project$Main$About = {$: 'About'};
var $author$project$Main$GraphColoring = function (a) {
	return {$: 'GraphColoring', a: a};
};
var $author$project$Main$HomePage = {$: 'HomePage'};
var $author$project$Main$Isomorphic = function (a) {
	return {$: 'Isomorphic', a: a};
};
var $author$project$Main$MaxCut = function (a) {
	return {$: 'MaxCut', a: a};
};
var $author$project$Main$ScreenSize = {$: 'ScreenSize'};
var $author$project$Main$TreeWidth = function (a) {
	return {$: 'TreeWidth', a: a};
};
var $author$project$Main$VertexCover = function (a) {
	return {$: 'VertexCover', a: a};
};
var $author$project$GraphColoring$TwoColor = {$: 'TwoColor'};
var $author$project$GraphColoring$ColorDisplay = F3(
	function (graphA, chosenColor, defaultColor) {
		return {chosenColor: chosenColor, defaultColor: defaultColor, graphA: graphA};
	});
var $author$project$Graph$First = {$: 'First'};
var $author$project$Graph$Graph = F2(
	function (vertices, edges) {
		return {edges: edges, vertices: vertices};
	});
var $author$project$Graph$PolygonCycleDoll = function (a) {
	return {$: 'PolygonCycleDoll', a: a};
};
var $author$project$Graph$Vertex = F4(
	function (name, pos, color, glow) {
		return {color: color, glow: glow, name: name, pos: pos};
	});
var $elm$core$Basics$composeR = F3(
	function (f, g, x) {
		return g(
			f(x));
	});
var $elm_explorations$linear_algebra$Math$Vector3$vec3 = _MJS_v3;
var $author$project$Graph$makelinear = function (n) {
	var divider = n - 1;
	return A2(
		$elm$core$List$map,
		function (y) {
			return A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 0, y, 0);
		},
		A2(
			$elm$core$List$map,
			A2(
				$elm$core$Basics$composeR,
				$elm$core$Basics$toFloat,
				function (y) {
					return y / divider;
				}),
			A2($elm$core$List$range, 0, n - 1)));
};
var $elm$core$Basics$composeL = F3(
	function (g, f, x) {
		return g(
			f(x));
	});
var $elm_explorations$linear_algebra$Math$Matrix4$identity = _MJS_m4x4identity;
var $elm_explorations$linear_algebra$Math$Matrix4$scale = _MJS_m4x4scale;
var $elm_explorations$linear_algebra$Math$Matrix4$transform = _MJS_v3mul4x4;
var $elm_explorations$linear_algebra$Math$Matrix4$translate = _MJS_m4x4translate;
var $author$project$Graph$situateShape = F3(
	function (position, scaleVec, polygon) {
		var translateTrans = A2($elm_explorations$linear_algebra$Math$Matrix4$translate, position, $elm_explorations$linear_algebra$Math$Matrix4$identity);
		var scaleTrans = A2($elm_explorations$linear_algebra$Math$Matrix4$scale, scaleVec, $elm_explorations$linear_algebra$Math$Matrix4$identity);
		return A2(
			$elm$core$List$map,
			A2(
				$elm$core$Basics$composeL,
				$elm_explorations$linear_algebra$Math$Matrix4$transform(translateTrans),
				$elm_explorations$linear_algebra$Math$Matrix4$transform(scaleTrans)),
			polygon);
	});
var $author$project$Graph$linearGrid = F3(
	function (n, position, size) {
		return A3(
			$author$project$Graph$situateShape,
			position,
			size,
			$author$project$Graph$makelinear(n));
	});
var $avh4$elm_color$Color$RgbaSpace = F4(
	function (a, b, c, d) {
		return {$: 'RgbaSpace', a: a, b: b, c: c, d: d};
	});
var $avh4$elm_color$Color$hsla = F4(
	function (hue, sat, light, alpha) {
		var _v0 = _Utils_Tuple3(hue, sat, light);
		var h = _v0.a;
		var s = _v0.b;
		var l = _v0.c;
		var m2 = (l <= 0.5) ? (l * (s + 1)) : ((l + s) - (l * s));
		var m1 = (l * 2) - m2;
		var hueToRgb = function (h__) {
			var h_ = (h__ < 0) ? (h__ + 1) : ((h__ > 1) ? (h__ - 1) : h__);
			return ((h_ * 6) < 1) ? (m1 + (((m2 - m1) * h_) * 6)) : (((h_ * 2) < 1) ? m2 : (((h_ * 3) < 2) ? (m1 + (((m2 - m1) * ((2 / 3) - h_)) * 6)) : m1));
		};
		var b = hueToRgb(h - (1 / 3));
		var g = hueToRgb(h);
		var r = hueToRgb(h + (1 / 3));
		return A4($avh4$elm_color$Color$RgbaSpace, r, g, b, alpha);
	});
var $avh4$elm_color$Color$hsl = F3(
	function (h, s, l) {
		return A4($avh4$elm_color$Color$hsla, h, s, l, 1.0);
	});
var $author$project$Graph$listOfColors = F2(
	function (region, n) {
		var firstRegion = A2(
			$elm$core$List$map,
			function (x) {
				return x / (3 * (n - 1));
			},
			A2(
				$elm$core$List$map,
				$elm$core$Basics$toFloat,
				A2($elm$core$List$range, 0, n - 1)));
		switch (region.$) {
			case 'First':
				return A2(
					$elm$core$List$map,
					function (h) {
						return A3($avh4$elm_color$Color$hsl, h, 1, 0.7);
					},
					firstRegion);
			case 'Second':
				return A2(
					$elm$core$List$map,
					function (h) {
						return A3($avh4$elm_color$Color$hsl, h, 1, 0.5);
					},
					A2(
						$elm$core$List$map,
						function (x) {
							return x + 0.33;
						},
						firstRegion));
			default:
				return A2(
					$elm$core$List$map,
					function (h) {
						return A3($avh4$elm_color$Color$hsl, h, 1, 0.5);
					},
					A2(
						$elm$core$List$map,
						function (x) {
							return x + 0.66;
						},
						firstRegion));
		}
	});
var $author$project$Graph$Edge = F2(
	function (vertexOne, vertexTwo) {
		return {vertexOne: vertexOne, vertexTwo: vertexTwo};
	});
var $author$project$Graph$Second = {$: 'Second'};
var $author$project$Graph$fullyConnectVertices = function (vs) {
	if (!vs.b) {
		return _List_Nil;
	} else {
		if (!vs.b.b) {
			var x = vs.a;
			return _List_Nil;
		} else {
			var x = vs.a;
			var xs = vs.b;
			return _Utils_ap(
				A2(
					$elm$core$List$map,
					$author$project$Graph$Edge(x),
					xs),
				$author$project$Graph$fullyConnectVertices(xs));
		}
	}
};
var $elm$core$List$map3 = _List_map3;
var $elm$core$Basics$pi = _Basics_pi;
var $elm_explorations$linear_algebra$Math$Matrix4$rotate = _MJS_m4x4rotate;
var $author$project$Graph$rotateVector = F2(
	function (v, a) {
		var rotation = A3(
			$elm_explorations$linear_algebra$Math$Matrix4$rotate,
			a,
			A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 0, 0, 1),
			$elm_explorations$linear_algebra$Math$Matrix4$identity);
		return A2($elm_explorations$linear_algebra$Math$Matrix4$transform, rotation, v);
	});
var $author$project$Graph$makePolygon = F2(
	function (startAngle, n) {
		var initialVector = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 1, 0, 0);
		var increment = (2 * $elm$core$Basics$pi) / n;
		var angles = A2(
			$elm$core$List$map,
			A2(
				$elm$core$Basics$composeL,
				A2(
					$elm$core$Basics$composeL,
					$elm$core$Basics$add(startAngle),
					$elm$core$Basics$mul(increment)),
				$elm$core$Basics$toFloat),
			A2($elm$core$List$range, 0, n - 1));
		return A2(
			$elm$core$List$map,
			$author$project$Graph$rotateVector(initialVector),
			angles);
	});
var $author$project$Graph$parametricPolygon = F4(
	function (n, scaleVec, position, startAngle) {
		return A3(
			$author$project$Graph$situateShape,
			position,
			scaleVec,
			A2($author$project$Graph$makePolygon, startAngle, n));
	});
var $elm_explorations$linear_algebra$Math$Vector3$scale = _MJS_v3scale;
var $elm$core$List$head = function (list) {
	if (list.b) {
		var x = list.a;
		var xs = list.b;
		return $elm$core$Maybe$Just(x);
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $elm$core$List$tail = function (list) {
	if (list.b) {
		var x = list.a;
		var xs = list.b;
		return $elm$core$Maybe$Just(xs);
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $author$project$Graph$shiftListCycle = function (xs) {
	var _v0 = $elm$core$List$tail(xs);
	if (_v0.$ === 'Just') {
		var ys = _v0.a;
		var _v1 = $elm$core$List$head(xs);
		if (_v1.$ === 'Just') {
			var h = _v1.a;
			return _Utils_ap(
				ys,
				_List_fromArray(
					[h]));
		} else {
			return _List_Nil;
		}
	} else {
		return _List_Nil;
	}
};
var $author$project$Graph$makeGraph = F4(
	function (graphType, position, size, initialAngle) {
		switch (graphType.$) {
			case 'PolygonCycle':
				var n = graphType.a;
				var vertices = A4(
					$elm$core$List$map3,
					F3(
						function (name, g, c) {
							return A4($author$project$Graph$Vertex, name, g, c, false);
						}),
					A2($elm$core$List$range, 1, n),
					A4($author$project$Graph$parametricPolygon, n, size, position, initialAngle),
					A2($author$project$Graph$listOfColors, $author$project$Graph$First, n));
				return A2(
					$author$project$Graph$Graph,
					vertices,
					A3(
						$elm$core$List$map2,
						$author$project$Graph$Edge,
						vertices,
						$author$project$Graph$shiftListCycle(vertices)));
			case 'PolygonFullyConnected':
				var n = graphType.a;
				var vertices = A4(
					$elm$core$List$map3,
					F3(
						function (name, g, c) {
							return A4($author$project$Graph$Vertex, name, g, c, false);
						}),
					A2($elm$core$List$range, 1, n),
					A4($author$project$Graph$parametricPolygon, n, size, position, initialAngle),
					A2($author$project$Graph$listOfColors, $author$project$Graph$First, n));
				return A2(
					$author$project$Graph$Graph,
					vertices,
					$author$project$Graph$fullyConnectVertices(vertices));
			default:
				var n = graphType.a;
				var verticesSetB = A4(
					$elm$core$List$map3,
					F3(
						function (name, g, c) {
							return A4($author$project$Graph$Vertex, name, g, c, false);
						}),
					A2($elm$core$List$range, n + 1, 2 * n),
					A4(
						$author$project$Graph$parametricPolygon,
						n,
						A2($elm_explorations$linear_algebra$Math$Vector3$scale, 0.5, size),
						position,
						initialAngle),
					A2($author$project$Graph$listOfColors, $author$project$Graph$Second, n));
				var verticesSetA = A4(
					$elm$core$List$map3,
					F3(
						function (name, g, c) {
							return A4($author$project$Graph$Vertex, name, g, c, false);
						}),
					A2($elm$core$List$range, 1, n),
					A4($author$project$Graph$parametricPolygon, n, size, position, initialAngle),
					A2($author$project$Graph$listOfColors, $author$project$Graph$First, n));
				var spokesSetASetB = A3($elm$core$List$map2, $author$project$Graph$Edge, verticesSetA, verticesSetB);
				var edgesCycleSetB = A3(
					$elm$core$List$map2,
					$author$project$Graph$Edge,
					verticesSetB,
					$author$project$Graph$shiftListCycle(verticesSetB));
				var edgesCycleSetA = A3(
					$elm$core$List$map2,
					$author$project$Graph$Edge,
					verticesSetA,
					$author$project$Graph$shiftListCycle(verticesSetA));
				var allVertices = _Utils_ap(verticesSetA, verticesSetB);
				return A2(
					$author$project$Graph$Graph,
					allVertices,
					_Utils_ap(
						edgesCycleSetA,
						_Utils_ap(edgesCycleSetB, spokesSetASetB)));
		}
	});
var $avh4$elm_color$Color$rgb = F3(
	function (r, g, b) {
		return A4($avh4$elm_color$Color$RgbaSpace, r, g, b, 1.0);
	});
var $author$project$Graph$lookUpVertex = F2(
	function (name, vs) {
		lookUpVertex:
		while (true) {
			if (!vs.b) {
				return $elm$core$Maybe$Nothing;
			} else {
				var x = vs.a;
				var xs = vs.b;
				if (_Utils_eq(name, x.name)) {
					return $elm$core$Maybe$Just(x);
				} else {
					var $temp$name = name,
						$temp$vs = xs;
					name = $temp$name;
					vs = $temp$vs;
					continue lookUpVertex;
				}
			}
		}
	});
var $author$project$Graph$updateEdge = F2(
	function (vs, e) {
		var v2 = e.vertexTwo;
		var v1 = e.vertexOne;
		var _v0 = _Utils_Tuple2(
			A2($author$project$Graph$lookUpVertex, v1.name, vs),
			A2($author$project$Graph$lookUpVertex, v2.name, vs));
		if (_v0.a.$ === 'Nothing') {
			var _v1 = _v0.a;
			return A2($author$project$Graph$Edge, v1, v2);
		} else {
			if (_v0.b.$ === 'Nothing') {
				var _v2 = _v0.b;
				return A2($author$project$Graph$Edge, v1, v2);
			} else {
				var ver1 = _v0.a.a;
				var ver2 = _v0.b.a;
				return A2($author$project$Graph$Edge, ver1, ver2);
			}
		}
	});
var $author$project$GraphColoring$colorDisplayA = function () {
	var tupleEdges = _List_fromArray(
		[
			_Utils_Tuple2(1, 5),
			_Utils_Tuple2(1, 6),
			_Utils_Tuple2(1, 7),
			_Utils_Tuple2(2, 5),
			_Utils_Tuple2(2, 6),
			_Utils_Tuple2(2, 8),
			_Utils_Tuple2(3, 5),
			_Utils_Tuple2(3, 7),
			_Utils_Tuple2(3, 8),
			_Utils_Tuple2(4, 6),
			_Utils_Tuple2(4, 7),
			_Utils_Tuple2(4, 8)
		]);
	var linearGridRight = A3(
		$author$project$Graph$linearGrid,
		4,
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 250, 50, 0),
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 0, 120, 0));
	var linearGridLeft = A3(
		$author$project$Graph$linearGrid,
		4,
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 150, 50, 0),
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 0, 120, 0));
	var totalGrid = _Utils_ap(linearGridLeft, linearGridRight);
	var vertices = A4(
		$elm$core$List$map3,
		F3(
			function (name, g, c) {
				return A4($author$project$Graph$Vertex, name, g, c, false);
			}),
		A2($elm$core$List$range, 1, 8),
		totalGrid,
		A2($author$project$Graph$listOfColors, $author$project$Graph$First, 8));
	var initialGraph = A4(
		$author$project$Graph$makeGraph,
		$author$project$Graph$PolygonCycleDoll(4),
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 200, 100, 0),
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 80, 80, 0),
		$elm$core$Basics$pi / 4);
	var whiteVertices = A2(
		$elm$core$List$map,
		function (v) {
			return _Utils_update(
				v,
				{
					color: A3($avh4$elm_color$Color$rgb, 1, 1, 1)
				});
		},
		initialGraph.vertices);
	var createEdge = $author$project$Graph$updateEdge(whiteVertices);
	var newGraph = A2(
		$author$project$Graph$Graph,
		whiteVertices,
		A2($elm$core$List$map, createEdge, initialGraph.edges));
	return A3(
		$author$project$GraphColoring$ColorDisplay,
		newGraph,
		A3($avh4$elm_color$Color$rgb, 1, 1, 1),
		A3($avh4$elm_color$Color$rgb, 1, 1, 1));
}();
var $author$project$GraphColoring$colorDisplayB = function () {
	var initialGraph = A4(
		$author$project$Graph$makeGraph,
		$author$project$Graph$PolygonCycleDoll(5),
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 200, 100, 0),
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 80, 80, 0),
		$elm$core$Basics$pi / 4);
	var whiteVertices = A2(
		$elm$core$List$map,
		function (v) {
			return _Utils_update(
				v,
				{
					color: A3($avh4$elm_color$Color$rgb, 1, 1, 1)
				});
		},
		initialGraph.vertices);
	var createEdge = $author$project$Graph$updateEdge(whiteVertices);
	var newGraph = A2(
		$author$project$Graph$Graph,
		whiteVertices,
		A2($elm$core$List$map, createEdge, initialGraph.edges));
	return A3(
		$author$project$GraphColoring$ColorDisplay,
		newGraph,
		A3($avh4$elm_color$Color$rgb, 1, 1, 1),
		A3($avh4$elm_color$Color$rgb, 1, 1, 1));
}();
var $author$project$GraphColoring$colorDisplaySeries = {colorDisplayA: $author$project$GraphColoring$colorDisplayA, colorDisplayB: $author$project$GraphColoring$colorDisplayB, state: $author$project$GraphColoring$TwoColor};
var $author$project$Isomorphism$Transition = {$: 'Transition'};
var $author$project$Isomorphism$NoCheck = {$: 'NoCheck'};
var $author$project$Isomorphism$NoChoice = {$: 'NoChoice'};
var $elm$core$Basics$compare = _Utils_compare;
var $author$project$Isomorphism$linearGridLeftInPlaceSecond = A3(
	$author$project$Graph$linearGrid,
	4,
	A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 250, 50, 0),
	A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 0, 120, 0));
var $author$project$Isomorphism$linearGridRightInPlaceSecond = A3(
	$author$project$Graph$linearGrid,
	4,
	A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 350, 50, 0),
	A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 0, 120, 0));
var $author$project$Isomorphism$setLeft = _List_fromArray(
	[3, 8, 6, 1]);
var $author$project$Isomorphism$setRight = _List_fromArray(
	[7, 4, 2, 5]);
var $elm$core$List$sortWith = _List_sortWith;
var $author$project$Isomorphism$bipartiteGridInPlaceSecond = function () {
	var rightTupled = A3(
		$elm$core$List$map2,
		F2(
			function (x, y) {
				return _Utils_Tuple2(x, y);
			}),
		$author$project$Isomorphism$setRight,
		$author$project$Isomorphism$linearGridRightInPlaceSecond);
	var leftTupled = A3(
		$elm$core$List$map2,
		F2(
			function (x, y) {
				return _Utils_Tuple2(x, y);
			}),
		$author$project$Isomorphism$setLeft,
		$author$project$Isomorphism$linearGridLeftInPlaceSecond);
	var totalGrid = _Utils_ap(leftTupled, rightTupled);
	return A2(
		$elm$core$List$map,
		function (_v0) {
			var x = _v0.a;
			var y = _v0.b;
			return y;
		},
		A2(
			$elm$core$List$sortWith,
			F2(
				function (t1, t2) {
					return A2($elm$core$Basics$compare, t1.a, t2.a);
				}),
			totalGrid));
}();
var $author$project$Isomorphism$linearGridLeftInPlaceThird = A3(
	$author$project$Graph$linearGrid,
	4,
	A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 250, 250, 0),
	A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 0, 120, 0));
var $author$project$Isomorphism$linearGridRightInPlaceThird = A3(
	$author$project$Graph$linearGrid,
	4,
	A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 350, 250, 0),
	A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 0, 120, 0));
var $author$project$Isomorphism$bipartiteGridInPlaceThird = function () {
	var rightTupled = A3(
		$elm$core$List$map2,
		F2(
			function (x, y) {
				return _Utils_Tuple2(x, y);
			}),
		$author$project$Isomorphism$setRight,
		$author$project$Isomorphism$linearGridRightInPlaceThird);
	var leftTupled = A3(
		$elm$core$List$map2,
		F2(
			function (x, y) {
				return _Utils_Tuple2(x, y);
			}),
		$author$project$Isomorphism$setLeft,
		$author$project$Isomorphism$linearGridLeftInPlaceThird);
	var totalGrid = _Utils_ap(leftTupled, rightTupled);
	return A2(
		$elm$core$List$map,
		function (_v0) {
			var x = _v0.a;
			var y = _v0.b;
			return y;
		},
		A2(
			$elm$core$List$sortWith,
			F2(
				function (t1, t2) {
					return A2($elm$core$Basics$compare, t1.a, t2.a);
				}),
			totalGrid));
}();
var $author$project$Isomorphism$linearGridLeftInPlace = A3(
	$author$project$Graph$linearGrid,
	4,
	A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 50, 50, 0),
	A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 0, 120, 0));
var $author$project$Isomorphism$linearGridRightInPlace = A3(
	$author$project$Graph$linearGrid,
	4,
	A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 150, 50, 0),
	A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 0, 120, 0));
var $author$project$Isomorphism$bipartiteGridInPlace = function () {
	var rightTupled = A3(
		$elm$core$List$map2,
		F2(
			function (x, y) {
				return _Utils_Tuple2(x, y);
			}),
		$author$project$Isomorphism$setRight,
		$author$project$Isomorphism$linearGridRightInPlace);
	var leftTupled = A3(
		$elm$core$List$map2,
		F2(
			function (x, y) {
				return _Utils_Tuple2(x, y);
			}),
		$author$project$Isomorphism$setLeft,
		$author$project$Isomorphism$linearGridLeftInPlace);
	var totalGrid = _Utils_ap(leftTupled, rightTupled);
	return A2(
		$elm$core$List$map,
		function (_v0) {
			var x = _v0.a;
			var y = _v0.b;
			return y;
		},
		A2(
			$elm$core$List$sortWith,
			F2(
				function (t1, t2) {
					return A2($elm$core$Basics$compare, t1.a, t2.a);
				}),
			totalGrid));
}();
var $author$project$Isomorphism$inplaceTransition = function () {
	var graph = A4(
		$author$project$Graph$makeGraph,
		$author$project$Graph$PolygonCycleDoll(4),
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 100, 200, 0),
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 80, 80, 0),
		$elm$core$Basics$pi / 4);
	return {animationOn: false, backupGraph: graph, graph: graph, grid: $author$project$Isomorphism$bipartiteGridInPlace, time: 0.0};
}();
var $author$project$Graph$updatePositionVertex = F2(
	function (ver, position) {
		return A4($author$project$Graph$Vertex, ver.name, position, ver.color, ver.glow);
	});
var $author$project$Graph$morphGraph = F2(
	function (graph, grid) {
		var updatedVertices = A3($elm$core$List$map2, $author$project$Graph$updatePositionVertex, graph.vertices, grid);
		var createEdge = $author$project$Graph$updateEdge(updatedVertices);
		var updatedEdges = A2($elm$core$List$map, createEdge, graph.edges);
		return A2($author$project$Graph$Graph, updatedVertices, updatedEdges);
	});
var $elm$core$Maybe$withDefault = F2(
	function (_default, maybe) {
		if (maybe.$ === 'Just') {
			var value = maybe.a;
			return value;
		} else {
			return _default;
		}
	});
var $author$project$Isomorphism$removeFirstEdge = function (graph) {
	var newEdges = A2(
		$elm$core$Maybe$withDefault,
		_List_Nil,
		$elm$core$List$tail(graph.edges));
	return _Utils_update(
		graph,
		{edges: newEdges});
};
var $author$project$Isomorphism$isomorphicGame = function () {
	var initialGraph = function (pos) {
		return A4(
			$author$project$Graph$makeGraph,
			$author$project$Graph$PolygonCycleDoll(4),
			pos,
			A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 80, 80, 0),
			$elm$core$Basics$pi / 4);
	};
	var removedEdgeGraph = $author$project$Isomorphism$removeFirstEdge(
		A2(
			$author$project$Graph$morphGraph,
			initialGraph(
				A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 300, 300, 0)),
			$author$project$Isomorphism$bipartiteGridInPlaceThird));
	return {
		choiceState: $author$project$Isomorphism$NoChoice,
		gameState: $author$project$Isomorphism$NoCheck,
		graphB: A2(
			$author$project$Graph$morphGraph,
			initialGraph(
				A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 300, 100, 0)),
			$author$project$Isomorphism$bipartiteGridInPlaceSecond),
		graphC: removedEdgeGraph,
		transition: $author$project$Isomorphism$inplaceTransition
	};
}();
var $author$project$Graph$NoToken = {$: 'NoToken'};
var $author$project$Isomorphism$linearGridLeft = A3(
	$author$project$Graph$linearGrid,
	4,
	A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 150, 250, 0),
	A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 0, 120, 0));
var $author$project$Isomorphism$linearGridRight = A3(
	$author$project$Graph$linearGrid,
	4,
	A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 250, 250, 0),
	A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 0, 120, 0));
var $author$project$Isomorphism$bipartiteGrid = function () {
	var rightTupled = A3(
		$elm$core$List$map2,
		F2(
			function (x, y) {
				return _Utils_Tuple2(x, y);
			}),
		$author$project$Isomorphism$setRight,
		$author$project$Isomorphism$linearGridRight);
	var leftTupled = A3(
		$elm$core$List$map2,
		F2(
			function (x, y) {
				return _Utils_Tuple2(x, y);
			}),
		$author$project$Isomorphism$setLeft,
		$author$project$Isomorphism$linearGridLeft);
	var totalGrid = _Utils_ap(leftTupled, rightTupled);
	return A2(
		$elm$core$List$map,
		function (_v0) {
			var x = _v0.a;
			var y = _v0.b;
			return y;
		},
		A2(
			$elm$core$List$sortWith,
			F2(
				function (t1, t2) {
					return A2($elm$core$Basics$compare, t1.a, t2.a);
				}),
			totalGrid));
}();
var $author$project$Isomorphism$isomorphicTransition = function () {
	var initialGraph = A4(
		$author$project$Graph$makeGraph,
		$author$project$Graph$PolygonCycleDoll(4),
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 200, 100, 0),
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 80, 80, 0),
		$elm$core$Basics$pi / 4);
	return {animationOn: false, finalGrid: $author$project$Isomorphism$bipartiteGrid, graphA: initialGraph, graphB: initialGraph, specialToken: $author$project$Graph$NoToken, time: 0.0};
}();
var $author$project$Isomorphism$isomorphicTopic = {isomorphicGame: $author$project$Isomorphism$isomorphicGame, shapeTransition: $author$project$Isomorphism$isomorphicTransition, topicState: $author$project$Isomorphism$Transition};
var $author$project$MaxkCut$TwoCut = {$: 'TwoCut'};
var $elm_explorations$linear_algebra$Math$Vector3$add = _MJS_v3add;
var $author$project$Graph$makeEdgeWithTuple = F2(
	function (tu, vs) {
		var name1 = tu.a;
		var name2 = tu.b;
		var _v1 = _Utils_Tuple2(
			A2($author$project$Graph$lookUpVertex, name1, vs),
			A2($author$project$Graph$lookUpVertex, name2, vs));
		if (_v1.a.$ === 'Nothing') {
			var _v2 = _v1.a;
			return $elm$core$Maybe$Nothing;
		} else {
			if (_v1.b.$ === 'Nothing') {
				var _v3 = _v1.b;
				return $elm$core$Maybe$Nothing;
			} else {
				var vertexOne = _v1.a.a;
				var vertexTwo = _v1.b.a;
				return $elm$core$Maybe$Just(
					A2($author$project$Graph$Edge, vertexOne, vertexTwo));
			}
		}
	});
var $author$project$Graph$makeEdgesWithTuples = F2(
	function (tuples, vertices) {
		makeEdgesWithTuples:
		while (true) {
			if (!tuples.b) {
				return _List_Nil;
			} else {
				var tu = tuples.a;
				var tus = tuples.b;
				var _v1 = A2($author$project$Graph$makeEdgeWithTuple, tu, vertices);
				if (_v1.$ === 'Nothing') {
					var $temp$tuples = tus,
						$temp$vertices = vertices;
					tuples = $temp$tuples;
					vertices = $temp$vertices;
					continue makeEdgesWithTuples;
				} else {
					var edge = _v1.a;
					return A2(
						$elm$core$List$cons,
						edge,
						A2($author$project$Graph$makeEdgesWithTuples, tus, vertices));
				}
			}
		}
	});
var $elm_explorations$linear_algebra$Math$Vector3$sub = _MJS_v3sub;
var $author$project$MaxkCut$maxCutGeometry = function () {
	var verticalShiftGrid = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 0, 90, 0);
	var verticalShift = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 0, 50, 0);
	var setB = _List_fromArray(
		[5, 6, 7, 8]);
	var setA = _List_fromArray(
		[1, 2, 3, 4]);
	var position = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 100, 200, 0);
	var setAGrid = A4(
		$author$project$Graph$parametricPolygon,
		4,
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 50, 30, 0),
		A2($elm_explorations$linear_algebra$Math$Vector3$sub, position, verticalShift),
		$elm$core$Basics$pi / 3);
	var setBGrid = A4(
		$author$project$Graph$parametricPolygon,
		4,
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 50, 30, 0),
		A2($elm_explorations$linear_algebra$Math$Vector3$add, position, verticalShift),
		$elm$core$Basics$pi / 6);
	var vertices = A4(
		$elm$core$List$map3,
		F3(
			function (name, g, c) {
				return A4($author$project$Graph$Vertex, name, g, c, false);
			}),
		_Utils_ap(setA, setB),
		_Utils_ap(setAGrid, setBGrid),
		A2($author$project$Graph$listOfColors, $author$project$Graph$First, 8));
	var horizontalShiftGrid = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 200, 0, 0);
	var setAGridPosition = A2(
		$elm_explorations$linear_algebra$Math$Vector3$add,
		A2(
			$elm_explorations$linear_algebra$Math$Vector3$sub,
			A2($elm_explorations$linear_algebra$Math$Vector3$sub, position, verticalShift),
			verticalShiftGrid),
		horizontalShiftGrid);
	var setAFinalGrid = A4(
		$author$project$Graph$parametricPolygon,
		4,
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 70, 10, 0),
		setAGridPosition,
		$elm$core$Basics$pi / 3);
	var setBGridPosition = A2(
		$elm_explorations$linear_algebra$Math$Vector3$add,
		A2(
			$elm_explorations$linear_algebra$Math$Vector3$add,
			A2($elm_explorations$linear_algebra$Math$Vector3$add, position, verticalShift),
			verticalShiftGrid),
		horizontalShiftGrid);
	var setBFinalGrid = A4(
		$author$project$Graph$parametricPolygon,
		4,
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 70, 10, 0),
		setBGridPosition,
		$elm$core$Basics$pi / 3);
	var edgeTuples = _List_fromArray(
		[
			_Utils_Tuple2(1, 8),
			_Utils_Tuple2(1, 7),
			_Utils_Tuple2(2, 6),
			_Utils_Tuple2(2, 7),
			_Utils_Tuple2(3, 5),
			_Utils_Tuple2(3, 7),
			_Utils_Tuple2(3, 8),
			_Utils_Tuple2(3, 6),
			_Utils_Tuple2(3, 4),
			_Utils_Tuple2(4, 5)
		]);
	var edges = A2($author$project$Graph$makeEdgesWithTuples, edgeTuples, vertices);
	return _Utils_Tuple2(
		A2($author$project$Graph$Graph, vertices, edges),
		_Utils_ap(setAFinalGrid, setBFinalGrid));
}();
var $author$project$MaxkCut$maxcutTransitionA = function () {
	var _v0 = $author$project$MaxkCut$maxCutGeometry;
	var initialGraph = _v0.a;
	var finalGrid = _v0.b;
	return {animationOn: false, finalGrid: finalGrid, graphA: initialGraph, graphB: initialGraph, specialToken: $author$project$Graph$NoToken, time: 0.0};
}();
var $elm$core$Basics$cos = _Basics_cos;
var $elm$core$Tuple$second = function (_v0) {
	var y = _v0.b;
	return y;
};
var $elm$core$Basics$sin = _Basics_sin;
var $author$project$MaxkCut$threeCutGeometry = function () {
	var position = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 200, 180, 0);
	var gridStart = A4(
		$author$project$Graph$parametricPolygon,
		9,
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 80, 80, 0),
		position,
		($elm$core$Basics$pi / 2) - ((2 * $elm$core$Basics$pi) / 9));
	var vertices = A4(
		$elm$core$List$map3,
		F3(
			function (name, g, c) {
				return A4($author$project$Graph$Vertex, name, g, c, false);
			}),
		A2($elm$core$List$range, 1, 9),
		gridStart,
		A2($author$project$Graph$listOfColors, $author$project$Graph$First, 9));
	var edgeTuples = _List_fromArray(
		[
			_Utils_Tuple2(1, 4),
			_Utils_Tuple2(1, 5),
			_Utils_Tuple2(1, 6),
			_Utils_Tuple2(1, 7),
			_Utils_Tuple2(1, 8),
			_Utils_Tuple2(1, 9),
			_Utils_Tuple2(2, 4),
			_Utils_Tuple2(2, 5),
			_Utils_Tuple2(2, 6),
			_Utils_Tuple2(2, 7),
			_Utils_Tuple2(2, 8),
			_Utils_Tuple2(2, 9),
			_Utils_Tuple2(3, 4),
			_Utils_Tuple2(3, 5),
			_Utils_Tuple2(3, 6),
			_Utils_Tuple2(3, 7),
			_Utils_Tuple2(3, 8),
			_Utils_Tuple2(3, 9),
			_Utils_Tuple2(4, 7),
			_Utils_Tuple2(4, 8),
			_Utils_Tuple2(4, 9),
			_Utils_Tuple2(5, 7),
			_Utils_Tuple2(5, 8),
			_Utils_Tuple2(5, 9),
			_Utils_Tuple2(6, 7),
			_Utils_Tuple2(6, 8),
			_Utils_Tuple2(6, 9)
		]);
	var edges = A2($author$project$Graph$makeEdgesWithTuples, edgeTuples, vertices);
	var distance = 100;
	var longVerticalShift = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 0, distance, 0);
	var angle = $elm$core$Basics$pi / 6;
	var horizontalShift = A3(
		$elm_explorations$linear_algebra$Math$Vector3$vec3,
		distance * $elm$core$Basics$cos(angle),
		0,
		0);
	var verticalShift = A3(
		$elm_explorations$linear_algebra$Math$Vector3$vec3,
		0,
		distance * $elm$core$Basics$sin(angle),
		0);
	var modifiedGrid = A2(
		$elm$core$List$map,
		function (t) {
			return (t.a <= 3) ? A2($elm_explorations$linear_algebra$Math$Vector3$add, t.b, longVerticalShift) : (((t.a > 3) && (t.a <= 6)) ? A2(
				$elm_explorations$linear_algebra$Math$Vector3$sub,
				A2($elm_explorations$linear_algebra$Math$Vector3$sub, t.b, horizontalShift),
				verticalShift) : A2(
				$elm_explorations$linear_algebra$Math$Vector3$sub,
				A2($elm_explorations$linear_algebra$Math$Vector3$add, t.b, horizontalShift),
				verticalShift));
		},
		A3(
			$elm$core$List$map2,
			F2(
				function (x, y) {
					return _Utils_Tuple2(x, y);
				}),
			A2($elm$core$List$range, 1, 9),
			gridStart));
	return _Utils_Tuple2(
		A2($author$project$Graph$Graph, vertices, edges),
		modifiedGrid);
}();
var $author$project$MaxkCut$maxcutTransitionB = function () {
	var _v0 = $author$project$MaxkCut$threeCutGeometry;
	var initialGraph = _v0.a;
	var finalGrid = _v0.b;
	return {animationOn: false, finalGrid: finalGrid, graphA: initialGraph, graphB: initialGraph, specialToken: $author$project$Graph$NoToken, time: 0.0};
}();
var $author$project$MaxkCut$maxCutTransition = {state: $author$project$MaxkCut$TwoCut, transitionA: $author$project$MaxkCut$maxcutTransitionA, transitionB: $author$project$MaxkCut$maxcutTransitionB};
var $author$project$TreeWidth$CircularGraph = {$: 'CircularGraph'};
var $elm$core$List$filter = F2(
	function (isGood, list) {
		return A3(
			$elm$core$List$foldr,
			F2(
				function (x, xs) {
					return isGood(x) ? A2($elm$core$List$cons, x, xs) : xs;
				}),
			_List_Nil,
			list);
	});
var $elm$core$List$append = F2(
	function (xs, ys) {
		if (!ys.b) {
			return xs;
		} else {
			return A3($elm$core$List$foldr, $elm$core$List$cons, ys, xs);
		}
	});
var $elm$core$List$concat = function (lists) {
	return A3($elm$core$List$foldr, $elm$core$List$append, _List_Nil, lists);
};
var $elm$core$List$repeatHelp = F3(
	function (result, n, value) {
		repeatHelp:
		while (true) {
			if (n <= 0) {
				return result;
			} else {
				var $temp$result = A2($elm$core$List$cons, value, result),
					$temp$n = n - 1,
					$temp$value = value;
				result = $temp$result;
				n = $temp$n;
				value = $temp$value;
				continue repeatHelp;
			}
		}
	});
var $elm$core$List$repeat = F2(
	function (n, value) {
		return A3($elm$core$List$repeatHelp, _List_Nil, n, value);
	});
var $author$project$Graph$makelinearIn2D = F2(
	function (n, m) {
		var xRange = A2(
			$elm$core$List$map,
			$elm$core$Basics$toFloat,
			A2($elm$core$List$range, 0, m - 1));
		var divider = A2($elm$core$Basics$max, n, m) - 1;
		var scalar = 1 / divider;
		return A2(
			$elm$core$List$map,
			function (v) {
				return A2($elm_explorations$linear_algebra$Math$Vector3$scale, scalar, v);
			},
			A2(
				$elm$core$List$map,
				function (_v0) {
					var x = _v0.a;
					var y = _v0.b;
					return A3($elm_explorations$linear_algebra$Math$Vector3$vec3, x, y, 0);
				},
				$elm$core$List$concat(
					A2(
						$elm$core$List$map,
						A2(
							$elm$core$List$map2,
							F2(
								function (x, y) {
									return _Utils_Tuple2(x, y);
								}),
							xRange),
						A2(
							$elm$core$List$map,
							$elm$core$List$repeat(m),
							A2(
								$elm$core$List$map,
								$elm$core$Basics$toFloat,
								A2($elm$core$List$range, 0, n - 1)))))));
	});
var $elm$core$Tuple$pair = F2(
	function (a, b) {
		return _Utils_Tuple2(a, b);
	});
var $author$project$TreeWidth$treeWidthGrid = function () {
	var size = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 250, 400, 0);
	var presenceList = _List_fromArray(
		[true, false, true, false, false, false, false, false, false, true, false, true, false, true, false, true, false, false, true, false, true, false, true, false, false, true, false, true, false, false, false, false, false, false, true, false, false, false, false, false]);
	var position = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 100, 100, 0);
	return A3(
		$author$project$Graph$situateShape,
		position,
		size,
		A2(
			$elm$core$List$map,
			$elm$core$Tuple$second,
			A2(
				$elm$core$List$filter,
				function (_v0) {
					var x = _v0.a;
					var y = _v0.b;
					return x;
				},
				A3(
					$elm$core$List$map2,
					$elm$core$Tuple$pair,
					presenceList,
					A2($author$project$Graph$makelinearIn2D, 5, 8)))));
}();
var $author$project$TreeWidth$treeWidthDisplay = function () {
	var triples = _List_fromArray(
		[
			_Utils_Tuple3(1, 2, 3),
			_Utils_Tuple3(2, 3, 4),
			_Utils_Tuple3(3, 4, 7),
			_Utils_Tuple3(4, 5, 8),
			_Utils_Tuple3(4, 7, 8),
			_Utils_Tuple3(5, 8, 9),
			_Utils_Tuple3(5, 6, 9),
			_Utils_Tuple3(7, 10, 11),
			_Utils_Tuple3(7, 8, 11),
			_Utils_Tuple3(10, 11, 12)
		]);
	var treeLines = _List_fromArray(
		[
			_Utils_Tuple2(
			_Utils_Tuple3(1, 2, 3),
			_Utils_Tuple3(2, 3, 4)),
			_Utils_Tuple2(
			_Utils_Tuple3(2, 3, 4),
			_Utils_Tuple3(3, 4, 7)),
			_Utils_Tuple2(
			_Utils_Tuple3(3, 4, 7),
			_Utils_Tuple3(4, 7, 8)),
			_Utils_Tuple2(
			_Utils_Tuple3(4, 7, 8),
			_Utils_Tuple3(4, 8, 5)),
			_Utils_Tuple2(
			_Utils_Tuple3(4, 8, 5),
			_Utils_Tuple3(5, 8, 9)),
			_Utils_Tuple2(
			_Utils_Tuple3(5, 8, 9),
			_Utils_Tuple3(5, 6, 9)),
			_Utils_Tuple2(
			_Utils_Tuple3(4, 7, 8),
			_Utils_Tuple3(7, 8, 11)),
			_Utils_Tuple2(
			_Utils_Tuple3(7, 8, 11),
			_Utils_Tuple3(7, 10, 11)),
			_Utils_Tuple2(
			_Utils_Tuple3(7, 10, 11),
			_Utils_Tuple3(10, 11, 12))
		]);
	var shuffleSet = _List_fromArray(
		[9, 8, 11, 12, 10, 7, 3, 1, 2, 4, 5, 6]);
	var gridHoneyComb = $author$project$TreeWidth$treeWidthGrid;
	var edgeTuples = _List_fromArray(
		[
			_Utils_Tuple2(1, 2),
			_Utils_Tuple2(1, 3),
			_Utils_Tuple2(2, 3),
			_Utils_Tuple2(2, 4),
			_Utils_Tuple2(3, 4),
			_Utils_Tuple2(3, 7),
			_Utils_Tuple2(4, 7),
			_Utils_Tuple2(4, 8),
			_Utils_Tuple2(4, 5),
			_Utils_Tuple2(5, 6),
			_Utils_Tuple2(5, 8),
			_Utils_Tuple2(5, 9),
			_Utils_Tuple2(6, 9),
			_Utils_Tuple2(7, 8),
			_Utils_Tuple2(7, 10),
			_Utils_Tuple2(7, 11),
			_Utils_Tuple2(8, 9),
			_Utils_Tuple2(8, 11),
			_Utils_Tuple2(10, 11),
			_Utils_Tuple2(10, 12),
			_Utils_Tuple2(11, 12)
		]);
	var circularStartAngle = 0;
	var circularSizeSmall = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 40, 40, 0);
	var circularSize = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 100, 100, 0);
	var circularPositionSmall = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 350, 50, 0);
	var gridCircularInitialSmall = A4($author$project$Graph$parametricPolygon, 12, circularSizeSmall, circularPositionSmall, circularStartAngle);
	var gridCircularSmall = A2(
		$elm$core$List$map,
		$elm$core$Tuple$second,
		A2(
			$elm$core$List$sortWith,
			F2(
				function (t1, t2) {
					return A2($elm$core$Basics$compare, t1.a, t2.a);
				}),
			A3(
				$elm$core$List$map2,
				F2(
					function (x, y) {
						return _Utils_Tuple2(x, y);
					}),
				shuffleSet,
				gridCircularInitialSmall)));
	var verticesSmall = A4(
		$elm$core$List$map3,
		F3(
			function (name, g, c) {
				return A4($author$project$Graph$Vertex, name, g, c, false);
			}),
		A2($elm$core$List$range, 1, 12),
		gridCircularSmall,
		A2($author$project$Graph$listOfColors, $author$project$Graph$First, 12));
	var edgesSmall = A2($author$project$Graph$makeEdgesWithTuples, edgeTuples, verticesSmall);
	var graphSmall = A2($author$project$Graph$Graph, verticesSmall, edgesSmall);
	var circularPosition = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 200, 200, 0);
	var gridCircularInitial = A4($author$project$Graph$parametricPolygon, 12, circularSize, circularPosition, circularStartAngle);
	var gridCircular = A2(
		$elm$core$List$map,
		$elm$core$Tuple$second,
		A2(
			$elm$core$List$sortWith,
			F2(
				function (t1, t2) {
					return A2($elm$core$Basics$compare, t1.a, t2.a);
				}),
			A3(
				$elm$core$List$map2,
				F2(
					function (x, y) {
						return _Utils_Tuple2(x, y);
					}),
				shuffleSet,
				gridCircularInitial)));
	var vertices = A4(
		$elm$core$List$map3,
		F3(
			function (name, g, c) {
				return A4($author$project$Graph$Vertex, name, g, c, false);
			}),
		A2($elm$core$List$range, 1, 12),
		gridCircular,
		A2($author$project$Graph$listOfColors, $author$project$Graph$First, 12));
	var edges = A2($author$project$Graph$makeEdgesWithTuples, edgeTuples, vertices);
	var graph = A2($author$project$Graph$Graph, vertices, edges);
	return {graph: graph, graphSmall: graphSmall, gridCircular: gridCircular, gridHoneyComb: gridHoneyComb, status: $author$project$TreeWidth$CircularGraph, time: 0.0, treeLines: treeLines, triples: triples};
}();
var $author$project$VertexCover$First = {$: 'First'};
var $author$project$VertexCover$VertexCoverDisplay = F3(
	function (graphA, graphB, state) {
		return {graphA: graphA, graphB: graphB, state: state};
	});
var $author$project$VertexCover$vertexCoverDisplay = function () {
	var graphB = A4(
		$author$project$Graph$makeGraph,
		$author$project$Graph$PolygonCycleDoll(6),
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 200, 100, 0),
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 80, 80, 0),
		(2 * $elm$core$Basics$pi) / 3);
	var graphA = A4(
		$author$project$Graph$makeGraph,
		$author$project$Graph$PolygonCycleDoll(4),
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 200, 100, 0),
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 80, 80, 0),
		$elm$core$Basics$pi / 4);
	return A3($author$project$VertexCover$VertexCoverDisplay, graphA, graphB, $author$project$VertexCover$First);
}();
var $author$project$Main$getTopic = function (url) {
	var _v0 = url.path;
	switch (_v0) {
		case '/isomorphism':
			return $author$project$Main$Isomorphic($author$project$Isomorphism$isomorphicTopic);
		case '/maxkcut':
			return $author$project$Main$MaxCut($author$project$MaxkCut$maxCutTransition);
		case '/coloring':
			return $author$project$Main$GraphColoring($author$project$GraphColoring$colorDisplaySeries);
		case '/vertexcover':
			return $author$project$Main$VertexCover($author$project$VertexCover$vertexCoverDisplay);
		case '/treewidth':
			return $author$project$Main$TreeWidth($author$project$TreeWidth$treeWidthDisplay);
		case '/':
			return $author$project$Main$HomePage;
		case '/size':
			return $author$project$Main$ScreenSize;
		case '/about':
			return $author$project$Main$About;
		default:
			return $author$project$Main$HomePage;
	}
};
var $elm$core$Platform$Cmd$batch = _Platform_batch;
var $elm$core$Platform$Cmd$none = $elm$core$Platform$Cmd$batch(_List_Nil);
var $author$project$Main$init = F3(
	function (flags, url, key) {
		var displaySize = {
			deviceType: $author$project$FontSize$getDeviceType(flags.width),
			height: flags.height,
			width: flags.width
		};
		return _Utils_Tuple2(
			{
				displaySize: displaySize,
				helpStatus: false,
				key: key,
				topic: $author$project$Main$getTopic(url),
				url: url
			},
			$elm$core$Platform$Cmd$none);
	});
var $elm$json$Json$Decode$int = _Json_decodeInt;
var $author$project$Messages$GotNewScreen = F2(
	function (a, b) {
		return {$: 'GotNewScreen', a: a, b: b};
	});
var $author$project$Messages$TimeDelta = function (a) {
	return {$: 'TimeDelta', a: a};
};
var $elm$core$Platform$Sub$batch = _Platform_batch;
var $author$project$Messages$AnimationStartOver = {$: 'AnimationStartOver'};
var $author$project$Messages$AnimationToggle = {$: 'AnimationToggle'};
var $author$project$Messages$GotoAbout = {$: 'GotoAbout'};
var $author$project$Messages$GotoHome = {$: 'GotoHome'};
var $author$project$Messages$GotoSize = {$: 'GotoSize'};
var $author$project$Messages$IsoCheck = {$: 'IsoCheck'};
var $author$project$Messages$IsoChoiceOne = {$: 'IsoChoiceOne'};
var $author$project$Messages$IsoChoiceTwo = {$: 'IsoChoiceTwo'};
var $author$project$Messages$MaxCutLine = {$: 'MaxCutLine'};
var $author$project$Messages$NextAnimation = {$: 'NextAnimation'};
var $author$project$Messages$NextTopic = {$: 'NextTopic'};
var $author$project$Messages$Other = {$: 'Other'};
var $author$project$Messages$PreviousTopic = {$: 'PreviousTopic'};
var $author$project$Messages$PreviousTreeWidthAnimation = {$: 'PreviousTreeWidthAnimation'};
var $author$project$Messages$ToggleHelpStatus = {$: 'ToggleHelpStatus'};
var $author$project$Messages$VertexNonColor = {$: 'VertexNonColor'};
var $author$project$Messages$ToggleVertexStatus = function (a) {
	return {$: 'ToggleVertexStatus', a: a};
};
var $author$project$Main$chooseVertexFromInt = function (x) {
	if (x.$ === 'Nothing') {
		return $author$project$Messages$Other;
	} else {
		var name = x.a;
		return $author$project$Messages$ToggleVertexStatus(name);
	}
};
var $elm$core$String$cons = _String_cons;
var $author$project$Main$keyToMsg = function (value) {
	var _v0 = $elm$core$String$uncons(value);
	if ((_v0.$ === 'Just') && (_v0.a.b === '')) {
		var _v1 = _v0.a;
		var _char = _v1.a;
		var _v2 = $elm$core$Char$isDigit(_char);
		if (_v2) {
			return $author$project$Main$chooseVertexFromInt(
				$elm$core$String$toInt(
					A2($elm$core$String$cons, _char, '')));
		} else {
			switch (_char.valueOf()) {
				case 'r':
					return $author$project$Messages$AnimationStartOver;
				case 'p':
					return $author$project$Messages$AnimationToggle;
				case 'n':
					return $author$project$Messages$NextTopic;
				case 'N':
					return $author$project$Messages$PreviousTopic;
				case 'l':
					return $author$project$Messages$MaxCutLine;
				case 'w':
					return $author$project$Messages$VertexNonColor;
				case 't':
					return $author$project$Messages$NextAnimation;
				case 'T':
					return $author$project$Messages$PreviousTreeWidthAnimation;
				case 'h':
					return $author$project$Messages$ToggleHelpStatus;
				case 'c':
					return $author$project$Messages$GotoHome;
				case 's':
					return $author$project$Messages$GotoSize;
				case 'a':
					return $author$project$Messages$GotoAbout;
				case 'z':
					return $author$project$Messages$IsoChoiceOne;
				case 'Z':
					return $author$project$Messages$IsoChoiceTwo;
				case 'C':
					return $author$project$Messages$IsoCheck;
				default:
					return $author$project$Messages$Other;
			}
		}
	} else {
		return $author$project$Messages$Other;
	}
};
var $elm$json$Json$Decode$string = _Json_decodeString;
var $author$project$Main$keyDecoder = A2(
	$elm$json$Json$Decode$map,
	$author$project$Main$keyToMsg,
	A2($elm$json$Json$Decode$field, 'key', $elm$json$Json$Decode$string));
var $elm$browser$Browser$AnimationManager$Delta = function (a) {
	return {$: 'Delta', a: a};
};
var $elm$browser$Browser$AnimationManager$State = F3(
	function (subs, request, oldTime) {
		return {oldTime: oldTime, request: request, subs: subs};
	});
var $elm$browser$Browser$AnimationManager$init = $elm$core$Task$succeed(
	A3($elm$browser$Browser$AnimationManager$State, _List_Nil, $elm$core$Maybe$Nothing, 0));
var $elm$core$Process$kill = _Scheduler_kill;
var $elm$browser$Browser$AnimationManager$now = _Browser_now(_Utils_Tuple0);
var $elm$browser$Browser$AnimationManager$rAF = _Browser_rAF(_Utils_Tuple0);
var $elm$core$Platform$sendToSelf = _Platform_sendToSelf;
var $elm$core$Process$spawn = _Scheduler_spawn;
var $elm$browser$Browser$AnimationManager$onEffects = F3(
	function (router, subs, _v0) {
		var request = _v0.request;
		var oldTime = _v0.oldTime;
		var _v1 = _Utils_Tuple2(request, subs);
		if (_v1.a.$ === 'Nothing') {
			if (!_v1.b.b) {
				var _v2 = _v1.a;
				return $elm$browser$Browser$AnimationManager$init;
			} else {
				var _v4 = _v1.a;
				return A2(
					$elm$core$Task$andThen,
					function (pid) {
						return A2(
							$elm$core$Task$andThen,
							function (time) {
								return $elm$core$Task$succeed(
									A3(
										$elm$browser$Browser$AnimationManager$State,
										subs,
										$elm$core$Maybe$Just(pid),
										time));
							},
							$elm$browser$Browser$AnimationManager$now);
					},
					$elm$core$Process$spawn(
						A2(
							$elm$core$Task$andThen,
							$elm$core$Platform$sendToSelf(router),
							$elm$browser$Browser$AnimationManager$rAF)));
			}
		} else {
			if (!_v1.b.b) {
				var pid = _v1.a.a;
				return A2(
					$elm$core$Task$andThen,
					function (_v3) {
						return $elm$browser$Browser$AnimationManager$init;
					},
					$elm$core$Process$kill(pid));
			} else {
				return $elm$core$Task$succeed(
					A3($elm$browser$Browser$AnimationManager$State, subs, request, oldTime));
			}
		}
	});
var $elm$time$Time$Posix = function (a) {
	return {$: 'Posix', a: a};
};
var $elm$time$Time$millisToPosix = $elm$time$Time$Posix;
var $elm$browser$Browser$AnimationManager$onSelfMsg = F3(
	function (router, newTime, _v0) {
		var subs = _v0.subs;
		var oldTime = _v0.oldTime;
		var send = function (sub) {
			if (sub.$ === 'Time') {
				var tagger = sub.a;
				return A2(
					$elm$core$Platform$sendToApp,
					router,
					tagger(
						$elm$time$Time$millisToPosix(newTime)));
			} else {
				var tagger = sub.a;
				return A2(
					$elm$core$Platform$sendToApp,
					router,
					tagger(newTime - oldTime));
			}
		};
		return A2(
			$elm$core$Task$andThen,
			function (pid) {
				return A2(
					$elm$core$Task$andThen,
					function (_v1) {
						return $elm$core$Task$succeed(
							A3(
								$elm$browser$Browser$AnimationManager$State,
								subs,
								$elm$core$Maybe$Just(pid),
								newTime));
					},
					$elm$core$Task$sequence(
						A2($elm$core$List$map, send, subs)));
			},
			$elm$core$Process$spawn(
				A2(
					$elm$core$Task$andThen,
					$elm$core$Platform$sendToSelf(router),
					$elm$browser$Browser$AnimationManager$rAF)));
	});
var $elm$browser$Browser$AnimationManager$Time = function (a) {
	return {$: 'Time', a: a};
};
var $elm$browser$Browser$AnimationManager$subMap = F2(
	function (func, sub) {
		if (sub.$ === 'Time') {
			var tagger = sub.a;
			return $elm$browser$Browser$AnimationManager$Time(
				A2($elm$core$Basics$composeL, func, tagger));
		} else {
			var tagger = sub.a;
			return $elm$browser$Browser$AnimationManager$Delta(
				A2($elm$core$Basics$composeL, func, tagger));
		}
	});
_Platform_effectManagers['Browser.AnimationManager'] = _Platform_createManager($elm$browser$Browser$AnimationManager$init, $elm$browser$Browser$AnimationManager$onEffects, $elm$browser$Browser$AnimationManager$onSelfMsg, 0, $elm$browser$Browser$AnimationManager$subMap);
var $elm$browser$Browser$AnimationManager$subscription = _Platform_leaf('Browser.AnimationManager');
var $elm$browser$Browser$AnimationManager$onAnimationFrameDelta = function (tagger) {
	return $elm$browser$Browser$AnimationManager$subscription(
		$elm$browser$Browser$AnimationManager$Delta(tagger));
};
var $elm$browser$Browser$Events$onAnimationFrameDelta = $elm$browser$Browser$AnimationManager$onAnimationFrameDelta;
var $elm$browser$Browser$Events$Document = {$: 'Document'};
var $elm$browser$Browser$Events$MySub = F3(
	function (a, b, c) {
		return {$: 'MySub', a: a, b: b, c: c};
	});
var $elm$browser$Browser$Events$State = F2(
	function (subs, pids) {
		return {pids: pids, subs: subs};
	});
var $elm$core$Dict$RBEmpty_elm_builtin = {$: 'RBEmpty_elm_builtin'};
var $elm$core$Dict$empty = $elm$core$Dict$RBEmpty_elm_builtin;
var $elm$browser$Browser$Events$init = $elm$core$Task$succeed(
	A2($elm$browser$Browser$Events$State, _List_Nil, $elm$core$Dict$empty));
var $elm$browser$Browser$Events$nodeToKey = function (node) {
	if (node.$ === 'Document') {
		return 'd_';
	} else {
		return 'w_';
	}
};
var $elm$browser$Browser$Events$addKey = function (sub) {
	var node = sub.a;
	var name = sub.b;
	return _Utils_Tuple2(
		_Utils_ap(
			$elm$browser$Browser$Events$nodeToKey(node),
			name),
		sub);
};
var $elm$core$Dict$Black = {$: 'Black'};
var $elm$core$Dict$RBNode_elm_builtin = F5(
	function (a, b, c, d, e) {
		return {$: 'RBNode_elm_builtin', a: a, b: b, c: c, d: d, e: e};
	});
var $elm$core$Dict$Red = {$: 'Red'};
var $elm$core$Dict$balance = F5(
	function (color, key, value, left, right) {
		if ((right.$ === 'RBNode_elm_builtin') && (right.a.$ === 'Red')) {
			var _v1 = right.a;
			var rK = right.b;
			var rV = right.c;
			var rLeft = right.d;
			var rRight = right.e;
			if ((left.$ === 'RBNode_elm_builtin') && (left.a.$ === 'Red')) {
				var _v3 = left.a;
				var lK = left.b;
				var lV = left.c;
				var lLeft = left.d;
				var lRight = left.e;
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					$elm$core$Dict$Red,
					key,
					value,
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Black, lK, lV, lLeft, lRight),
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Black, rK, rV, rLeft, rRight));
			} else {
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					color,
					rK,
					rV,
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Red, key, value, left, rLeft),
					rRight);
			}
		} else {
			if ((((left.$ === 'RBNode_elm_builtin') && (left.a.$ === 'Red')) && (left.d.$ === 'RBNode_elm_builtin')) && (left.d.a.$ === 'Red')) {
				var _v5 = left.a;
				var lK = left.b;
				var lV = left.c;
				var _v6 = left.d;
				var _v7 = _v6.a;
				var llK = _v6.b;
				var llV = _v6.c;
				var llLeft = _v6.d;
				var llRight = _v6.e;
				var lRight = left.e;
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					$elm$core$Dict$Red,
					lK,
					lV,
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Black, llK, llV, llLeft, llRight),
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Black, key, value, lRight, right));
			} else {
				return A5($elm$core$Dict$RBNode_elm_builtin, color, key, value, left, right);
			}
		}
	});
var $elm$core$Dict$insertHelp = F3(
	function (key, value, dict) {
		if (dict.$ === 'RBEmpty_elm_builtin') {
			return A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Red, key, value, $elm$core$Dict$RBEmpty_elm_builtin, $elm$core$Dict$RBEmpty_elm_builtin);
		} else {
			var nColor = dict.a;
			var nKey = dict.b;
			var nValue = dict.c;
			var nLeft = dict.d;
			var nRight = dict.e;
			var _v1 = A2($elm$core$Basics$compare, key, nKey);
			switch (_v1.$) {
				case 'LT':
					return A5(
						$elm$core$Dict$balance,
						nColor,
						nKey,
						nValue,
						A3($elm$core$Dict$insertHelp, key, value, nLeft),
						nRight);
				case 'EQ':
					return A5($elm$core$Dict$RBNode_elm_builtin, nColor, nKey, value, nLeft, nRight);
				default:
					return A5(
						$elm$core$Dict$balance,
						nColor,
						nKey,
						nValue,
						nLeft,
						A3($elm$core$Dict$insertHelp, key, value, nRight));
			}
		}
	});
var $elm$core$Dict$insert = F3(
	function (key, value, dict) {
		var _v0 = A3($elm$core$Dict$insertHelp, key, value, dict);
		if ((_v0.$ === 'RBNode_elm_builtin') && (_v0.a.$ === 'Red')) {
			var _v1 = _v0.a;
			var k = _v0.b;
			var v = _v0.c;
			var l = _v0.d;
			var r = _v0.e;
			return A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Black, k, v, l, r);
		} else {
			var x = _v0;
			return x;
		}
	});
var $elm$core$Dict$fromList = function (assocs) {
	return A3(
		$elm$core$List$foldl,
		F2(
			function (_v0, dict) {
				var key = _v0.a;
				var value = _v0.b;
				return A3($elm$core$Dict$insert, key, value, dict);
			}),
		$elm$core$Dict$empty,
		assocs);
};
var $elm$core$Dict$foldl = F3(
	function (func, acc, dict) {
		foldl:
		while (true) {
			if (dict.$ === 'RBEmpty_elm_builtin') {
				return acc;
			} else {
				var key = dict.b;
				var value = dict.c;
				var left = dict.d;
				var right = dict.e;
				var $temp$func = func,
					$temp$acc = A3(
					func,
					key,
					value,
					A3($elm$core$Dict$foldl, func, acc, left)),
					$temp$dict = right;
				func = $temp$func;
				acc = $temp$acc;
				dict = $temp$dict;
				continue foldl;
			}
		}
	});
var $elm$core$Dict$merge = F6(
	function (leftStep, bothStep, rightStep, leftDict, rightDict, initialResult) {
		var stepState = F3(
			function (rKey, rValue, _v0) {
				stepState:
				while (true) {
					var list = _v0.a;
					var result = _v0.b;
					if (!list.b) {
						return _Utils_Tuple2(
							list,
							A3(rightStep, rKey, rValue, result));
					} else {
						var _v2 = list.a;
						var lKey = _v2.a;
						var lValue = _v2.b;
						var rest = list.b;
						if (_Utils_cmp(lKey, rKey) < 0) {
							var $temp$rKey = rKey,
								$temp$rValue = rValue,
								$temp$_v0 = _Utils_Tuple2(
								rest,
								A3(leftStep, lKey, lValue, result));
							rKey = $temp$rKey;
							rValue = $temp$rValue;
							_v0 = $temp$_v0;
							continue stepState;
						} else {
							if (_Utils_cmp(lKey, rKey) > 0) {
								return _Utils_Tuple2(
									list,
									A3(rightStep, rKey, rValue, result));
							} else {
								return _Utils_Tuple2(
									rest,
									A4(bothStep, lKey, lValue, rValue, result));
							}
						}
					}
				}
			});
		var _v3 = A3(
			$elm$core$Dict$foldl,
			stepState,
			_Utils_Tuple2(
				$elm$core$Dict$toList(leftDict),
				initialResult),
			rightDict);
		var leftovers = _v3.a;
		var intermediateResult = _v3.b;
		return A3(
			$elm$core$List$foldl,
			F2(
				function (_v4, result) {
					var k = _v4.a;
					var v = _v4.b;
					return A3(leftStep, k, v, result);
				}),
			intermediateResult,
			leftovers);
	});
var $elm$browser$Browser$Events$Event = F2(
	function (key, event) {
		return {event: event, key: key};
	});
var $elm$browser$Browser$Events$spawn = F3(
	function (router, key, _v0) {
		var node = _v0.a;
		var name = _v0.b;
		var actualNode = function () {
			if (node.$ === 'Document') {
				return _Browser_doc;
			} else {
				return _Browser_window;
			}
		}();
		return A2(
			$elm$core$Task$map,
			function (value) {
				return _Utils_Tuple2(key, value);
			},
			A3(
				_Browser_on,
				actualNode,
				name,
				function (event) {
					return A2(
						$elm$core$Platform$sendToSelf,
						router,
						A2($elm$browser$Browser$Events$Event, key, event));
				}));
	});
var $elm$core$Dict$union = F2(
	function (t1, t2) {
		return A3($elm$core$Dict$foldl, $elm$core$Dict$insert, t2, t1);
	});
var $elm$browser$Browser$Events$onEffects = F3(
	function (router, subs, state) {
		var stepRight = F3(
			function (key, sub, _v6) {
				var deads = _v6.a;
				var lives = _v6.b;
				var news = _v6.c;
				return _Utils_Tuple3(
					deads,
					lives,
					A2(
						$elm$core$List$cons,
						A3($elm$browser$Browser$Events$spawn, router, key, sub),
						news));
			});
		var stepLeft = F3(
			function (_v4, pid, _v5) {
				var deads = _v5.a;
				var lives = _v5.b;
				var news = _v5.c;
				return _Utils_Tuple3(
					A2($elm$core$List$cons, pid, deads),
					lives,
					news);
			});
		var stepBoth = F4(
			function (key, pid, _v2, _v3) {
				var deads = _v3.a;
				var lives = _v3.b;
				var news = _v3.c;
				return _Utils_Tuple3(
					deads,
					A3($elm$core$Dict$insert, key, pid, lives),
					news);
			});
		var newSubs = A2($elm$core$List$map, $elm$browser$Browser$Events$addKey, subs);
		var _v0 = A6(
			$elm$core$Dict$merge,
			stepLeft,
			stepBoth,
			stepRight,
			state.pids,
			$elm$core$Dict$fromList(newSubs),
			_Utils_Tuple3(_List_Nil, $elm$core$Dict$empty, _List_Nil));
		var deadPids = _v0.a;
		var livePids = _v0.b;
		var makeNewPids = _v0.c;
		return A2(
			$elm$core$Task$andThen,
			function (pids) {
				return $elm$core$Task$succeed(
					A2(
						$elm$browser$Browser$Events$State,
						newSubs,
						A2(
							$elm$core$Dict$union,
							livePids,
							$elm$core$Dict$fromList(pids))));
			},
			A2(
				$elm$core$Task$andThen,
				function (_v1) {
					return $elm$core$Task$sequence(makeNewPids);
				},
				$elm$core$Task$sequence(
					A2($elm$core$List$map, $elm$core$Process$kill, deadPids))));
	});
var $elm$core$List$maybeCons = F3(
	function (f, mx, xs) {
		var _v0 = f(mx);
		if (_v0.$ === 'Just') {
			var x = _v0.a;
			return A2($elm$core$List$cons, x, xs);
		} else {
			return xs;
		}
	});
var $elm$core$List$filterMap = F2(
	function (f, xs) {
		return A3(
			$elm$core$List$foldr,
			$elm$core$List$maybeCons(f),
			_List_Nil,
			xs);
	});
var $elm$browser$Browser$Events$onSelfMsg = F3(
	function (router, _v0, state) {
		var key = _v0.key;
		var event = _v0.event;
		var toMessage = function (_v2) {
			var subKey = _v2.a;
			var _v3 = _v2.b;
			var node = _v3.a;
			var name = _v3.b;
			var decoder = _v3.c;
			return _Utils_eq(subKey, key) ? A2(_Browser_decodeEvent, decoder, event) : $elm$core$Maybe$Nothing;
		};
		var messages = A2($elm$core$List$filterMap, toMessage, state.subs);
		return A2(
			$elm$core$Task$andThen,
			function (_v1) {
				return $elm$core$Task$succeed(state);
			},
			$elm$core$Task$sequence(
				A2(
					$elm$core$List$map,
					$elm$core$Platform$sendToApp(router),
					messages)));
	});
var $elm$browser$Browser$Events$subMap = F2(
	function (func, _v0) {
		var node = _v0.a;
		var name = _v0.b;
		var decoder = _v0.c;
		return A3(
			$elm$browser$Browser$Events$MySub,
			node,
			name,
			A2($elm$json$Json$Decode$map, func, decoder));
	});
_Platform_effectManagers['Browser.Events'] = _Platform_createManager($elm$browser$Browser$Events$init, $elm$browser$Browser$Events$onEffects, $elm$browser$Browser$Events$onSelfMsg, 0, $elm$browser$Browser$Events$subMap);
var $elm$browser$Browser$Events$subscription = _Platform_leaf('Browser.Events');
var $elm$browser$Browser$Events$on = F3(
	function (node, name, decoder) {
		return $elm$browser$Browser$Events$subscription(
			A3($elm$browser$Browser$Events$MySub, node, name, decoder));
	});
var $elm$browser$Browser$Events$onKeyPress = A2($elm$browser$Browser$Events$on, $elm$browser$Browser$Events$Document, 'keypress');
var $elm$browser$Browser$Events$Window = {$: 'Window'};
var $elm$browser$Browser$Events$onResize = function (func) {
	return A3(
		$elm$browser$Browser$Events$on,
		$elm$browser$Browser$Events$Window,
		'resize',
		A2(
			$elm$json$Json$Decode$field,
			'target',
			A3(
				$elm$json$Json$Decode$map2,
				func,
				A2($elm$json$Json$Decode$field, 'innerWidth', $elm$json$Json$Decode$int),
				A2($elm$json$Json$Decode$field, 'innerHeight', $elm$json$Json$Decode$int))));
};
var $author$project$Main$subscription = function (_v0) {
	return $elm$core$Platform$Sub$batch(
		_List_fromArray(
			[
				$elm$browser$Browser$Events$onAnimationFrameDelta($author$project$Messages$TimeDelta),
				$elm$browser$Browser$Events$onKeyPress($author$project$Main$keyDecoder),
				$elm$browser$Browser$Events$onResize(
				F2(
					function (w, h) {
						return A2($author$project$Messages$GotNewScreen, w, h);
					}))
			]));
};
var $author$project$Isomorphism$Game = {$: 'Game'};
var $author$project$Graph$changeGlowVertex = F3(
	function (status, name, graph) {
		var new_vertices = function (vs) {
			if (!vs.b) {
				return _List_Nil;
			} else {
				var x = vs.a;
				var xs = vs.b;
				return A2(
					$elm$core$List$cons,
					_Utils_eq(x.name, name) ? _Utils_update(
						x,
						{glow: status}) : x,
					new_vertices(xs));
			}
		};
		return A2(
			$author$project$Graph$Graph,
			new_vertices(graph.vertices),
			graph.edges);
	});
var $elm_explorations$linear_algebra$Math$Vector3$distance = _MJS_v3distance;
var $elm$core$List$sum = function (numbers) {
	return A3($elm$core$List$foldl, $elm$core$Basics$add, 0, numbers);
};
var $author$project$Graph$distanceBetweenGraphAndGrid = F2(
	function (graph, grid) {
		var listOfDistances = A3(
			$elm$core$List$map2,
			F2(
				function (ver, pos) {
					return A2($elm_explorations$linear_algebra$Math$Vector3$distance, pos, ver.pos);
				}),
			graph.vertices,
			grid);
		return $elm$core$List$sum(listOfDistances);
	});
var $author$project$Graph$advanceVertexTowardsPosition = F3(
	function (time, vertex, position) {
		var dif = A2($elm_explorations$linear_algebra$Math$Vector3$sub, position, vertex.pos);
		return A2(
			$elm_explorations$linear_algebra$Math$Vector3$add,
			vertex.pos,
			A2($elm_explorations$linear_algebra$Math$Vector3$scale, time, dif));
	});
var $author$project$Graph$calcNextGrid = F3(
	function (graph, grid, time) {
		return A3(
			$elm$core$List$map2,
			$author$project$Graph$advanceVertexTowardsPosition(time),
			graph.vertices,
			grid);
	});
var $author$project$Graph$moveTowards = F3(
	function (time, graph, grid) {
		var intermediateGrid = A3($author$project$Graph$calcNextGrid, graph, grid, time);
		return A2($author$project$Graph$morphGraph, graph, intermediateGrid);
	});
var $author$project$Graph$executeShapeTransition = F2(
	function (delta, shapeTransition) {
		if (A2($author$project$Graph$distanceBetweenGraphAndGrid, shapeTransition.graphB, shapeTransition.finalGrid) < 10) {
			return _Utils_update(
				shapeTransition,
				{
					animationOn: false,
					graphB: A2($author$project$Graph$morphGraph, shapeTransition.graphB, shapeTransition.finalGrid),
					time: 0.0
				});
		} else {
			var accumulatedTime = shapeTransition.time + delta;
			var calculatedTime = delta / (2000 - (0.78 * accumulatedTime));
			return _Utils_update(
				shapeTransition,
				{
					graphB: A3($author$project$Graph$moveTowards, calculatedTime, shapeTransition.graphB, shapeTransition.finalGrid),
					time: accumulatedTime
				});
		}
	});
var $author$project$Graph$makeUnglowAllVertices = function (graph) {
	var new_vertices = function (vs) {
		if (!vs.b) {
			return _List_Nil;
		} else {
			var x = vs.a;
			var xs = vs.b;
			return A2(
				$elm$core$List$cons,
				_Utils_update(
					x,
					{glow: false}),
				new_vertices(xs));
		}
	};
	return A2(
		$author$project$Graph$Graph,
		new_vertices(graph.vertices),
		graph.edges);
};
var $author$project$Graph$makeUnglowAllVerticesBut = F2(
	function (name, graph) {
		var new_vertices = function (vs) {
			if (!vs.b) {
				return _List_Nil;
			} else {
				var x = vs.a;
				var xs = vs.b;
				return A2(
					$elm$core$List$cons,
					_Utils_eq(x.name, name) ? x : _Utils_update(
						x,
						{glow: false}),
					new_vertices(xs));
			}
		};
		return A2(
			$author$project$Graph$Graph,
			new_vertices(graph.vertices),
			graph.edges);
	});
var $elm$core$Basics$not = _Basics_not;
var $author$project$Graph$toggleGlowVertex = F2(
	function (name, graph) {
		var new_vertices = function (vs) {
			if (!vs.b) {
				return _List_Nil;
			} else {
				var x = vs.a;
				var xs = vs.b;
				return A2(
					$elm$core$List$cons,
					_Utils_eq(x.name, name) ? _Utils_update(
						x,
						{glow: !x.glow}) : x,
					new_vertices(xs));
			}
		};
		return A2(
			$author$project$Graph$Graph,
			new_vertices(graph.vertices),
			graph.edges);
	});
var $author$project$Isomorphism$animateIsomorphicTransition = F2(
	function (msg, shapeTransition) {
		switch (msg.$) {
			case 'TimeDelta':
				var delta = msg.a;
				var _v1 = shapeTransition.animationOn;
				if (_v1) {
					return A2($author$project$Graph$executeShapeTransition, delta, shapeTransition);
				} else {
					return shapeTransition;
				}
			case 'HoverOver':
				var name = msg.a;
				return _Utils_update(
					shapeTransition,
					{
						graphA: A3(
							$author$project$Graph$changeGlowVertex,
							true,
							name,
							$author$project$Graph$makeUnglowAllVertices(shapeTransition.graphA)),
						graphB: A3(
							$author$project$Graph$changeGlowVertex,
							true,
							name,
							$author$project$Graph$makeUnglowAllVertices(shapeTransition.graphB))
					});
			case 'MouseOut':
				var name = msg.a;
				return _Utils_update(
					shapeTransition,
					{
						graphA: A3($author$project$Graph$changeGlowVertex, false, name, shapeTransition.graphA),
						graphB: A3($author$project$Graph$changeGlowVertex, false, name, shapeTransition.graphB)
					});
			case 'ToggleVertexStatus':
				var name = msg.a;
				return _Utils_update(
					shapeTransition,
					{
						graphA: A2(
							$author$project$Graph$toggleGlowVertex,
							name,
							A2($author$project$Graph$makeUnglowAllVerticesBut, name, shapeTransition.graphA)),
						graphB: A2(
							$author$project$Graph$toggleGlowVertex,
							name,
							A2($author$project$Graph$makeUnglowAllVerticesBut, name, shapeTransition.graphB))
					});
			case 'AnimationToggle':
				return _Utils_update(
					shapeTransition,
					{animationOn: !shapeTransition.animationOn});
			case 'AnimationStartOver':
				return _Utils_update(
					shapeTransition,
					{graphB: shapeTransition.graphA, time: 0.0});
			case 'Other':
				return shapeTransition;
			case 'NextTopic':
				return shapeTransition;
			default:
				return shapeTransition;
		}
	});
var $author$project$Isomorphism$Check = {$: 'Check'};
var $author$project$Isomorphism$FirstGraph = {$: 'FirstGraph'};
var $author$project$Isomorphism$SecondGraph = {$: 'SecondGraph'};
var $author$project$Graph$executeInPlaceShapeTransition = F2(
	function (delta, inplaceTrans) {
		if (A2($author$project$Graph$distanceBetweenGraphAndGrid, inplaceTrans.graph, inplaceTrans.grid) < 10) {
			return _Utils_update(
				inplaceTrans,
				{
					animationOn: false,
					graph: A2($author$project$Graph$morphGraph, inplaceTrans.graph, inplaceTrans.grid),
					time: 0.0
				});
		} else {
			var accumulatedTime = inplaceTrans.time + delta;
			var calculatedTime = delta / (2000 - (0.78 * accumulatedTime));
			return _Utils_update(
				inplaceTrans,
				{
					graph: A3($author$project$Graph$moveTowards, calculatedTime, inplaceTrans.graph, inplaceTrans.grid),
					time: accumulatedTime
				});
		}
	});
var $author$project$Isomorphism$animateIsomorphicGameTrans = F2(
	function (msg, inPlaceTran) {
		switch (msg.$) {
			case 'TimeDelta':
				var delta = msg.a;
				var _v1 = inPlaceTran.animationOn;
				if (_v1) {
					return A2($author$project$Graph$executeInPlaceShapeTransition, delta, inPlaceTran);
				} else {
					return inPlaceTran;
				}
			case 'AnimationStartOver':
				return _Utils_update(
					inPlaceTran,
					{graph: inPlaceTran.backupGraph, time: 0.0});
			default:
				return inPlaceTran;
		}
	});
var $author$project$Isomorphism$getNewGame = F2(
	function (msg, game) {
		switch (msg.$) {
			case 'IsoChoiceOne':
				return _Utils_update(
					game,
					{
						choiceState: $author$project$Isomorphism$FirstGraph,
						gameState: $author$project$Isomorphism$NoCheck,
						graphB: A3($author$project$Graph$changeGlowVertex, false, 1, game.graphB),
						graphC: A3($author$project$Graph$changeGlowVertex, false, 1, game.graphC),
						transition: A2($author$project$Isomorphism$animateIsomorphicGameTrans, $author$project$Messages$AnimationStartOver, game.transition)
					});
			case 'IsoChoiceTwo':
				return _Utils_update(
					game,
					{
						choiceState: $author$project$Isomorphism$SecondGraph,
						gameState: $author$project$Isomorphism$NoCheck,
						graphB: A3($author$project$Graph$changeGlowVertex, false, 1, game.graphB),
						graphC: A3($author$project$Graph$changeGlowVertex, false, 1, game.graphC),
						transition: A2($author$project$Isomorphism$animateIsomorphicGameTrans, $author$project$Messages$AnimationStartOver, game.transition)
					});
			case 'HoverOver':
				var name = msg.a;
				var _v1 = game.gameState;
				if (_v1.$ === 'NoCheck') {
					var transition = game.transition;
					return _Utils_update(
						game,
						{
							graphB: A3(
								$author$project$Graph$changeGlowVertex,
								true,
								name,
								$author$project$Graph$makeUnglowAllVertices(game.graphB)),
							graphC: A3(
								$author$project$Graph$changeGlowVertex,
								true,
								name,
								$author$project$Graph$makeUnglowAllVertices(game.graphC)),
							transition: _Utils_update(
								transition,
								{
									graph: A3(
										$author$project$Graph$changeGlowVertex,
										true,
										name,
										$author$project$Graph$makeUnglowAllVertices(transition.graph))
								})
						});
				} else {
					return game;
				}
			case 'MouseOut':
				var name = msg.a;
				var _v2 = game.gameState;
				if (_v2.$ === 'NoCheck') {
					var transition = game.transition;
					return _Utils_update(
						game,
						{
							graphB: A3($author$project$Graph$changeGlowVertex, false, name, game.graphB),
							graphC: A3($author$project$Graph$changeGlowVertex, false, name, game.graphC),
							transition: function () {
								var graph = $author$project$Graph$makeUnglowAllVertices(transition.graph);
								return _Utils_update(
									transition,
									{graph: graph});
							}()
						});
				} else {
					return game;
				}
			case 'IsoCheck':
				var transition = game.transition;
				var gameState = game.gameState;
				return _Utils_update(
					game,
					{
						gameState: _Utils_eq(gameState, $author$project$Isomorphism$NoCheck) ? $author$project$Isomorphism$Check : $author$project$Isomorphism$NoCheck,
						graphB: _Utils_eq(game.choiceState, $author$project$Isomorphism$NoChoice) ? game.graphB : A3($author$project$Graph$changeGlowVertex, true, 1, game.graphB),
						graphC: _Utils_eq(game.choiceState, $author$project$Isomorphism$NoChoice) ? game.graphC : A3($author$project$Graph$changeGlowVertex, true, 1, game.graphC),
						transition: _Utils_update(
							transition,
							{
								animationOn: _Utils_eq(game.choiceState, $author$project$Isomorphism$NoChoice) ? transition.animationOn : (!transition.animationOn),
								graph: _Utils_eq(game.choiceState, $author$project$Isomorphism$NoChoice) ? transition.graph : A3($author$project$Graph$changeGlowVertex, true, 1, transition.graph)
							})
					});
			case 'IsoReset':
				return $author$project$Isomorphism$isomorphicGame;
			default:
				var transition = A2($author$project$Isomorphism$animateIsomorphicGameTrans, msg, game.transition);
				return _Utils_update(
					game,
					{transition: transition});
		}
	});
var $author$project$Isomorphism$animateIsomorphicTopic = F2(
	function (msg, topic) {
		if (msg.$ === 'NextAnimation') {
			var _v1 = topic.topicState;
			if (_v1.$ === 'Transition') {
				return _Utils_update(
					topic,
					{topicState: $author$project$Isomorphism$Game});
			} else {
				return _Utils_update(
					topic,
					{topicState: $author$project$Isomorphism$Transition});
			}
		} else {
			var _v2 = topic.topicState;
			if (_v2.$ === 'Transition') {
				var shapeTransition = A2($author$project$Isomorphism$animateIsomorphicTransition, msg, topic.shapeTransition);
				return _Utils_update(
					topic,
					{shapeTransition: shapeTransition});
			} else {
				var newGame = A2($author$project$Isomorphism$getNewGame, msg, topic.isomorphicGame);
				return _Utils_update(
					topic,
					{isomorphicGame: newGame});
			}
		}
	});
var $author$project$MaxkCut$ThreeCut = {$: 'ThreeCut'};
var $author$project$Graph$MakeKCut = {$: 'MakeKCut'};
var $author$project$MaxkCut$toggleToken = function (token) {
	if (token.$ === 'MakeKCut') {
		return $author$project$Graph$NoToken;
	} else {
		return $author$project$Graph$MakeKCut;
	}
};
var $author$project$MaxkCut$animateMaxCutTransition = F2(
	function (msg, shapeTransition) {
		switch (msg.$) {
			case 'TimeDelta':
				var delta = msg.a;
				var _v1 = shapeTransition.animationOn;
				if (_v1) {
					return A2($author$project$Graph$executeShapeTransition, delta, shapeTransition);
				} else {
					return shapeTransition;
				}
			case 'AnimationToggle':
				return _Utils_update(
					shapeTransition,
					{animationOn: !shapeTransition.animationOn});
			case 'AnimationStartOver':
				return _Utils_update(
					shapeTransition,
					{graphB: shapeTransition.graphA, time: 0.0});
			case 'MaxCutLine':
				return _Utils_update(
					shapeTransition,
					{
						specialToken: $author$project$MaxkCut$toggleToken(shapeTransition.specialToken)
					});
			default:
				return shapeTransition;
		}
	});
var $author$project$MaxkCut$animateMaxCutCompound = F2(
	function (msg, maxCutTrans) {
		if (msg.$ === 'NextAnimation') {
			var newState = function () {
				var _v1 = maxCutTrans.state;
				if (_v1.$ === 'TwoCut') {
					return $author$project$MaxkCut$ThreeCut;
				} else {
					return $author$project$MaxkCut$TwoCut;
				}
			}();
			return _Utils_update(
				maxCutTrans,
				{state: newState});
		} else {
			var _v2 = maxCutTrans.state;
			if (_v2.$ === 'TwoCut') {
				var shapeTrans = A2($author$project$MaxkCut$animateMaxCutTransition, msg, maxCutTrans.transitionA);
				return _Utils_update(
					maxCutTrans,
					{transitionA: shapeTrans});
			} else {
				var shapeTrans = A2($author$project$MaxkCut$animateMaxCutTransition, msg, maxCutTrans.transitionB);
				return _Utils_update(
					maxCutTrans,
					{transitionB: shapeTrans});
			}
		}
	});
var $author$project$GraphColoring$ThreeColor = {$: 'ThreeColor'};
var $author$project$Graph$changeColorOfVertex = F3(
	function (name, color, graph) {
		var newVertices = A2(
			$elm$core$List$map,
			function (v) {
				return _Utils_eq(v.name, name) ? _Utils_update(
					v,
					{color: color}) : v;
			},
			graph.vertices);
		var createEdge = $author$project$Graph$updateEdge(newVertices);
		return A2(
			$author$project$Graph$Graph,
			newVertices,
			A2($elm$core$List$map, createEdge, graph.edges));
	});
var $author$project$GraphColoring$goColor = F2(
	function (display, msg) {
		switch (msg.$) {
			case 'ColoringSelectColor':
				var color = msg.a;
				return _Utils_update(
					display,
					{chosenColor: color});
			case 'VertexClicked':
				var name = msg.a;
				var newGraph = A3($author$project$Graph$changeColorOfVertex, name, display.chosenColor, display.graphA);
				return _Utils_update(
					display,
					{graphA: newGraph});
			case 'VertexNonColor':
				var whiteVertices = A2(
					$elm$core$List$map,
					function (v) {
						return _Utils_update(
							v,
							{
								color: A3($avh4$elm_color$Color$rgb, 1, 1, 1)
							});
					},
					display.graphA.vertices);
				var createEdge = $author$project$Graph$updateEdge(whiteVertices);
				var newGraph = A2(
					$author$project$Graph$Graph,
					whiteVertices,
					A2($elm$core$List$map, createEdge, display.graphA.edges));
				return _Utils_update(
					display,
					{graphA: newGraph});
			default:
				return display;
		}
	});
var $author$project$GraphColoring$goColorSeries = F2(
	function (displaySeries, msg) {
		var newState = function () {
			if (msg.$ === 'NextAnimation') {
				var _v3 = displaySeries.state;
				if (_v3.$ === 'TwoColor') {
					return $author$project$GraphColoring$ThreeColor;
				} else {
					return $author$project$GraphColoring$TwoColor;
				}
			} else {
				return displaySeries.state;
			}
		}();
		var newDisplayB = function () {
			if (newState.$ === 'ThreeColor') {
				return A2($author$project$GraphColoring$goColor, displaySeries.colorDisplayB, msg);
			} else {
				return displaySeries.colorDisplayB;
			}
		}();
		var newDisplayA = function () {
			if (newState.$ === 'TwoColor') {
				return A2($author$project$GraphColoring$goColor, displaySeries.colorDisplayA, msg);
			} else {
				return displaySeries.colorDisplayA;
			}
		}();
		return {colorDisplayA: newDisplayA, colorDisplayB: newDisplayB, state: newState};
	});
var $author$project$VertexCover$Second = {$: 'Second'};
var $author$project$VertexCover$goCover = F2(
	function (display, msg) {
		switch (msg.$) {
			case 'ToggleVertexStatus':
				var name = msg.a;
				var _v1 = display.state;
				if (_v1.$ === 'First') {
					return _Utils_update(
						display,
						{
							graphA: A2($author$project$Graph$toggleGlowVertex, name, display.graphA)
						});
				} else {
					return _Utils_update(
						display,
						{
							graphB: A2($author$project$Graph$toggleGlowVertex, name, display.graphB)
						});
				}
			case 'VertexClicked':
				var name = msg.a;
				var _v2 = display.state;
				if (_v2.$ === 'First') {
					return _Utils_update(
						display,
						{
							graphA: A2($author$project$Graph$toggleGlowVertex, name, display.graphA)
						});
				} else {
					return _Utils_update(
						display,
						{
							graphB: A2($author$project$Graph$toggleGlowVertex, name, display.graphB)
						});
				}
			case 'NextAnimation':
				var _v3 = display.state;
				if (_v3.$ === 'First') {
					return _Utils_update(
						display,
						{state: $author$project$VertexCover$Second});
				} else {
					return _Utils_update(
						display,
						{state: $author$project$VertexCover$First});
				}
			default:
				return display;
		}
	});
var $author$project$TreeWidth$AltTree = {$: 'AltTree'};
var $author$project$TreeWidth$FinalSlide = {$: 'FinalSlide'};
var $author$project$TreeWidth$HoneyCombGraph = {$: 'HoneyCombGraph'};
var $author$project$TreeWidth$MorphingIntoHoneyComb = {$: 'MorphingIntoHoneyComb'};
var $author$project$TreeWidth$PiecesMarked = {$: 'PiecesMarked'};
var $author$project$TreeWidth$ShowLargePiece = {$: 'ShowLargePiece'};
var $author$project$TreeWidth$ShowOnePiece = {$: 'ShowOnePiece'};
var $author$project$TreeWidth$TreeDrawnGraph = {$: 'TreeDrawnGraph'};
var $author$project$TreeWidth$morphIntoHoneyComb = F2(
	function (delta, display) {
		if (A2($author$project$Graph$distanceBetweenGraphAndGrid, display.graph, display.gridHoneyComb) < 20) {
			return _Utils_update(
				display,
				{
					graph: A2($author$project$Graph$morphGraph, display.graph, display.gridHoneyComb),
					status: $author$project$TreeWidth$HoneyCombGraph,
					time: 0.0
				});
		} else {
			var accumulatedTime = display.time + delta;
			var calculatedTime = delta / (2000 - accumulatedTime);
			return _Utils_update(
				display,
				{
					graph: A3($author$project$Graph$moveTowards, calculatedTime, display.graph, display.gridHoneyComb),
					time: accumulatedTime
				});
		}
	});
var $author$project$TreeWidth$goTree = F2(
	function (display, msg) {
		switch (msg.$) {
			case 'NextAnimation':
				var newStatus = function () {
					var _v2 = display.status;
					switch (_v2.$) {
						case 'CircularGraph':
							return $author$project$TreeWidth$MorphingIntoHoneyComb;
						case 'MorphingIntoHoneyComb':
							return $author$project$TreeWidth$HoneyCombGraph;
						case 'HoneyCombGraph':
							return $author$project$TreeWidth$ShowOnePiece;
						case 'ShowOnePiece':
							return $author$project$TreeWidth$PiecesMarked;
						case 'PiecesMarked':
							return $author$project$TreeWidth$TreeDrawnGraph;
						case 'TreeDrawnGraph':
							return $author$project$TreeWidth$ShowLargePiece;
						case 'ShowLargePiece':
							return $author$project$TreeWidth$AltTree;
						case 'AltTree':
							return $author$project$TreeWidth$FinalSlide;
						default:
							return $author$project$TreeWidth$CircularGraph;
					}
				}();
				var newGraph = function () {
					switch (newStatus.$) {
						case 'CircularGraph':
							return A2($author$project$Graph$morphGraph, display.graph, display.gridCircular);
						case 'HoneyCombGraph':
							return A2($author$project$Graph$morphGraph, display.graph, display.gridHoneyComb);
						default:
							return display.graph;
					}
				}();
				return _Utils_update(
					display,
					{graph: newGraph, status: newStatus});
			case 'PreviousTreeWidthAnimation':
				var newStatus = function () {
					var _v4 = display.status;
					switch (_v4.$) {
						case 'CircularGraph':
							return $author$project$TreeWidth$CircularGraph;
						case 'MorphingIntoHoneyComb':
							return $author$project$TreeWidth$CircularGraph;
						case 'HoneyCombGraph':
							return $author$project$TreeWidth$CircularGraph;
						case 'ShowOnePiece':
							return $author$project$TreeWidth$HoneyCombGraph;
						case 'PiecesMarked':
							return $author$project$TreeWidth$ShowOnePiece;
						case 'TreeDrawnGraph':
							return $author$project$TreeWidth$PiecesMarked;
						case 'ShowLargePiece':
							return $author$project$TreeWidth$TreeDrawnGraph;
						case 'AltTree':
							return $author$project$TreeWidth$ShowLargePiece;
						default:
							return $author$project$TreeWidth$AltTree;
					}
				}();
				var newGraph = function () {
					switch (newStatus.$) {
						case 'CircularGraph':
							return A2($author$project$Graph$morphGraph, display.graph, display.gridCircular);
						case 'HoneyCombGraph':
							return A2($author$project$Graph$morphGraph, display.graph, display.gridHoneyComb);
						default:
							return display.graph;
					}
				}();
				return _Utils_update(
					display,
					{graph: newGraph, status: newStatus});
			case 'TimeDelta':
				var delta = msg.a;
				return _Utils_eq(display.status, $author$project$TreeWidth$MorphingIntoHoneyComb) ? A2($author$project$TreeWidth$morphIntoHoneyComb, delta, display) : display;
			default:
				return display;
		}
	});
var $elm$browser$Browser$Navigation$load = _Browser_load;
var $elm$browser$Browser$Navigation$pushUrl = _Browser_pushUrl;
var $elm$url$Url$addPort = F2(
	function (maybePort, starter) {
		if (maybePort.$ === 'Nothing') {
			return starter;
		} else {
			var port_ = maybePort.a;
			return starter + (':' + $elm$core$String$fromInt(port_));
		}
	});
var $elm$url$Url$addPrefixed = F3(
	function (prefix, maybeSegment, starter) {
		if (maybeSegment.$ === 'Nothing') {
			return starter;
		} else {
			var segment = maybeSegment.a;
			return _Utils_ap(
				starter,
				_Utils_ap(prefix, segment));
		}
	});
var $elm$url$Url$toString = function (url) {
	var http = function () {
		var _v0 = url.protocol;
		if (_v0.$ === 'Http') {
			return 'http://';
		} else {
			return 'https://';
		}
	}();
	return A3(
		$elm$url$Url$addPrefixed,
		'#',
		url.fragment,
		A3(
			$elm$url$Url$addPrefixed,
			'?',
			url.query,
			_Utils_ap(
				A2(
					$elm$url$Url$addPort,
					url.port_,
					_Utils_ap(http, url.host)),
				url.path)));
};
var $author$project$Main$update = F2(
	function (msg, model) {
		var topic = model.topic;
		var oldDisplaySize = model.displaySize;
		var newTopic = function () {
			if (msg.$ === 'UrlChanged') {
				var url = msg.a;
				return $author$project$Main$getTopic(url);
			} else {
				switch (topic.$) {
					case 'Isomorphic':
						var isotopic = topic.a;
						return $author$project$Main$Isomorphic(
							A2($author$project$Isomorphism$animateIsomorphicTopic, msg, isotopic));
					case 'MaxCut':
						var maxcutTrans = topic.a;
						return $author$project$Main$MaxCut(
							A2($author$project$MaxkCut$animateMaxCutCompound, msg, maxcutTrans));
					case 'GraphColoring':
						var displaySeries = topic.a;
						return $author$project$Main$GraphColoring(
							A2($author$project$GraphColoring$goColorSeries, displaySeries, msg));
					case 'VertexCover':
						var display = topic.a;
						return $author$project$Main$VertexCover(
							A2($author$project$VertexCover$goCover, display, msg));
					case 'TreeWidth':
						var display = topic.a;
						return $author$project$Main$TreeWidth(
							A2($author$project$TreeWidth$goTree, display, msg));
					case 'HomePage':
						return topic;
					default:
						return topic;
				}
			}
		}();
		var helpStatus = function () {
			switch (msg.$) {
				case 'ToggleHelpStatus':
					return !model.helpStatus;
				case 'TimeDelta':
					return model.helpStatus;
				default:
					return false;
			}
		}();
		var displaySize = function () {
			if (msg.$ === 'GotNewScreen') {
				var w = msg.a;
				var h = msg.b;
				return _Utils_update(
					oldDisplaySize,
					{
						deviceType: $author$project$FontSize$getDeviceType(w),
						height: h,
						width: w
					});
			} else {
				return model.displaySize;
			}
		}();
		var command = function () {
			switch (msg.$) {
				case 'LinkClicked':
					var urlRequest = msg.a;
					if (urlRequest.$ === 'Internal') {
						var url = urlRequest.a;
						return A2(
							$elm$browser$Browser$Navigation$pushUrl,
							model.key,
							$elm$url$Url$toString(url));
					} else {
						var href = urlRequest.a;
						return $elm$browser$Browser$Navigation$load(href);
					}
				case 'GotoHome':
					return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/');
				case 'GotoIsomorphism':
					return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/isomorphism');
				case 'GotoMaxkCut':
					return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/maxkcut');
				case 'GotoColoring':
					return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/coloring');
				case 'GotoCover':
					return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/vertexcover');
				case 'GotoTreeWidth':
					return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/treewidth');
				case 'GotoSize':
					return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/size');
				case 'GotoAbout':
					return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/about');
				case 'NextTopic':
					switch (topic.$) {
						case 'HomePage':
							return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/isomorphism');
						case 'Isomorphic':
							var x = topic.a;
							return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/maxkcut');
						case 'MaxCut':
							var x = topic.a;
							return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/coloring');
						case 'GraphColoring':
							var x = topic.a;
							return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/vertexcover');
						case 'VertexCover':
							var x = topic.a;
							return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/treewidth');
						case 'TreeWidth':
							var x = topic.a;
							return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/isomorphism');
						default:
							return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/');
					}
				case 'PreviousTopic':
					switch (topic.$) {
						case 'Isomorphic':
							var x = topic.a;
							return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/treewidth');
						case 'TreeWidth':
							var x = topic.a;
							return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/vertexcover');
						case 'MaxCut':
							var x = topic.a;
							return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/isomorphism');
						case 'GraphColoring':
							var x = topic.a;
							return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/maxkcut');
						case 'VertexCover':
							var x = topic.a;
							return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/coloring');
						case 'HomePage':
							return $elm$core$Platform$Cmd$none;
						default:
							return A2($elm$browser$Browser$Navigation$pushUrl, model.key, '/');
					}
				default:
					return $elm$core$Platform$Cmd$none;
			}
		}();
		return _Utils_Tuple2(
			_Utils_update(
				model,
				{displaySize: displaySize, helpStatus: helpStatus, topic: newTopic}),
			command);
	});
var $author$project$FontSize$DisplaySize = F3(
	function (width, height, deviceType) {
		return {deviceType: deviceType, height: height, width: width};
	});
var $mdgriffith$elm_ui$Internal$Model$Unkeyed = function (a) {
	return {$: 'Unkeyed', a: a};
};
var $mdgriffith$elm_ui$Internal$Model$AsColumn = {$: 'AsColumn'};
var $mdgriffith$elm_ui$Internal$Model$asColumn = $mdgriffith$elm_ui$Internal$Model$AsColumn;
var $mdgriffith$elm_ui$Internal$Style$classes = {above: 'a', active: 'atv', alignBottom: 'ab', alignCenterX: 'cx', alignCenterY: 'cy', alignContainerBottom: 'acb', alignContainerCenterX: 'accx', alignContainerCenterY: 'accy', alignContainerRight: 'acr', alignLeft: 'al', alignRight: 'ar', alignTop: 'at', alignedHorizontally: 'ah', alignedVertically: 'av', any: 's', behind: 'bh', below: 'b', bold: 'w7', borderDashed: 'bd', borderDotted: 'bdt', borderNone: 'bn', borderSolid: 'bs', capturePointerEvents: 'cpe', clip: 'cp', clipX: 'cpx', clipY: 'cpy', column: 'c', container: 'ctr', contentBottom: 'cb', contentCenterX: 'ccx', contentCenterY: 'ccy', contentLeft: 'cl', contentRight: 'cr', contentTop: 'ct', cursorPointer: 'cptr', cursorText: 'ctxt', focus: 'fcs', focusedWithin: 'focus-within', fullSize: 'fs', grid: 'g', hasBehind: 'hbh', heightContent: 'hc', heightExact: 'he', heightFill: 'hf', heightFillPortion: 'hfp', hover: 'hv', imageContainer: 'ic', inFront: 'fr', inputLabel: 'lbl', inputMultiline: 'iml', inputMultilineFiller: 'imlf', inputMultilineParent: 'imlp', inputMultilineWrapper: 'implw', inputText: 'it', italic: 'i', link: 'lnk', nearby: 'nb', noTextSelection: 'notxt', onLeft: 'ol', onRight: 'or', opaque: 'oq', overflowHidden: 'oh', page: 'pg', paragraph: 'p', passPointerEvents: 'ppe', root: 'ui', row: 'r', scrollbars: 'sb', scrollbarsX: 'sbx', scrollbarsY: 'sby', seButton: 'sbt', single: 'e', sizeByCapital: 'cap', spaceEvenly: 'sev', strike: 'sk', text: 't', textCenter: 'tc', textExtraBold: 'w8', textExtraLight: 'w2', textHeavy: 'w9', textJustify: 'tj', textJustifyAll: 'tja', textLeft: 'tl', textLight: 'w3', textMedium: 'w5', textNormalWeight: 'w4', textRight: 'tr', textSemiBold: 'w6', textThin: 'w1', textUnitalicized: 'tun', transition: 'ts', transparent: 'clr', underline: 'u', widthContent: 'wc', widthExact: 'we', widthFill: 'wf', widthFillPortion: 'wfp', wrapped: 'wrp'};
var $mdgriffith$elm_ui$Internal$Model$Generic = {$: 'Generic'};
var $mdgriffith$elm_ui$Internal$Model$div = $mdgriffith$elm_ui$Internal$Model$Generic;
var $mdgriffith$elm_ui$Internal$Model$NoNearbyChildren = {$: 'NoNearbyChildren'};
var $mdgriffith$elm_ui$Internal$Model$columnClass = $mdgriffith$elm_ui$Internal$Style$classes.any + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.column);
var $mdgriffith$elm_ui$Internal$Model$gridClass = $mdgriffith$elm_ui$Internal$Style$classes.any + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.grid);
var $mdgriffith$elm_ui$Internal$Model$pageClass = $mdgriffith$elm_ui$Internal$Style$classes.any + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.page);
var $mdgriffith$elm_ui$Internal$Model$paragraphClass = $mdgriffith$elm_ui$Internal$Style$classes.any + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.paragraph);
var $mdgriffith$elm_ui$Internal$Model$rowClass = $mdgriffith$elm_ui$Internal$Style$classes.any + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.row);
var $mdgriffith$elm_ui$Internal$Model$singleClass = $mdgriffith$elm_ui$Internal$Style$classes.any + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.single);
var $mdgriffith$elm_ui$Internal$Model$contextClasses = function (context) {
	switch (context.$) {
		case 'AsRow':
			return $mdgriffith$elm_ui$Internal$Model$rowClass;
		case 'AsColumn':
			return $mdgriffith$elm_ui$Internal$Model$columnClass;
		case 'AsEl':
			return $mdgriffith$elm_ui$Internal$Model$singleClass;
		case 'AsGrid':
			return $mdgriffith$elm_ui$Internal$Model$gridClass;
		case 'AsParagraph':
			return $mdgriffith$elm_ui$Internal$Model$paragraphClass;
		default:
			return $mdgriffith$elm_ui$Internal$Model$pageClass;
	}
};
var $mdgriffith$elm_ui$Internal$Model$Keyed = function (a) {
	return {$: 'Keyed', a: a};
};
var $mdgriffith$elm_ui$Internal$Model$NoStyleSheet = {$: 'NoStyleSheet'};
var $mdgriffith$elm_ui$Internal$Model$Styled = function (a) {
	return {$: 'Styled', a: a};
};
var $mdgriffith$elm_ui$Internal$Model$Unstyled = function (a) {
	return {$: 'Unstyled', a: a};
};
var $mdgriffith$elm_ui$Internal$Model$addChildren = F2(
	function (existing, nearbyChildren) {
		switch (nearbyChildren.$) {
			case 'NoNearbyChildren':
				return existing;
			case 'ChildrenBehind':
				var behind = nearbyChildren.a;
				return _Utils_ap(behind, existing);
			case 'ChildrenInFront':
				var inFront = nearbyChildren.a;
				return _Utils_ap(existing, inFront);
			default:
				var behind = nearbyChildren.a;
				var inFront = nearbyChildren.b;
				return _Utils_ap(
					behind,
					_Utils_ap(existing, inFront));
		}
	});
var $mdgriffith$elm_ui$Internal$Model$addKeyedChildren = F3(
	function (key, existing, nearbyChildren) {
		switch (nearbyChildren.$) {
			case 'NoNearbyChildren':
				return existing;
			case 'ChildrenBehind':
				var behind = nearbyChildren.a;
				return _Utils_ap(
					A2(
						$elm$core$List$map,
						function (x) {
							return _Utils_Tuple2(key, x);
						},
						behind),
					existing);
			case 'ChildrenInFront':
				var inFront = nearbyChildren.a;
				return _Utils_ap(
					existing,
					A2(
						$elm$core$List$map,
						function (x) {
							return _Utils_Tuple2(key, x);
						},
						inFront));
			default:
				var behind = nearbyChildren.a;
				var inFront = nearbyChildren.b;
				return _Utils_ap(
					A2(
						$elm$core$List$map,
						function (x) {
							return _Utils_Tuple2(key, x);
						},
						behind),
					_Utils_ap(
						existing,
						A2(
							$elm$core$List$map,
							function (x) {
								return _Utils_Tuple2(key, x);
							},
							inFront)));
		}
	});
var $mdgriffith$elm_ui$Internal$Model$AsEl = {$: 'AsEl'};
var $mdgriffith$elm_ui$Internal$Model$asEl = $mdgriffith$elm_ui$Internal$Model$AsEl;
var $mdgriffith$elm_ui$Internal$Model$AsParagraph = {$: 'AsParagraph'};
var $mdgriffith$elm_ui$Internal$Model$asParagraph = $mdgriffith$elm_ui$Internal$Model$AsParagraph;
var $mdgriffith$elm_ui$Internal$Flag$Flag = function (a) {
	return {$: 'Flag', a: a};
};
var $mdgriffith$elm_ui$Internal$Flag$Second = function (a) {
	return {$: 'Second', a: a};
};
var $elm$core$Bitwise$shiftLeftBy = _Bitwise_shiftLeftBy;
var $mdgriffith$elm_ui$Internal$Flag$flag = function (i) {
	return (i > 31) ? $mdgriffith$elm_ui$Internal$Flag$Second(1 << (i - 32)) : $mdgriffith$elm_ui$Internal$Flag$Flag(1 << i);
};
var $mdgriffith$elm_ui$Internal$Flag$alignBottom = $mdgriffith$elm_ui$Internal$Flag$flag(41);
var $mdgriffith$elm_ui$Internal$Flag$alignRight = $mdgriffith$elm_ui$Internal$Flag$flag(40);
var $mdgriffith$elm_ui$Internal$Flag$centerX = $mdgriffith$elm_ui$Internal$Flag$flag(42);
var $mdgriffith$elm_ui$Internal$Flag$centerY = $mdgriffith$elm_ui$Internal$Flag$flag(43);
var $elm$json$Json$Encode$string = _Json_wrap;
var $elm$html$Html$Attributes$stringProperty = F2(
	function (key, string) {
		return A2(
			_VirtualDom_property,
			key,
			$elm$json$Json$Encode$string(string));
	});
var $elm$html$Html$Attributes$class = $elm$html$Html$Attributes$stringProperty('className');
var $elm$html$Html$div = _VirtualDom_node('div');
var $elm$core$Set$Set_elm_builtin = function (a) {
	return {$: 'Set_elm_builtin', a: a};
};
var $elm$core$Set$empty = $elm$core$Set$Set_elm_builtin($elm$core$Dict$empty);
var $mdgriffith$elm_ui$Internal$Model$lengthClassName = function (x) {
	switch (x.$) {
		case 'Px':
			var px = x.a;
			return $elm$core$String$fromInt(px) + 'px';
		case 'Content':
			return 'auto';
		case 'Fill':
			var i = x.a;
			return $elm$core$String$fromInt(i) + 'fr';
		case 'Min':
			var min = x.a;
			var len = x.b;
			return 'min' + ($elm$core$String$fromInt(min) + $mdgriffith$elm_ui$Internal$Model$lengthClassName(len));
		default:
			var max = x.a;
			var len = x.b;
			return 'max' + ($elm$core$String$fromInt(max) + $mdgriffith$elm_ui$Internal$Model$lengthClassName(len));
	}
};
var $elm$core$Basics$round = _Basics_round;
var $mdgriffith$elm_ui$Internal$Model$floatClass = function (x) {
	return $elm$core$String$fromInt(
		$elm$core$Basics$round(x * 255));
};
var $mdgriffith$elm_ui$Internal$Model$transformClass = function (transform) {
	switch (transform.$) {
		case 'Untransformed':
			return $elm$core$Maybe$Nothing;
		case 'Moved':
			var _v1 = transform.a;
			var x = _v1.a;
			var y = _v1.b;
			var z = _v1.c;
			return $elm$core$Maybe$Just(
				'mv-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(x) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(y) + ('-' + $mdgriffith$elm_ui$Internal$Model$floatClass(z))))));
		default:
			var _v2 = transform.a;
			var tx = _v2.a;
			var ty = _v2.b;
			var tz = _v2.c;
			var _v3 = transform.b;
			var sx = _v3.a;
			var sy = _v3.b;
			var sz = _v3.c;
			var _v4 = transform.c;
			var ox = _v4.a;
			var oy = _v4.b;
			var oz = _v4.c;
			var angle = transform.d;
			return $elm$core$Maybe$Just(
				'tfrm-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(tx) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(ty) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(tz) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(sx) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(sy) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(sz) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(ox) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(oy) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(oz) + ('-' + $mdgriffith$elm_ui$Internal$Model$floatClass(angle))))))))))))))))))));
	}
};
var $mdgriffith$elm_ui$Internal$Model$getStyleName = function (style) {
	switch (style.$) {
		case 'Shadows':
			var name = style.a;
			return name;
		case 'Transparency':
			var name = style.a;
			var o = style.b;
			return name;
		case 'Style':
			var _class = style.a;
			return _class;
		case 'FontFamily':
			var name = style.a;
			return name;
		case 'FontSize':
			var i = style.a;
			return 'font-size-' + $elm$core$String$fromInt(i);
		case 'Single':
			var _class = style.a;
			return _class;
		case 'Colored':
			var _class = style.a;
			return _class;
		case 'SpacingStyle':
			var cls = style.a;
			var x = style.b;
			var y = style.c;
			return cls;
		case 'PaddingStyle':
			var cls = style.a;
			var top = style.b;
			var right = style.c;
			var bottom = style.d;
			var left = style.e;
			return cls;
		case 'BorderWidth':
			var cls = style.a;
			var top = style.b;
			var right = style.c;
			var bottom = style.d;
			var left = style.e;
			return cls;
		case 'GridTemplateStyle':
			var template = style.a;
			return 'grid-rows-' + (A2(
				$elm$core$String$join,
				'-',
				A2($elm$core$List$map, $mdgriffith$elm_ui$Internal$Model$lengthClassName, template.rows)) + ('-cols-' + (A2(
				$elm$core$String$join,
				'-',
				A2($elm$core$List$map, $mdgriffith$elm_ui$Internal$Model$lengthClassName, template.columns)) + ('-space-x-' + ($mdgriffith$elm_ui$Internal$Model$lengthClassName(template.spacing.a) + ('-space-y-' + $mdgriffith$elm_ui$Internal$Model$lengthClassName(template.spacing.b)))))));
		case 'GridPosition':
			var pos = style.a;
			return 'gp grid-pos-' + ($elm$core$String$fromInt(pos.row) + ('-' + ($elm$core$String$fromInt(pos.col) + ('-' + ($elm$core$String$fromInt(pos.width) + ('-' + $elm$core$String$fromInt(pos.height)))))));
		case 'PseudoSelector':
			var selector = style.a;
			var subStyle = style.b;
			var name = function () {
				switch (selector.$) {
					case 'Focus':
						return 'fs';
					case 'Hover':
						return 'hv';
					default:
						return 'act';
				}
			}();
			return A2(
				$elm$core$String$join,
				' ',
				A2(
					$elm$core$List$map,
					function (sty) {
						var _v1 = $mdgriffith$elm_ui$Internal$Model$getStyleName(sty);
						if (_v1 === '') {
							return '';
						} else {
							var styleName = _v1;
							return styleName + ('-' + name);
						}
					},
					subStyle));
		default:
			var x = style.a;
			return A2(
				$elm$core$Maybe$withDefault,
				'',
				$mdgriffith$elm_ui$Internal$Model$transformClass(x));
	}
};
var $elm$core$Set$insert = F2(
	function (key, _v0) {
		var dict = _v0.a;
		return $elm$core$Set$Set_elm_builtin(
			A3($elm$core$Dict$insert, key, _Utils_Tuple0, dict));
	});
var $elm$core$Dict$get = F2(
	function (targetKey, dict) {
		get:
		while (true) {
			if (dict.$ === 'RBEmpty_elm_builtin') {
				return $elm$core$Maybe$Nothing;
			} else {
				var key = dict.b;
				var value = dict.c;
				var left = dict.d;
				var right = dict.e;
				var _v1 = A2($elm$core$Basics$compare, targetKey, key);
				switch (_v1.$) {
					case 'LT':
						var $temp$targetKey = targetKey,
							$temp$dict = left;
						targetKey = $temp$targetKey;
						dict = $temp$dict;
						continue get;
					case 'EQ':
						return $elm$core$Maybe$Just(value);
					default:
						var $temp$targetKey = targetKey,
							$temp$dict = right;
						targetKey = $temp$targetKey;
						dict = $temp$dict;
						continue get;
				}
			}
		}
	});
var $elm$core$Dict$member = F2(
	function (key, dict) {
		var _v0 = A2($elm$core$Dict$get, key, dict);
		if (_v0.$ === 'Just') {
			return true;
		} else {
			return false;
		}
	});
var $elm$core$Set$member = F2(
	function (key, _v0) {
		var dict = _v0.a;
		return A2($elm$core$Dict$member, key, dict);
	});
var $mdgriffith$elm_ui$Internal$Model$reduceStyles = F2(
	function (style, nevermind) {
		var cache = nevermind.a;
		var existing = nevermind.b;
		var styleName = $mdgriffith$elm_ui$Internal$Model$getStyleName(style);
		return A2($elm$core$Set$member, styleName, cache) ? nevermind : _Utils_Tuple2(
			A2($elm$core$Set$insert, styleName, cache),
			A2($elm$core$List$cons, style, existing));
	});
var $mdgriffith$elm_ui$Internal$Model$Property = F2(
	function (a, b) {
		return {$: 'Property', a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Model$Style = F2(
	function (a, b) {
		return {$: 'Style', a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Style$dot = function (c) {
	return '.' + c;
};
var $elm$core$String$fromFloat = _String_fromNumber;
var $mdgriffith$elm_ui$Internal$Model$formatColor = function (_v0) {
	var red = _v0.a;
	var green = _v0.b;
	var blue = _v0.c;
	var alpha = _v0.d;
	return 'rgba(' + ($elm$core$String$fromInt(
		$elm$core$Basics$round(red * 255)) + ((',' + $elm$core$String$fromInt(
		$elm$core$Basics$round(green * 255))) + ((',' + $elm$core$String$fromInt(
		$elm$core$Basics$round(blue * 255))) + (',' + ($elm$core$String$fromFloat(alpha) + ')')))));
};
var $mdgriffith$elm_ui$Internal$Model$formatBoxShadow = function (shadow) {
	return A2(
		$elm$core$String$join,
		' ',
		A2(
			$elm$core$List$filterMap,
			$elm$core$Basics$identity,
			_List_fromArray(
				[
					shadow.inset ? $elm$core$Maybe$Just('inset') : $elm$core$Maybe$Nothing,
					$elm$core$Maybe$Just(
					$elm$core$String$fromFloat(shadow.offset.a) + 'px'),
					$elm$core$Maybe$Just(
					$elm$core$String$fromFloat(shadow.offset.b) + 'px'),
					$elm$core$Maybe$Just(
					$elm$core$String$fromFloat(shadow.blur) + 'px'),
					$elm$core$Maybe$Just(
					$elm$core$String$fromFloat(shadow.size) + 'px'),
					$elm$core$Maybe$Just(
					$mdgriffith$elm_ui$Internal$Model$formatColor(shadow.color))
				])));
};
var $elm$core$Maybe$map = F2(
	function (f, maybe) {
		if (maybe.$ === 'Just') {
			var value = maybe.a;
			return $elm$core$Maybe$Just(
				f(value));
		} else {
			return $elm$core$Maybe$Nothing;
		}
	});
var $elm$core$Tuple$mapFirst = F2(
	function (func, _v0) {
		var x = _v0.a;
		var y = _v0.b;
		return _Utils_Tuple2(
			func(x),
			y);
	});
var $elm$core$Tuple$mapSecond = F2(
	function (func, _v0) {
		var x = _v0.a;
		var y = _v0.b;
		return _Utils_Tuple2(
			x,
			func(y));
	});
var $mdgriffith$elm_ui$Internal$Model$renderFocusStyle = function (focus) {
	return _List_fromArray(
		[
			A2(
			$mdgriffith$elm_ui$Internal$Model$Style,
			$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.focusedWithin) + ':focus-within',
			A2(
				$elm$core$List$filterMap,
				$elm$core$Basics$identity,
				_List_fromArray(
					[
						A2(
						$elm$core$Maybe$map,
						function (color) {
							return A2(
								$mdgriffith$elm_ui$Internal$Model$Property,
								'border-color',
								$mdgriffith$elm_ui$Internal$Model$formatColor(color));
						},
						focus.borderColor),
						A2(
						$elm$core$Maybe$map,
						function (color) {
							return A2(
								$mdgriffith$elm_ui$Internal$Model$Property,
								'background-color',
								$mdgriffith$elm_ui$Internal$Model$formatColor(color));
						},
						focus.backgroundColor),
						A2(
						$elm$core$Maybe$map,
						function (shadow) {
							return A2(
								$mdgriffith$elm_ui$Internal$Model$Property,
								'box-shadow',
								$mdgriffith$elm_ui$Internal$Model$formatBoxShadow(
									{
										blur: shadow.blur,
										color: shadow.color,
										inset: false,
										offset: A2(
											$elm$core$Tuple$mapSecond,
											$elm$core$Basics$toFloat,
											A2($elm$core$Tuple$mapFirst, $elm$core$Basics$toFloat, shadow.offset)),
										size: shadow.size
									}));
						},
						focus.shadow),
						$elm$core$Maybe$Just(
						A2($mdgriffith$elm_ui$Internal$Model$Property, 'outline', 'none'))
					]))),
			A2(
			$mdgriffith$elm_ui$Internal$Model$Style,
			($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.any) + ':focus .focusable, ') + (($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.any) + '.focusable:focus, ') + ('.ui-slide-bar:focus + ' + ($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.any) + ' .focusable-thumb'))),
			A2(
				$elm$core$List$filterMap,
				$elm$core$Basics$identity,
				_List_fromArray(
					[
						A2(
						$elm$core$Maybe$map,
						function (color) {
							return A2(
								$mdgriffith$elm_ui$Internal$Model$Property,
								'border-color',
								$mdgriffith$elm_ui$Internal$Model$formatColor(color));
						},
						focus.borderColor),
						A2(
						$elm$core$Maybe$map,
						function (color) {
							return A2(
								$mdgriffith$elm_ui$Internal$Model$Property,
								'background-color',
								$mdgriffith$elm_ui$Internal$Model$formatColor(color));
						},
						focus.backgroundColor),
						A2(
						$elm$core$Maybe$map,
						function (shadow) {
							return A2(
								$mdgriffith$elm_ui$Internal$Model$Property,
								'box-shadow',
								$mdgriffith$elm_ui$Internal$Model$formatBoxShadow(
									{
										blur: shadow.blur,
										color: shadow.color,
										inset: false,
										offset: A2(
											$elm$core$Tuple$mapSecond,
											$elm$core$Basics$toFloat,
											A2($elm$core$Tuple$mapFirst, $elm$core$Basics$toFloat, shadow.offset)),
										size: shadow.size
									}));
						},
						focus.shadow),
						$elm$core$Maybe$Just(
						A2($mdgriffith$elm_ui$Internal$Model$Property, 'outline', 'none'))
					])))
		]);
};
var $elm$virtual_dom$VirtualDom$node = function (tag) {
	return _VirtualDom_node(
		_VirtualDom_noScript(tag));
};
var $elm$virtual_dom$VirtualDom$property = F2(
	function (key, value) {
		return A2(
			_VirtualDom_property,
			_VirtualDom_noInnerHtmlOrFormAction(key),
			_VirtualDom_noJavaScriptOrHtmlJson(value));
	});
var $mdgriffith$elm_ui$Internal$Style$AllChildren = F2(
	function (a, b) {
		return {$: 'AllChildren', a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Style$Batch = function (a) {
	return {$: 'Batch', a: a};
};
var $mdgriffith$elm_ui$Internal$Style$Child = F2(
	function (a, b) {
		return {$: 'Child', a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Style$Class = F2(
	function (a, b) {
		return {$: 'Class', a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Style$Descriptor = F2(
	function (a, b) {
		return {$: 'Descriptor', a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Style$Left = {$: 'Left'};
var $mdgriffith$elm_ui$Internal$Style$Prop = F2(
	function (a, b) {
		return {$: 'Prop', a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Style$Right = {$: 'Right'};
var $mdgriffith$elm_ui$Internal$Style$Self = function (a) {
	return {$: 'Self', a: a};
};
var $mdgriffith$elm_ui$Internal$Style$Supports = F2(
	function (a, b) {
		return {$: 'Supports', a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Style$Content = function (a) {
	return {$: 'Content', a: a};
};
var $mdgriffith$elm_ui$Internal$Style$Bottom = {$: 'Bottom'};
var $mdgriffith$elm_ui$Internal$Style$CenterX = {$: 'CenterX'};
var $mdgriffith$elm_ui$Internal$Style$CenterY = {$: 'CenterY'};
var $mdgriffith$elm_ui$Internal$Style$Top = {$: 'Top'};
var $mdgriffith$elm_ui$Internal$Style$alignments = _List_fromArray(
	[$mdgriffith$elm_ui$Internal$Style$Top, $mdgriffith$elm_ui$Internal$Style$Bottom, $mdgriffith$elm_ui$Internal$Style$Right, $mdgriffith$elm_ui$Internal$Style$Left, $mdgriffith$elm_ui$Internal$Style$CenterX, $mdgriffith$elm_ui$Internal$Style$CenterY]);
var $elm$core$List$concatMap = F2(
	function (f, list) {
		return $elm$core$List$concat(
			A2($elm$core$List$map, f, list));
	});
var $mdgriffith$elm_ui$Internal$Style$contentName = function (desc) {
	switch (desc.a.$) {
		case 'Top':
			var _v1 = desc.a;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.contentTop);
		case 'Bottom':
			var _v2 = desc.a;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.contentBottom);
		case 'Right':
			var _v3 = desc.a;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.contentRight);
		case 'Left':
			var _v4 = desc.a;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.contentLeft);
		case 'CenterX':
			var _v5 = desc.a;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.contentCenterX);
		default:
			var _v6 = desc.a;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.contentCenterY);
	}
};
var $mdgriffith$elm_ui$Internal$Style$selfName = function (desc) {
	switch (desc.a.$) {
		case 'Top':
			var _v1 = desc.a;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.alignTop);
		case 'Bottom':
			var _v2 = desc.a;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.alignBottom);
		case 'Right':
			var _v3 = desc.a;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.alignRight);
		case 'Left':
			var _v4 = desc.a;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.alignLeft);
		case 'CenterX':
			var _v5 = desc.a;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.alignCenterX);
		default:
			var _v6 = desc.a;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.alignCenterY);
	}
};
var $mdgriffith$elm_ui$Internal$Style$describeAlignment = function (values) {
	var createDescription = function (alignment) {
		var _v0 = values(alignment);
		var content = _v0.a;
		var indiv = _v0.b;
		return _List_fromArray(
			[
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$contentName(
					$mdgriffith$elm_ui$Internal$Style$Content(alignment)),
				content),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Child,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.any),
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$selfName(
							$mdgriffith$elm_ui$Internal$Style$Self(alignment)),
						indiv)
					]))
			]);
	};
	return $mdgriffith$elm_ui$Internal$Style$Batch(
		A2($elm$core$List$concatMap, createDescription, $mdgriffith$elm_ui$Internal$Style$alignments));
};
var $mdgriffith$elm_ui$Internal$Style$elDescription = _List_fromArray(
	[
		A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex'),
		A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-direction', 'column'),
		A2($mdgriffith$elm_ui$Internal$Style$Prop, 'white-space', 'pre'),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Descriptor,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.hasBehind),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '0'),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Child,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.behind),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '-1')
					]))
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Descriptor,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.seButton),
		_List_fromArray(
			[
				A2(
				$mdgriffith$elm_ui$Internal$Style$Child,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.text),
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.heightFill),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '0')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.widthFill),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'auto !important')
							]))
					]))
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Child,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.heightContent),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', 'auto')
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Child,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.heightFill),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '100000')
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Child,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.widthFill),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%')
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Child,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.widthFillPortion),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%')
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Child,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.widthContent),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'flex-start')
			])),
		$mdgriffith$elm_ui$Internal$Style$describeAlignment(
		function (alignment) {
			switch (alignment.$) {
				case 'Top':
					return _Utils_Tuple2(
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'flex-start')
							]),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-bottom', 'auto !important'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-top', '0 !important')
							]));
				case 'Bottom':
					return _Utils_Tuple2(
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'flex-end')
							]),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-top', 'auto !important'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-bottom', '0 !important')
							]));
				case 'Right':
					return _Utils_Tuple2(
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'flex-end')
							]),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'flex-end')
							]));
				case 'Left':
					return _Utils_Tuple2(
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'flex-start')
							]),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'flex-start')
							]));
				case 'CenterX':
					return _Utils_Tuple2(
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'center')
							]),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'center')
							]));
				default:
					return _Utils_Tuple2(
						_List_fromArray(
							[
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.any),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-top', 'auto'),
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-bottom', 'auto')
									]))
							]),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-top', 'auto !important'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-bottom', 'auto !important')
							]));
			}
		})
	]);
var $mdgriffith$elm_ui$Internal$Style$gridAlignments = function (values) {
	var createDescription = function (alignment) {
		return _List_fromArray(
			[
				A2(
				$mdgriffith$elm_ui$Internal$Style$Child,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.any),
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$selfName(
							$mdgriffith$elm_ui$Internal$Style$Self(alignment)),
						values(alignment))
					]))
			]);
	};
	return $mdgriffith$elm_ui$Internal$Style$Batch(
		A2($elm$core$List$concatMap, createDescription, $mdgriffith$elm_ui$Internal$Style$alignments));
};
var $mdgriffith$elm_ui$Internal$Style$Above = {$: 'Above'};
var $mdgriffith$elm_ui$Internal$Style$Behind = {$: 'Behind'};
var $mdgriffith$elm_ui$Internal$Style$Below = {$: 'Below'};
var $mdgriffith$elm_ui$Internal$Style$OnLeft = {$: 'OnLeft'};
var $mdgriffith$elm_ui$Internal$Style$OnRight = {$: 'OnRight'};
var $mdgriffith$elm_ui$Internal$Style$Within = {$: 'Within'};
var $mdgriffith$elm_ui$Internal$Style$locations = function () {
	var loc = $mdgriffith$elm_ui$Internal$Style$Above;
	var _v0 = function () {
		switch (loc.$) {
			case 'Above':
				return _Utils_Tuple0;
			case 'Below':
				return _Utils_Tuple0;
			case 'OnRight':
				return _Utils_Tuple0;
			case 'OnLeft':
				return _Utils_Tuple0;
			case 'Within':
				return _Utils_Tuple0;
			default:
				return _Utils_Tuple0;
		}
	}();
	return _List_fromArray(
		[$mdgriffith$elm_ui$Internal$Style$Above, $mdgriffith$elm_ui$Internal$Style$Below, $mdgriffith$elm_ui$Internal$Style$OnRight, $mdgriffith$elm_ui$Internal$Style$OnLeft, $mdgriffith$elm_ui$Internal$Style$Within, $mdgriffith$elm_ui$Internal$Style$Behind]);
}();
var $mdgriffith$elm_ui$Internal$Style$baseSheet = _List_fromArray(
	[
		A2(
		$mdgriffith$elm_ui$Internal$Style$Class,
		'html,body',
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '100%'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'padding', '0'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0')
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Class,
		_Utils_ap(
			$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.any),
			_Utils_ap(
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.single),
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.imageContainer))),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'block'),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.heightFill),
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						'img',
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'max-height', '100%'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'object-fit', 'cover')
							]))
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.widthFill),
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						'img',
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'max-width', '100%'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'object-fit', 'cover')
							]))
					]))
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Class,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.any) + ':focus',
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'outline', 'none')
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Class,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.root),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', 'auto'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'min-height', '100%'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '0'),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				_Utils_ap(
					$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.any),
					$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.heightFill)),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '100%'),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.heightFill),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '100%')
							]))
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Child,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.inFront),
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.nearby),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'fixed'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '20')
							]))
					]))
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Class,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.nearby),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'relative'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'border', 'none'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-direction', 'row'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', 'auto'),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.single),
				$mdgriffith$elm_ui$Internal$Style$elDescription),
				$mdgriffith$elm_ui$Internal$Style$Batch(
				function (fn) {
					return A2($elm$core$List$map, fn, $mdgriffith$elm_ui$Internal$Style$locations);
				}(
					function (loc) {
						switch (loc.$) {
							case 'Above':
								return A2(
									$mdgriffith$elm_ui$Internal$Style$Descriptor,
									$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.above),
									_List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'absolute'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'bottom', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'left', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '20'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0 !important'),
											A2(
											$mdgriffith$elm_ui$Internal$Style$Child,
											$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.heightFill),
											_List_fromArray(
												[
													A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', 'auto')
												])),
											A2(
											$mdgriffith$elm_ui$Internal$Style$Child,
											$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.widthFill),
											_List_fromArray(
												[
													A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%')
												])),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'none'),
											A2(
											$mdgriffith$elm_ui$Internal$Style$Child,
											'*',
											_List_fromArray(
												[
													A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'auto')
												]))
										]));
							case 'Below':
								return A2(
									$mdgriffith$elm_ui$Internal$Style$Descriptor,
									$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.below),
									_List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'absolute'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'bottom', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'left', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '20'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0 !important'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'none'),
											A2(
											$mdgriffith$elm_ui$Internal$Style$Child,
											'*',
											_List_fromArray(
												[
													A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'auto')
												])),
											A2(
											$mdgriffith$elm_ui$Internal$Style$Child,
											$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.heightFill),
											_List_fromArray(
												[
													A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', 'auto')
												]))
										]));
							case 'OnRight':
								return A2(
									$mdgriffith$elm_ui$Internal$Style$Descriptor,
									$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.onRight),
									_List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'absolute'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'left', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'top', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0 !important'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '20'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'none'),
											A2(
											$mdgriffith$elm_ui$Internal$Style$Child,
											'*',
											_List_fromArray(
												[
													A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'auto')
												]))
										]));
							case 'OnLeft':
								return A2(
									$mdgriffith$elm_ui$Internal$Style$Descriptor,
									$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.onLeft),
									_List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'absolute'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'right', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'top', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0 !important'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '20'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'none'),
											A2(
											$mdgriffith$elm_ui$Internal$Style$Child,
											'*',
											_List_fromArray(
												[
													A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'auto')
												]))
										]));
							case 'Within':
								return A2(
									$mdgriffith$elm_ui$Internal$Style$Descriptor,
									$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.inFront),
									_List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'absolute'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'left', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'top', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0 !important'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'none'),
											A2(
											$mdgriffith$elm_ui$Internal$Style$Child,
											'*',
											_List_fromArray(
												[
													A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'auto')
												]))
										]));
							default:
								return A2(
									$mdgriffith$elm_ui$Internal$Style$Descriptor,
									$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.behind),
									_List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'absolute'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'left', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'top', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0 !important'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'none'),
											A2(
											$mdgriffith$elm_ui$Internal$Style$Child,
											'*',
											_List_fromArray(
												[
													A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'auto')
												]))
										]));
						}
					}))
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Class,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.any),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'relative'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'border', 'none'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-shrink', '0'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-direction', 'row'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', 'auto'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'resize', 'none'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-feature-settings', 'inherit'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'box-sizing', 'border-box'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'padding', '0'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'border-width', '0'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'border-style', 'solid'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-size', 'inherit'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'color', 'inherit'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-family', 'inherit'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'line-height', '1'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', 'inherit'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-decoration', 'none'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-style', 'inherit'),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.wrapped),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-wrap', 'wrap')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.noTextSelection),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, '-moz-user-select', 'none'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, '-webkit-user-select', 'none'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, '-ms-user-select', 'none'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'user-select', 'none')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cursorPointer),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'cursor', 'pointer')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cursorText),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'cursor', 'text')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.passPointerEvents),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'none !important')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.capturePointerEvents),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'auto !important')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.transparent),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'opacity', '0')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.opaque),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'opacity', '1')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot(
					_Utils_ap($mdgriffith$elm_ui$Internal$Style$classes.hover, $mdgriffith$elm_ui$Internal$Style$classes.transparent)) + ':hover',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'opacity', '0')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot(
					_Utils_ap($mdgriffith$elm_ui$Internal$Style$classes.hover, $mdgriffith$elm_ui$Internal$Style$classes.opaque)) + ':hover',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'opacity', '1')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot(
					_Utils_ap($mdgriffith$elm_ui$Internal$Style$classes.focus, $mdgriffith$elm_ui$Internal$Style$classes.transparent)) + ':focus',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'opacity', '0')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot(
					_Utils_ap($mdgriffith$elm_ui$Internal$Style$classes.focus, $mdgriffith$elm_ui$Internal$Style$classes.opaque)) + ':focus',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'opacity', '1')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot(
					_Utils_ap($mdgriffith$elm_ui$Internal$Style$classes.active, $mdgriffith$elm_ui$Internal$Style$classes.transparent)) + ':active',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'opacity', '0')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot(
					_Utils_ap($mdgriffith$elm_ui$Internal$Style$classes.active, $mdgriffith$elm_ui$Internal$Style$classes.opaque)) + ':active',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'opacity', '1')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.transition),
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Internal$Style$Prop,
						'transition',
						A2(
							$elm$core$String$join,
							', ',
							A2(
								$elm$core$List$map,
								function (x) {
									return x + ' 160ms';
								},
								_List_fromArray(
									['transform', 'opacity', 'filter', 'background-color', 'color', 'font-size']))))
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.scrollbars),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'overflow', 'auto'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-shrink', '1')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.scrollbarsX),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'overflow-x', 'auto'),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.row),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-shrink', '1')
							]))
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.scrollbarsY),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'overflow-y', 'auto'),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.column),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-shrink', '1')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.single),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-shrink', '1')
							]))
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.clip),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'overflow', 'hidden')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.clipX),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'overflow-x', 'hidden')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.clipY),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'overflow-y', 'hidden')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.widthContent),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', 'auto')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.borderNone),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'border-width', '0')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.borderDashed),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'border-style', 'dashed')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.borderDotted),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'border-style', 'dotted')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.borderSolid),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'border-style', 'solid')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.text),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'white-space', 'pre'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'inline-block')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.inputText),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'line-height', '1.05'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'background', 'transparent'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-align', 'inherit')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.single),
				$mdgriffith$elm_ui$Internal$Style$elDescription),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.row),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-direction', 'row'),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.any),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', '0%'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.widthExact),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', 'auto')
									])),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.link),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', 'auto')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.heightFill),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'stretch !important')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.heightFillPortion),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'stretch !important')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.widthFill),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '100000')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.container),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '0'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', 'auto'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'stretch')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						'u:first-of-type.' + $mdgriffith$elm_ui$Internal$Style$classes.alignContainerRight,
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '1')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						's:first-of-type.' + $mdgriffith$elm_ui$Internal$Style$classes.alignContainerCenterX,
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '1'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.alignCenterX),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-left', 'auto !important')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						's:last-of-type.' + $mdgriffith$elm_ui$Internal$Style$classes.alignContainerCenterX,
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '1'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.alignCenterX),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-right', 'auto !important')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						's:only-of-type.' + $mdgriffith$elm_ui$Internal$Style$classes.alignContainerCenterX,
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '1'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.alignCenterY),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-top', 'auto !important'),
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-bottom', 'auto !important')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						's:last-of-type.' + ($mdgriffith$elm_ui$Internal$Style$classes.alignContainerCenterX + ' ~ u'),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '0')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						'u:first-of-type.' + ($mdgriffith$elm_ui$Internal$Style$classes.alignContainerRight + (' ~ s.' + $mdgriffith$elm_ui$Internal$Style$classes.alignContainerCenterX)),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '0')
							])),
						$mdgriffith$elm_ui$Internal$Style$describeAlignment(
						function (alignment) {
							switch (alignment.$) {
								case 'Top':
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'flex-start')
											]),
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'flex-start')
											]));
								case 'Bottom':
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'flex-end')
											]),
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'flex-end')
											]));
								case 'Right':
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'flex-end')
											]),
										_List_Nil);
								case 'Left':
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'flex-start')
											]),
										_List_Nil);
								case 'CenterX':
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'center')
											]),
										_List_Nil);
								default:
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'center')
											]),
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'center')
											]));
							}
						}),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.spaceEvenly),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'space-between')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.inputLabel),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'baseline')
							]))
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.column),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-direction', 'column'),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.any),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', '0px'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'min-height', 'min-content'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.heightExact),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', 'auto')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.heightFill),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '100000')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.widthFill),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.widthFillPortion),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.widthContent),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'flex-start')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						'u:first-of-type.' + $mdgriffith$elm_ui$Internal$Style$classes.alignContainerBottom,
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '1')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						's:first-of-type.' + $mdgriffith$elm_ui$Internal$Style$classes.alignContainerCenterY,
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '1'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.alignCenterY),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-top', 'auto !important'),
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-bottom', '0 !important')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						's:last-of-type.' + $mdgriffith$elm_ui$Internal$Style$classes.alignContainerCenterY,
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '1'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.alignCenterY),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-bottom', 'auto !important'),
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-top', '0 !important')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						's:only-of-type.' + $mdgriffith$elm_ui$Internal$Style$classes.alignContainerCenterY,
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '1'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.alignCenterY),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-top', 'auto !important'),
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-bottom', 'auto !important')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						's:last-of-type.' + ($mdgriffith$elm_ui$Internal$Style$classes.alignContainerCenterY + ' ~ u'),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '0')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						'u:first-of-type.' + ($mdgriffith$elm_ui$Internal$Style$classes.alignContainerBottom + (' ~ s.' + $mdgriffith$elm_ui$Internal$Style$classes.alignContainerCenterY)),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '0')
							])),
						$mdgriffith$elm_ui$Internal$Style$describeAlignment(
						function (alignment) {
							switch (alignment.$) {
								case 'Top':
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'flex-start')
											]),
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-bottom', 'auto')
											]));
								case 'Bottom':
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'flex-end')
											]),
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-top', 'auto')
											]));
								case 'Right':
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'flex-end')
											]),
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'flex-end')
											]));
								case 'Left':
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'flex-start')
											]),
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'flex-start')
											]));
								case 'CenterX':
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'center')
											]),
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'center')
											]));
								default:
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'center')
											]),
										_List_Nil);
							}
						}),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.container),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '0'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', 'auto'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'stretch !important')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.spaceEvenly),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'space-between')
							]))
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.grid),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', '-ms-grid'),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						'.gp',
						_List_fromArray(
							[
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.any),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Supports,
						_Utils_Tuple2('display', 'grid'),
						_List_fromArray(
							[
								_Utils_Tuple2('display', 'grid')
							])),
						$mdgriffith$elm_ui$Internal$Style$gridAlignments(
						function (alignment) {
							switch (alignment.$) {
								case 'Top':
									return _List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'flex-start')
										]);
								case 'Bottom':
									return _List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'flex-end')
										]);
								case 'Right':
									return _List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'flex-end')
										]);
								case 'Left':
									return _List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'flex-start')
										]);
								case 'CenterX':
									return _List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'center')
										]);
								default:
									return _List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'center')
										]);
							}
						})
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.page),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'block'),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.any + ':first-child'),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0 !important')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot(
							$mdgriffith$elm_ui$Internal$Style$classes.any + ($mdgriffith$elm_ui$Internal$Style$selfName(
								$mdgriffith$elm_ui$Internal$Style$Self($mdgriffith$elm_ui$Internal$Style$Left)) + (':first-child + .' + $mdgriffith$elm_ui$Internal$Style$classes.any))),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0 !important')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot(
							$mdgriffith$elm_ui$Internal$Style$classes.any + ($mdgriffith$elm_ui$Internal$Style$selfName(
								$mdgriffith$elm_ui$Internal$Style$Self($mdgriffith$elm_ui$Internal$Style$Right)) + (':first-child + .' + $mdgriffith$elm_ui$Internal$Style$classes.any))),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0 !important')
							])),
						$mdgriffith$elm_ui$Internal$Style$describeAlignment(
						function (alignment) {
							switch (alignment.$) {
								case 'Top':
									return _Utils_Tuple2(_List_Nil, _List_Nil);
								case 'Bottom':
									return _Utils_Tuple2(_List_Nil, _List_Nil);
								case 'Right':
									return _Utils_Tuple2(
										_List_Nil,
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'float', 'right'),
												A2(
												$mdgriffith$elm_ui$Internal$Style$Descriptor,
												'::after',
												_List_fromArray(
													[
														A2($mdgriffith$elm_ui$Internal$Style$Prop, 'content', '\"\"'),
														A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'table'),
														A2($mdgriffith$elm_ui$Internal$Style$Prop, 'clear', 'both')
													]))
											]));
								case 'Left':
									return _Utils_Tuple2(
										_List_Nil,
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'float', 'left'),
												A2(
												$mdgriffith$elm_ui$Internal$Style$Descriptor,
												'::after',
												_List_fromArray(
													[
														A2($mdgriffith$elm_ui$Internal$Style$Prop, 'content', '\"\"'),
														A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'table'),
														A2($mdgriffith$elm_ui$Internal$Style$Prop, 'clear', 'both')
													]))
											]));
								case 'CenterX':
									return _Utils_Tuple2(_List_Nil, _List_Nil);
								default:
									return _Utils_Tuple2(_List_Nil, _List_Nil);
							}
						})
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.inputMultiline),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'white-space', 'pre-wrap !important'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '100%'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'background-color', 'transparent')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.inputMultilineWrapper),
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.single),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', 'auto')
							]))
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.inputMultilineParent),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'white-space', 'pre-wrap !important'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'cursor', 'text'),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.inputMultilineFiller),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'white-space', 'pre-wrap !important'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'color', 'transparent')
							]))
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.paragraph),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'block'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'white-space', 'normal'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'overflow-wrap', 'break-word'),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.hasBehind),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '0'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.behind),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '-1')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$AllChildren,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.text),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'inline'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'white-space', 'normal')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$AllChildren,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.paragraph),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'inline'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								'::after',
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'content', 'none')
									])),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								'::before',
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'content', 'none')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$AllChildren,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.single),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'inline'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'white-space', 'normal'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.widthExact),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'inline-block')
									])),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.inFront),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex')
									])),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.behind),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex')
									])),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.above),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex')
									])),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.below),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex')
									])),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.onRight),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex')
									])),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.onLeft),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex')
									])),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.text),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'inline'),
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'white-space', 'normal')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.row),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'inline')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.column),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'inline-flex')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.grid),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'inline-grid')
							])),
						$mdgriffith$elm_ui$Internal$Style$describeAlignment(
						function (alignment) {
							switch (alignment.$) {
								case 'Top':
									return _Utils_Tuple2(_List_Nil, _List_Nil);
								case 'Bottom':
									return _Utils_Tuple2(_List_Nil, _List_Nil);
								case 'Right':
									return _Utils_Tuple2(
										_List_Nil,
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'float', 'right')
											]));
								case 'Left':
									return _Utils_Tuple2(
										_List_Nil,
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'float', 'left')
											]));
								case 'CenterX':
									return _Utils_Tuple2(_List_Nil, _List_Nil);
								default:
									return _Utils_Tuple2(_List_Nil, _List_Nil);
							}
						})
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				'.hidden',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'none')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.textThin),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', '100')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.textExtraLight),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', '200')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.textLight),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', '300')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.textNormalWeight),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', '400')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.textMedium),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', '500')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.textSemiBold),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', '600')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.bold),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', '700')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.textExtraBold),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', '800')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.textHeavy),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', '900')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.italic),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-style', 'italic')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.strike),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-decoration', 'line-through')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.underline),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-decoration', 'underline'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-decoration-skip-ink', 'auto'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-decoration-skip', 'ink')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				_Utils_ap(
					$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.underline),
					$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.strike)),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-decoration', 'line-through underline'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-decoration-skip-ink', 'auto'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-decoration-skip', 'ink')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.textUnitalicized),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-style', 'normal')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.textJustify),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-align', 'justify')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.textJustifyAll),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-align', 'justify-all')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.textCenter),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-align', 'center')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.textRight),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-align', 'right')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.textLeft),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-align', 'left')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				'.modal',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'fixed'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'left', '0'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'top', '0'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '100%'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'none')
					]))
			]))
	]);
var $mdgriffith$elm_ui$Internal$Style$fontVariant = function (_var) {
	return _List_fromArray(
		[
			A2(
			$mdgriffith$elm_ui$Internal$Style$Class,
			'.v-' + _var,
			_List_fromArray(
				[
					A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-feature-settings', '\"' + (_var + '\"'))
				])),
			A2(
			$mdgriffith$elm_ui$Internal$Style$Class,
			'.v-' + (_var + '-off'),
			_List_fromArray(
				[
					A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-feature-settings', '\"' + (_var + '\" 0'))
				]))
		]);
};
var $mdgriffith$elm_ui$Internal$Style$commonValues = $elm$core$List$concat(
	_List_fromArray(
		[
			A2(
			$elm$core$List$map,
			function (x) {
				return A2(
					$mdgriffith$elm_ui$Internal$Style$Class,
					'.border-' + $elm$core$String$fromInt(x),
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Internal$Style$Prop,
							'border-width',
							$elm$core$String$fromInt(x) + 'px')
						]));
			},
			A2($elm$core$List$range, 0, 6)),
			A2(
			$elm$core$List$map,
			function (i) {
				return A2(
					$mdgriffith$elm_ui$Internal$Style$Class,
					'.font-size-' + $elm$core$String$fromInt(i),
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Internal$Style$Prop,
							'font-size',
							$elm$core$String$fromInt(i) + 'px')
						]));
			},
			A2($elm$core$List$range, 8, 32)),
			A2(
			$elm$core$List$map,
			function (i) {
				return A2(
					$mdgriffith$elm_ui$Internal$Style$Class,
					'.p-' + $elm$core$String$fromInt(i),
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Internal$Style$Prop,
							'padding',
							$elm$core$String$fromInt(i) + 'px')
						]));
			},
			A2($elm$core$List$range, 0, 24)),
			_List_fromArray(
			[
				A2(
				$mdgriffith$elm_ui$Internal$Style$Class,
				'.v-smcp',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-variant', 'small-caps')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Class,
				'.v-smcp-off',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-variant', 'normal')
					]))
			]),
			$mdgriffith$elm_ui$Internal$Style$fontVariant('zero'),
			$mdgriffith$elm_ui$Internal$Style$fontVariant('onum'),
			$mdgriffith$elm_ui$Internal$Style$fontVariant('liga'),
			$mdgriffith$elm_ui$Internal$Style$fontVariant('dlig'),
			$mdgriffith$elm_ui$Internal$Style$fontVariant('ordn'),
			$mdgriffith$elm_ui$Internal$Style$fontVariant('tnum'),
			$mdgriffith$elm_ui$Internal$Style$fontVariant('afrc'),
			$mdgriffith$elm_ui$Internal$Style$fontVariant('frac')
		]));
var $mdgriffith$elm_ui$Internal$Style$explainer = '\n.explain {\n    border: 6px solid rgb(174, 121, 15) !important;\n}\n.explain > .' + ($mdgriffith$elm_ui$Internal$Style$classes.any + (' {\n    border: 4px dashed rgb(0, 151, 167) !important;\n}\n\n.ctr {\n    border: none !important;\n}\n.explain > .ctr > .' + ($mdgriffith$elm_ui$Internal$Style$classes.any + ' {\n    border: 4px dashed rgb(0, 151, 167) !important;\n}\n\n')));
var $mdgriffith$elm_ui$Internal$Style$inputTextReset = '\ninput[type="search"],\ninput[type="search"]::-webkit-search-decoration,\ninput[type="search"]::-webkit-search-cancel-button,\ninput[type="search"]::-webkit-search-results-button,\ninput[type="search"]::-webkit-search-results-decoration {\n  -webkit-appearance:none;\n}\n';
var $mdgriffith$elm_ui$Internal$Style$sliderReset = '\ninput[type=range] {\n  -webkit-appearance: none; \n  background: transparent;\n  position:absolute;\n  left:0;\n  top:0;\n  z-index:10;\n  width: 100%;\n  outline: dashed 1px;\n  height: 100%;\n  opacity: 0;\n}\n';
var $mdgriffith$elm_ui$Internal$Style$thumbReset = '\ninput[type=range]::-webkit-slider-thumb {\n    -webkit-appearance: none;\n    opacity: 0.5;\n    width: 80px;\n    height: 80px;\n    background-color: black;\n    border:none;\n    border-radius: 5px;\n}\ninput[type=range]::-moz-range-thumb {\n    opacity: 0.5;\n    width: 80px;\n    height: 80px;\n    background-color: black;\n    border:none;\n    border-radius: 5px;\n}\ninput[type=range]::-ms-thumb {\n    opacity: 0.5;\n    width: 80px;\n    height: 80px;\n    background-color: black;\n    border:none;\n    border-radius: 5px;\n}\ninput[type=range][orient=vertical]{\n    writing-mode: bt-lr; /* IE */\n    -webkit-appearance: slider-vertical;  /* WebKit */\n}\n';
var $mdgriffith$elm_ui$Internal$Style$trackReset = '\ninput[type=range]::-moz-range-track {\n    background: transparent;\n    cursor: pointer;\n}\ninput[type=range]::-ms-track {\n    background: transparent;\n    cursor: pointer;\n}\ninput[type=range]::-webkit-slider-runnable-track {\n    background: transparent;\n    cursor: pointer;\n}\n';
var $mdgriffith$elm_ui$Internal$Style$overrides = '@media screen and (-ms-high-contrast: active), (-ms-high-contrast: none) {' + ($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.any) + ($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.row) + (' > ' + ($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.any) + (' { flex-basis: auto !important; } ' + ($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.any) + ($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.row) + (' > ' + ($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.any) + ($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.container) + (' { flex-basis: auto !important; }}' + ($mdgriffith$elm_ui$Internal$Style$inputTextReset + ($mdgriffith$elm_ui$Internal$Style$sliderReset + ($mdgriffith$elm_ui$Internal$Style$trackReset + ($mdgriffith$elm_ui$Internal$Style$thumbReset + $mdgriffith$elm_ui$Internal$Style$explainer)))))))))))))));
var $elm$core$String$concat = function (strings) {
	return A2($elm$core$String$join, '', strings);
};
var $mdgriffith$elm_ui$Internal$Style$Intermediate = function (a) {
	return {$: 'Intermediate', a: a};
};
var $mdgriffith$elm_ui$Internal$Style$emptyIntermediate = F2(
	function (selector, closing) {
		return $mdgriffith$elm_ui$Internal$Style$Intermediate(
			{closing: closing, others: _List_Nil, props: _List_Nil, selector: selector});
	});
var $mdgriffith$elm_ui$Internal$Style$renderRules = F2(
	function (_v0, rulesToRender) {
		var parent = _v0.a;
		var generateIntermediates = F2(
			function (rule, rendered) {
				switch (rule.$) {
					case 'Prop':
						var name = rule.a;
						var val = rule.b;
						return _Utils_update(
							rendered,
							{
								props: A2(
									$elm$core$List$cons,
									_Utils_Tuple2(name, val),
									rendered.props)
							});
					case 'Supports':
						var _v2 = rule.a;
						var prop = _v2.a;
						var value = _v2.b;
						var props = rule.b;
						return _Utils_update(
							rendered,
							{
								others: A2(
									$elm$core$List$cons,
									$mdgriffith$elm_ui$Internal$Style$Intermediate(
										{closing: '\n}', others: _List_Nil, props: props, selector: '@supports (' + (prop + (':' + (value + (') {' + parent.selector))))}),
									rendered.others)
							});
					case 'Adjacent':
						var selector = rule.a;
						var adjRules = rule.b;
						return _Utils_update(
							rendered,
							{
								others: A2(
									$elm$core$List$cons,
									A2(
										$mdgriffith$elm_ui$Internal$Style$renderRules,
										A2($mdgriffith$elm_ui$Internal$Style$emptyIntermediate, parent.selector + (' + ' + selector), ''),
										adjRules),
									rendered.others)
							});
					case 'Child':
						var child = rule.a;
						var childRules = rule.b;
						return _Utils_update(
							rendered,
							{
								others: A2(
									$elm$core$List$cons,
									A2(
										$mdgriffith$elm_ui$Internal$Style$renderRules,
										A2($mdgriffith$elm_ui$Internal$Style$emptyIntermediate, parent.selector + (' > ' + child), ''),
										childRules),
									rendered.others)
							});
					case 'AllChildren':
						var child = rule.a;
						var childRules = rule.b;
						return _Utils_update(
							rendered,
							{
								others: A2(
									$elm$core$List$cons,
									A2(
										$mdgriffith$elm_ui$Internal$Style$renderRules,
										A2($mdgriffith$elm_ui$Internal$Style$emptyIntermediate, parent.selector + (' ' + child), ''),
										childRules),
									rendered.others)
							});
					case 'Descriptor':
						var descriptor = rule.a;
						var descriptorRules = rule.b;
						return _Utils_update(
							rendered,
							{
								others: A2(
									$elm$core$List$cons,
									A2(
										$mdgriffith$elm_ui$Internal$Style$renderRules,
										A2(
											$mdgriffith$elm_ui$Internal$Style$emptyIntermediate,
											_Utils_ap(parent.selector, descriptor),
											''),
										descriptorRules),
									rendered.others)
							});
					default:
						var batched = rule.a;
						return _Utils_update(
							rendered,
							{
								others: A2(
									$elm$core$List$cons,
									A2(
										$mdgriffith$elm_ui$Internal$Style$renderRules,
										A2($mdgriffith$elm_ui$Internal$Style$emptyIntermediate, parent.selector, ''),
										batched),
									rendered.others)
							});
				}
			});
		return $mdgriffith$elm_ui$Internal$Style$Intermediate(
			A3($elm$core$List$foldr, generateIntermediates, parent, rulesToRender));
	});
var $mdgriffith$elm_ui$Internal$Style$renderCompact = function (styleClasses) {
	var renderValues = function (values) {
		return $elm$core$String$concat(
			A2(
				$elm$core$List$map,
				function (_v3) {
					var x = _v3.a;
					var y = _v3.b;
					return x + (':' + (y + ';'));
				},
				values));
	};
	var renderClass = function (rule) {
		var _v2 = rule.props;
		if (!_v2.b) {
			return '';
		} else {
			return rule.selector + ('{' + (renderValues(rule.props) + (rule.closing + '}')));
		}
	};
	var renderIntermediate = function (_v0) {
		var rule = _v0.a;
		return _Utils_ap(
			renderClass(rule),
			$elm$core$String$concat(
				A2($elm$core$List$map, renderIntermediate, rule.others)));
	};
	return $elm$core$String$concat(
		A2(
			$elm$core$List$map,
			renderIntermediate,
			A3(
				$elm$core$List$foldr,
				F2(
					function (_v1, existing) {
						var name = _v1.a;
						var styleRules = _v1.b;
						return A2(
							$elm$core$List$cons,
							A2(
								$mdgriffith$elm_ui$Internal$Style$renderRules,
								A2($mdgriffith$elm_ui$Internal$Style$emptyIntermediate, name, ''),
								styleRules),
							existing);
					}),
				_List_Nil,
				styleClasses)));
};
var $mdgriffith$elm_ui$Internal$Style$rules = _Utils_ap(
	$mdgriffith$elm_ui$Internal$Style$overrides,
	$mdgriffith$elm_ui$Internal$Style$renderCompact(
		_Utils_ap($mdgriffith$elm_ui$Internal$Style$baseSheet, $mdgriffith$elm_ui$Internal$Style$commonValues)));
var $elm$virtual_dom$VirtualDom$text = _VirtualDom_text;
var $mdgriffith$elm_ui$Internal$Model$staticRoot = function (opts) {
	var _v0 = opts.mode;
	switch (_v0.$) {
		case 'Layout':
			return A3(
				$elm$virtual_dom$VirtualDom$node,
				'div',
				_List_Nil,
				_List_fromArray(
					[
						A3(
						$elm$virtual_dom$VirtualDom$node,
						'style',
						_List_Nil,
						_List_fromArray(
							[
								$elm$virtual_dom$VirtualDom$text($mdgriffith$elm_ui$Internal$Style$rules)
							]))
					]));
		case 'NoStaticStyleSheet':
			return $elm$virtual_dom$VirtualDom$text('');
		default:
			return A3(
				$elm$virtual_dom$VirtualDom$node,
				'elm-ui-static-rules',
				_List_fromArray(
					[
						A2(
						$elm$virtual_dom$VirtualDom$property,
						'rules',
						$elm$json$Json$Encode$string($mdgriffith$elm_ui$Internal$Style$rules))
					]),
				_List_Nil);
	}
};
var $elm$json$Json$Encode$list = F2(
	function (func, entries) {
		return _Json_wrap(
			A3(
				$elm$core$List$foldl,
				_Json_addEntry(func),
				_Json_emptyArray(_Utils_Tuple0),
				entries));
	});
var $elm$json$Json$Encode$object = function (pairs) {
	return _Json_wrap(
		A3(
			$elm$core$List$foldl,
			F2(
				function (_v0, obj) {
					var k = _v0.a;
					var v = _v0.b;
					return A3(_Json_addField, k, v, obj);
				}),
			_Json_emptyObject(_Utils_Tuple0),
			pairs));
};
var $elm$core$List$any = F2(
	function (isOkay, list) {
		any:
		while (true) {
			if (!list.b) {
				return false;
			} else {
				var x = list.a;
				var xs = list.b;
				if (isOkay(x)) {
					return true;
				} else {
					var $temp$isOkay = isOkay,
						$temp$list = xs;
					isOkay = $temp$isOkay;
					list = $temp$list;
					continue any;
				}
			}
		}
	});
var $mdgriffith$elm_ui$Internal$Model$fontName = function (font) {
	switch (font.$) {
		case 'Serif':
			return 'serif';
		case 'SansSerif':
			return 'sans-serif';
		case 'Monospace':
			return 'monospace';
		case 'Typeface':
			var name = font.a;
			return '\"' + (name + '\"');
		case 'ImportFont':
			var name = font.a;
			var url = font.b;
			return '\"' + (name + '\"');
		default:
			var name = font.a.name;
			return '\"' + (name + '\"');
	}
};
var $mdgriffith$elm_ui$Internal$Model$isSmallCaps = function (_var) {
	switch (_var.$) {
		case 'VariantActive':
			var name = _var.a;
			return name === 'smcp';
		case 'VariantOff':
			var name = _var.a;
			return false;
		default:
			var name = _var.a;
			var index = _var.b;
			return (name === 'smcp') && (index === 1);
	}
};
var $mdgriffith$elm_ui$Internal$Model$hasSmallCaps = function (typeface) {
	if (typeface.$ === 'FontWith') {
		var font = typeface.a;
		return A2($elm$core$List$any, $mdgriffith$elm_ui$Internal$Model$isSmallCaps, font.variants);
	} else {
		return false;
	}
};
var $elm$core$Basics$min = F2(
	function (x, y) {
		return (_Utils_cmp(x, y) < 0) ? x : y;
	});
var $elm$core$Basics$negate = function (n) {
	return -n;
};
var $mdgriffith$elm_ui$Internal$Model$renderProps = F3(
	function (force, _v0, existing) {
		var key = _v0.a;
		var val = _v0.b;
		return force ? (existing + ('\n  ' + (key + (': ' + (val + ' !important;'))))) : (existing + ('\n  ' + (key + (': ' + (val + ';')))));
	});
var $mdgriffith$elm_ui$Internal$Model$renderStyle = F4(
	function (options, maybePseudo, selector, props) {
		if (maybePseudo.$ === 'Nothing') {
			return _List_fromArray(
				[
					selector + ('{' + (A3(
					$elm$core$List$foldl,
					$mdgriffith$elm_ui$Internal$Model$renderProps(false),
					'',
					props) + '\n}'))
				]);
		} else {
			var pseudo = maybePseudo.a;
			switch (pseudo.$) {
				case 'Hover':
					var _v2 = options.hover;
					switch (_v2.$) {
						case 'NoHover':
							return _List_Nil;
						case 'ForceHover':
							return _List_fromArray(
								[
									selector + ('-hv {' + (A3(
									$elm$core$List$foldl,
									$mdgriffith$elm_ui$Internal$Model$renderProps(true),
									'',
									props) + '\n}'))
								]);
						default:
							return _List_fromArray(
								[
									selector + ('-hv:hover {' + (A3(
									$elm$core$List$foldl,
									$mdgriffith$elm_ui$Internal$Model$renderProps(false),
									'',
									props) + '\n}'))
								]);
					}
				case 'Focus':
					var renderedProps = A3(
						$elm$core$List$foldl,
						$mdgriffith$elm_ui$Internal$Model$renderProps(false),
						'',
						props);
					return _List_fromArray(
						[
							selector + ('-fs:focus {' + (renderedProps + '\n}')),
							('.' + ($mdgriffith$elm_ui$Internal$Style$classes.any + (':focus ' + (selector + '-fs  {')))) + (renderedProps + '\n}'),
							(selector + '-fs:focus-within {') + (renderedProps + '\n}'),
							('.ui-slide-bar:focus + ' + ($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.any) + (' .focusable-thumb' + (selector + '-fs {')))) + (renderedProps + '\n}')
						]);
				default:
					return _List_fromArray(
						[
							selector + ('-act:active {' + (A3(
							$elm$core$List$foldl,
							$mdgriffith$elm_ui$Internal$Model$renderProps(false),
							'',
							props) + '\n}'))
						]);
			}
		}
	});
var $mdgriffith$elm_ui$Internal$Model$renderVariant = function (_var) {
	switch (_var.$) {
		case 'VariantActive':
			var name = _var.a;
			return '\"' + (name + '\"');
		case 'VariantOff':
			var name = _var.a;
			return '\"' + (name + '\" 0');
		default:
			var name = _var.a;
			var index = _var.b;
			return '\"' + (name + ('\" ' + $elm$core$String$fromInt(index)));
	}
};
var $mdgriffith$elm_ui$Internal$Model$renderVariants = function (typeface) {
	if (typeface.$ === 'FontWith') {
		var font = typeface.a;
		return $elm$core$Maybe$Just(
			A2(
				$elm$core$String$join,
				', ',
				A2($elm$core$List$map, $mdgriffith$elm_ui$Internal$Model$renderVariant, font.variants)));
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $mdgriffith$elm_ui$Internal$Model$transformValue = function (transform) {
	switch (transform.$) {
		case 'Untransformed':
			return $elm$core$Maybe$Nothing;
		case 'Moved':
			var _v1 = transform.a;
			var x = _v1.a;
			var y = _v1.b;
			var z = _v1.c;
			return $elm$core$Maybe$Just(
				'translate3d(' + ($elm$core$String$fromFloat(x) + ('px, ' + ($elm$core$String$fromFloat(y) + ('px, ' + ($elm$core$String$fromFloat(z) + 'px)'))))));
		default:
			var _v2 = transform.a;
			var tx = _v2.a;
			var ty = _v2.b;
			var tz = _v2.c;
			var _v3 = transform.b;
			var sx = _v3.a;
			var sy = _v3.b;
			var sz = _v3.c;
			var _v4 = transform.c;
			var ox = _v4.a;
			var oy = _v4.b;
			var oz = _v4.c;
			var angle = transform.d;
			var translate = 'translate3d(' + ($elm$core$String$fromFloat(tx) + ('px, ' + ($elm$core$String$fromFloat(ty) + ('px, ' + ($elm$core$String$fromFloat(tz) + 'px)')))));
			var scale = 'scale3d(' + ($elm$core$String$fromFloat(sx) + (', ' + ($elm$core$String$fromFloat(sy) + (', ' + ($elm$core$String$fromFloat(sz) + ')')))));
			var rotate = 'rotate3d(' + ($elm$core$String$fromFloat(ox) + (', ' + ($elm$core$String$fromFloat(oy) + (', ' + ($elm$core$String$fromFloat(oz) + (', ' + ($elm$core$String$fromFloat(angle) + 'rad)')))))));
			return $elm$core$Maybe$Just(translate + (' ' + (scale + (' ' + rotate))));
	}
};
var $mdgriffith$elm_ui$Internal$Model$renderStyleRule = F3(
	function (options, rule, maybePseudo) {
		switch (rule.$) {
			case 'Style':
				var selector = rule.a;
				var props = rule.b;
				return A4($mdgriffith$elm_ui$Internal$Model$renderStyle, options, maybePseudo, selector, props);
			case 'Shadows':
				var name = rule.a;
				var prop = rule.b;
				return A4(
					$mdgriffith$elm_ui$Internal$Model$renderStyle,
					options,
					maybePseudo,
					'.' + name,
					_List_fromArray(
						[
							A2($mdgriffith$elm_ui$Internal$Model$Property, 'box-shadow', prop)
						]));
			case 'Transparency':
				var name = rule.a;
				var transparency = rule.b;
				var opacity = A2(
					$elm$core$Basics$max,
					0,
					A2($elm$core$Basics$min, 1, 1 - transparency));
				return A4(
					$mdgriffith$elm_ui$Internal$Model$renderStyle,
					options,
					maybePseudo,
					'.' + name,
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Internal$Model$Property,
							'opacity',
							$elm$core$String$fromFloat(opacity))
						]));
			case 'FontSize':
				var i = rule.a;
				return A4(
					$mdgriffith$elm_ui$Internal$Model$renderStyle,
					options,
					maybePseudo,
					'.font-size-' + $elm$core$String$fromInt(i),
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Internal$Model$Property,
							'font-size',
							$elm$core$String$fromInt(i) + 'px')
						]));
			case 'FontFamily':
				var name = rule.a;
				var typefaces = rule.b;
				var features = A2(
					$elm$core$String$join,
					', ',
					A2($elm$core$List$filterMap, $mdgriffith$elm_ui$Internal$Model$renderVariants, typefaces));
				var families = _List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Internal$Model$Property,
						'font-family',
						A2(
							$elm$core$String$join,
							', ',
							A2($elm$core$List$map, $mdgriffith$elm_ui$Internal$Model$fontName, typefaces))),
						A2($mdgriffith$elm_ui$Internal$Model$Property, 'font-feature-settings', features),
						A2(
						$mdgriffith$elm_ui$Internal$Model$Property,
						'font-variant',
						A2($elm$core$List$any, $mdgriffith$elm_ui$Internal$Model$hasSmallCaps, typefaces) ? 'small-caps' : 'normal')
					]);
				return A4($mdgriffith$elm_ui$Internal$Model$renderStyle, options, maybePseudo, '.' + name, families);
			case 'Single':
				var _class = rule.a;
				var prop = rule.b;
				var val = rule.c;
				return A4(
					$mdgriffith$elm_ui$Internal$Model$renderStyle,
					options,
					maybePseudo,
					'.' + _class,
					_List_fromArray(
						[
							A2($mdgriffith$elm_ui$Internal$Model$Property, prop, val)
						]));
			case 'Colored':
				var _class = rule.a;
				var prop = rule.b;
				var color = rule.c;
				return A4(
					$mdgriffith$elm_ui$Internal$Model$renderStyle,
					options,
					maybePseudo,
					'.' + _class,
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Internal$Model$Property,
							prop,
							$mdgriffith$elm_ui$Internal$Model$formatColor(color))
						]));
			case 'SpacingStyle':
				var cls = rule.a;
				var x = rule.b;
				var y = rule.c;
				var yPx = $elm$core$String$fromInt(y) + 'px';
				var xPx = $elm$core$String$fromInt(x) + 'px';
				var single = '.' + $mdgriffith$elm_ui$Internal$Style$classes.single;
				var row = '.' + $mdgriffith$elm_ui$Internal$Style$classes.row;
				var wrappedRow = '.' + ($mdgriffith$elm_ui$Internal$Style$classes.wrapped + row);
				var right = '.' + $mdgriffith$elm_ui$Internal$Style$classes.alignRight;
				var paragraph = '.' + $mdgriffith$elm_ui$Internal$Style$classes.paragraph;
				var page = '.' + $mdgriffith$elm_ui$Internal$Style$classes.page;
				var left = '.' + $mdgriffith$elm_ui$Internal$Style$classes.alignLeft;
				var halfY = $elm$core$String$fromFloat(y / 2) + 'px';
				var halfX = $elm$core$String$fromFloat(x / 2) + 'px';
				var column = '.' + $mdgriffith$elm_ui$Internal$Style$classes.column;
				var _class = '.' + cls;
				var any = '.' + $mdgriffith$elm_ui$Internal$Style$classes.any;
				return $elm$core$List$concat(
					_List_fromArray(
						[
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (row + (' > ' + (any + (' + ' + any)))),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'margin-left', xPx)
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (wrappedRow + (' > ' + any)),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'margin', halfY + (' ' + halfX))
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (column + (' > ' + (any + (' + ' + any)))),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'margin-top', yPx)
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (page + (' > ' + (any + (' + ' + any)))),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'margin-top', yPx)
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (page + (' > ' + left)),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'margin-right', xPx)
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (page + (' > ' + right)),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'margin-left', xPx)
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_Utils_ap(_class, paragraph),
							_List_fromArray(
								[
									A2(
									$mdgriffith$elm_ui$Internal$Model$Property,
									'line-height',
									'calc(1em + ' + ($elm$core$String$fromInt(y) + 'px)'))
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							'textarea' + (any + _class),
							_List_fromArray(
								[
									A2(
									$mdgriffith$elm_ui$Internal$Model$Property,
									'line-height',
									'calc(1em + ' + ($elm$core$String$fromInt(y) + 'px)')),
									A2(
									$mdgriffith$elm_ui$Internal$Model$Property,
									'height',
									'calc(100% + ' + ($elm$core$String$fromInt(y) + 'px)'))
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (paragraph + (' > ' + left)),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'margin-right', xPx)
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (paragraph + (' > ' + right)),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'margin-left', xPx)
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (paragraph + '::after'),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'content', '\'\''),
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'display', 'block'),
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'height', '0'),
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'width', '0'),
									A2(
									$mdgriffith$elm_ui$Internal$Model$Property,
									'margin-top',
									$elm$core$String$fromInt((-1) * ((y / 2) | 0)) + 'px')
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (paragraph + '::before'),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'content', '\'\''),
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'display', 'block'),
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'height', '0'),
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'width', '0'),
									A2(
									$mdgriffith$elm_ui$Internal$Model$Property,
									'margin-bottom',
									$elm$core$String$fromInt((-1) * ((y / 2) | 0)) + 'px')
								]))
						]));
			case 'PaddingStyle':
				var cls = rule.a;
				var top = rule.b;
				var right = rule.c;
				var bottom = rule.d;
				var left = rule.e;
				var _class = '.' + cls;
				return A4(
					$mdgriffith$elm_ui$Internal$Model$renderStyle,
					options,
					maybePseudo,
					_class,
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Internal$Model$Property,
							'padding',
							$elm$core$String$fromFloat(top) + ('px ' + ($elm$core$String$fromFloat(right) + ('px ' + ($elm$core$String$fromFloat(bottom) + ('px ' + ($elm$core$String$fromFloat(left) + 'px')))))))
						]));
			case 'BorderWidth':
				var cls = rule.a;
				var top = rule.b;
				var right = rule.c;
				var bottom = rule.d;
				var left = rule.e;
				var _class = '.' + cls;
				return A4(
					$mdgriffith$elm_ui$Internal$Model$renderStyle,
					options,
					maybePseudo,
					_class,
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Internal$Model$Property,
							'border-width',
							$elm$core$String$fromInt(top) + ('px ' + ($elm$core$String$fromInt(right) + ('px ' + ($elm$core$String$fromInt(bottom) + ('px ' + ($elm$core$String$fromInt(left) + 'px')))))))
						]));
			case 'GridTemplateStyle':
				var template = rule.a;
				var toGridLengthHelper = F3(
					function (minimum, maximum, x) {
						toGridLengthHelper:
						while (true) {
							switch (x.$) {
								case 'Px':
									var px = x.a;
									return $elm$core$String$fromInt(px) + 'px';
								case 'Content':
									var _v2 = _Utils_Tuple2(minimum, maximum);
									if (_v2.a.$ === 'Nothing') {
										if (_v2.b.$ === 'Nothing') {
											var _v3 = _v2.a;
											var _v4 = _v2.b;
											return 'max-content';
										} else {
											var _v6 = _v2.a;
											var maxSize = _v2.b.a;
											return 'minmax(max-content, ' + ($elm$core$String$fromInt(maxSize) + 'px)');
										}
									} else {
										if (_v2.b.$ === 'Nothing') {
											var minSize = _v2.a.a;
											var _v5 = _v2.b;
											return 'minmax(' + ($elm$core$String$fromInt(minSize) + ('px, ' + 'max-content)'));
										} else {
											var minSize = _v2.a.a;
											var maxSize = _v2.b.a;
											return 'minmax(' + ($elm$core$String$fromInt(minSize) + ('px, ' + ($elm$core$String$fromInt(maxSize) + 'px)')));
										}
									}
								case 'Fill':
									var i = x.a;
									var _v7 = _Utils_Tuple2(minimum, maximum);
									if (_v7.a.$ === 'Nothing') {
										if (_v7.b.$ === 'Nothing') {
											var _v8 = _v7.a;
											var _v9 = _v7.b;
											return $elm$core$String$fromInt(i) + 'fr';
										} else {
											var _v11 = _v7.a;
											var maxSize = _v7.b.a;
											return 'minmax(max-content, ' + ($elm$core$String$fromInt(maxSize) + 'px)');
										}
									} else {
										if (_v7.b.$ === 'Nothing') {
											var minSize = _v7.a.a;
											var _v10 = _v7.b;
											return 'minmax(' + ($elm$core$String$fromInt(minSize) + ('px, ' + ($elm$core$String$fromInt(i) + ('fr' + 'fr)'))));
										} else {
											var minSize = _v7.a.a;
											var maxSize = _v7.b.a;
											return 'minmax(' + ($elm$core$String$fromInt(minSize) + ('px, ' + ($elm$core$String$fromInt(maxSize) + 'px)')));
										}
									}
								case 'Min':
									var m = x.a;
									var len = x.b;
									var $temp$minimum = $elm$core$Maybe$Just(m),
										$temp$maximum = maximum,
										$temp$x = len;
									minimum = $temp$minimum;
									maximum = $temp$maximum;
									x = $temp$x;
									continue toGridLengthHelper;
								default:
									var m = x.a;
									var len = x.b;
									var $temp$minimum = minimum,
										$temp$maximum = $elm$core$Maybe$Just(m),
										$temp$x = len;
									minimum = $temp$minimum;
									maximum = $temp$maximum;
									x = $temp$x;
									continue toGridLengthHelper;
							}
						}
					});
				var toGridLength = function (x) {
					return A3(toGridLengthHelper, $elm$core$Maybe$Nothing, $elm$core$Maybe$Nothing, x);
				};
				var xSpacing = toGridLength(template.spacing.a);
				var ySpacing = toGridLength(template.spacing.b);
				var rows = function (x) {
					return 'grid-template-rows: ' + (x + ';');
				}(
					A2(
						$elm$core$String$join,
						' ',
						A2($elm$core$List$map, toGridLength, template.rows)));
				var msRows = function (x) {
					return '-ms-grid-rows: ' + (x + ';');
				}(
					A2(
						$elm$core$String$join,
						ySpacing,
						A2($elm$core$List$map, toGridLength, template.columns)));
				var msColumns = function (x) {
					return '-ms-grid-columns: ' + (x + ';');
				}(
					A2(
						$elm$core$String$join,
						ySpacing,
						A2($elm$core$List$map, toGridLength, template.columns)));
				var gapY = 'grid-row-gap:' + (toGridLength(template.spacing.b) + ';');
				var gapX = 'grid-column-gap:' + (toGridLength(template.spacing.a) + ';');
				var columns = function (x) {
					return 'grid-template-columns: ' + (x + ';');
				}(
					A2(
						$elm$core$String$join,
						' ',
						A2($elm$core$List$map, toGridLength, template.columns)));
				var _class = '.grid-rows-' + (A2(
					$elm$core$String$join,
					'-',
					A2($elm$core$List$map, $mdgriffith$elm_ui$Internal$Model$lengthClassName, template.rows)) + ('-cols-' + (A2(
					$elm$core$String$join,
					'-',
					A2($elm$core$List$map, $mdgriffith$elm_ui$Internal$Model$lengthClassName, template.columns)) + ('-space-x-' + ($mdgriffith$elm_ui$Internal$Model$lengthClassName(template.spacing.a) + ('-space-y-' + $mdgriffith$elm_ui$Internal$Model$lengthClassName(template.spacing.b)))))));
				var modernGrid = _class + ('{' + (columns + (rows + (gapX + (gapY + '}')))));
				var supports = '@supports (display:grid) {' + (modernGrid + '}');
				var base = _class + ('{' + (msColumns + (msRows + '}')));
				return _List_fromArray(
					[base, supports]);
			case 'GridPosition':
				var position = rule.a;
				var msPosition = A2(
					$elm$core$String$join,
					' ',
					_List_fromArray(
						[
							'-ms-grid-row: ' + ($elm$core$String$fromInt(position.row) + ';'),
							'-ms-grid-row-span: ' + ($elm$core$String$fromInt(position.height) + ';'),
							'-ms-grid-column: ' + ($elm$core$String$fromInt(position.col) + ';'),
							'-ms-grid-column-span: ' + ($elm$core$String$fromInt(position.width) + ';')
						]));
				var modernPosition = A2(
					$elm$core$String$join,
					' ',
					_List_fromArray(
						[
							'grid-row: ' + ($elm$core$String$fromInt(position.row) + (' / ' + ($elm$core$String$fromInt(position.row + position.height) + ';'))),
							'grid-column: ' + ($elm$core$String$fromInt(position.col) + (' / ' + ($elm$core$String$fromInt(position.col + position.width) + ';')))
						]));
				var _class = '.grid-pos-' + ($elm$core$String$fromInt(position.row) + ('-' + ($elm$core$String$fromInt(position.col) + ('-' + ($elm$core$String$fromInt(position.width) + ('-' + $elm$core$String$fromInt(position.height)))))));
				var modernGrid = _class + ('{' + (modernPosition + '}'));
				var supports = '@supports (display:grid) {' + (modernGrid + '}');
				var base = _class + ('{' + (msPosition + '}'));
				return _List_fromArray(
					[base, supports]);
			case 'PseudoSelector':
				var _class = rule.a;
				var styles = rule.b;
				var renderPseudoRule = function (style) {
					return A3(
						$mdgriffith$elm_ui$Internal$Model$renderStyleRule,
						options,
						style,
						$elm$core$Maybe$Just(_class));
				};
				return A2($elm$core$List$concatMap, renderPseudoRule, styles);
			default:
				var transform = rule.a;
				var val = $mdgriffith$elm_ui$Internal$Model$transformValue(transform);
				var _class = $mdgriffith$elm_ui$Internal$Model$transformClass(transform);
				var _v12 = _Utils_Tuple2(_class, val);
				if ((_v12.a.$ === 'Just') && (_v12.b.$ === 'Just')) {
					var cls = _v12.a.a;
					var v = _v12.b.a;
					return A4(
						$mdgriffith$elm_ui$Internal$Model$renderStyle,
						options,
						maybePseudo,
						'.' + cls,
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Model$Property, 'transform', v)
							]));
				} else {
					return _List_Nil;
				}
		}
	});
var $mdgriffith$elm_ui$Internal$Model$encodeStyles = F2(
	function (options, stylesheet) {
		return $elm$json$Json$Encode$object(
			A2(
				$elm$core$List$map,
				function (style) {
					var styled = A3($mdgriffith$elm_ui$Internal$Model$renderStyleRule, options, style, $elm$core$Maybe$Nothing);
					return _Utils_Tuple2(
						$mdgriffith$elm_ui$Internal$Model$getStyleName(style),
						A2($elm$json$Json$Encode$list, $elm$json$Json$Encode$string, styled));
				},
				stylesheet));
	});
var $mdgriffith$elm_ui$Internal$Model$bracket = F2(
	function (selector, rules) {
		var renderPair = function (_v0) {
			var name = _v0.a;
			var val = _v0.b;
			return name + (': ' + (val + ';'));
		};
		return selector + (' {' + (A2(
			$elm$core$String$join,
			'',
			A2($elm$core$List$map, renderPair, rules)) + '}'));
	});
var $mdgriffith$elm_ui$Internal$Model$fontRule = F3(
	function (name, modifier, _v0) {
		var parentAdj = _v0.a;
		var textAdjustment = _v0.b;
		return _List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Model$bracket, '.' + (name + ('.' + (modifier + (', ' + ('.' + (name + (' .' + modifier))))))), parentAdj),
				A2($mdgriffith$elm_ui$Internal$Model$bracket, '.' + (name + ('.' + (modifier + ('> .' + ($mdgriffith$elm_ui$Internal$Style$classes.text + (', .' + (name + (' .' + (modifier + (' > .' + $mdgriffith$elm_ui$Internal$Style$classes.text)))))))))), textAdjustment)
			]);
	});
var $mdgriffith$elm_ui$Internal$Model$renderFontAdjustmentRule = F3(
	function (fontToAdjust, _v0, otherFontName) {
		var full = _v0.a;
		var capital = _v0.b;
		var name = _Utils_eq(fontToAdjust, otherFontName) ? fontToAdjust : (otherFontName + (' .' + fontToAdjust));
		return A2(
			$elm$core$String$join,
			' ',
			_Utils_ap(
				A3($mdgriffith$elm_ui$Internal$Model$fontRule, name, $mdgriffith$elm_ui$Internal$Style$classes.sizeByCapital, capital),
				A3($mdgriffith$elm_ui$Internal$Model$fontRule, name, $mdgriffith$elm_ui$Internal$Style$classes.fullSize, full)));
	});
var $mdgriffith$elm_ui$Internal$Model$renderNullAdjustmentRule = F2(
	function (fontToAdjust, otherFontName) {
		var name = _Utils_eq(fontToAdjust, otherFontName) ? fontToAdjust : (otherFontName + (' .' + fontToAdjust));
		return A2(
			$elm$core$String$join,
			' ',
			_List_fromArray(
				[
					A2(
					$mdgriffith$elm_ui$Internal$Model$bracket,
					'.' + (name + ('.' + ($mdgriffith$elm_ui$Internal$Style$classes.sizeByCapital + (', ' + ('.' + (name + (' .' + $mdgriffith$elm_ui$Internal$Style$classes.sizeByCapital))))))),
					_List_fromArray(
						[
							_Utils_Tuple2('line-height', '1')
						])),
					A2(
					$mdgriffith$elm_ui$Internal$Model$bracket,
					'.' + (name + ('.' + ($mdgriffith$elm_ui$Internal$Style$classes.sizeByCapital + ('> .' + ($mdgriffith$elm_ui$Internal$Style$classes.text + (', .' + (name + (' .' + ($mdgriffith$elm_ui$Internal$Style$classes.sizeByCapital + (' > .' + $mdgriffith$elm_ui$Internal$Style$classes.text)))))))))),
					_List_fromArray(
						[
							_Utils_Tuple2('vertical-align', '0'),
							_Utils_Tuple2('line-height', '1')
						]))
				]));
	});
var $mdgriffith$elm_ui$Internal$Model$adjust = F3(
	function (size, height, vertical) {
		return {height: height / size, size: size, vertical: vertical};
	});
var $elm$core$List$maximum = function (list) {
	if (list.b) {
		var x = list.a;
		var xs = list.b;
		return $elm$core$Maybe$Just(
			A3($elm$core$List$foldl, $elm$core$Basics$max, x, xs));
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $elm$core$List$minimum = function (list) {
	if (list.b) {
		var x = list.a;
		var xs = list.b;
		return $elm$core$Maybe$Just(
			A3($elm$core$List$foldl, $elm$core$Basics$min, x, xs));
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $elm$core$Basics$neq = _Utils_notEqual;
var $mdgriffith$elm_ui$Internal$Model$convertAdjustment = function (adjustment) {
	var lines = _List_fromArray(
		[adjustment.capital, adjustment.baseline, adjustment.descender, adjustment.lowercase]);
	var lineHeight = 1.5;
	var normalDescender = (lineHeight - 1) / 2;
	var oldMiddle = lineHeight / 2;
	var descender = A2(
		$elm$core$Maybe$withDefault,
		adjustment.descender,
		$elm$core$List$minimum(lines));
	var newBaseline = A2(
		$elm$core$Maybe$withDefault,
		adjustment.baseline,
		$elm$core$List$minimum(
			A2(
				$elm$core$List$filter,
				function (x) {
					return !_Utils_eq(x, descender);
				},
				lines)));
	var base = lineHeight;
	var ascender = A2(
		$elm$core$Maybe$withDefault,
		adjustment.capital,
		$elm$core$List$maximum(lines));
	var capitalSize = 1 / (ascender - newBaseline);
	var capitalVertical = 1 - ascender;
	var fullSize = 1 / (ascender - descender);
	var fullVertical = 1 - ascender;
	var newCapitalMiddle = ((ascender - newBaseline) / 2) + newBaseline;
	var newFullMiddle = ((ascender - descender) / 2) + descender;
	return {
		capital: A3($mdgriffith$elm_ui$Internal$Model$adjust, capitalSize, ascender - newBaseline, capitalVertical),
		full: A3($mdgriffith$elm_ui$Internal$Model$adjust, fullSize, ascender - descender, fullVertical)
	};
};
var $mdgriffith$elm_ui$Internal$Model$fontAdjustmentRules = function (converted) {
	return _Utils_Tuple2(
		_List_fromArray(
			[
				_Utils_Tuple2('display', 'block')
			]),
		_List_fromArray(
			[
				_Utils_Tuple2('display', 'inline-block'),
				_Utils_Tuple2(
				'line-height',
				$elm$core$String$fromFloat(converted.height)),
				_Utils_Tuple2(
				'vertical-align',
				$elm$core$String$fromFloat(converted.vertical) + 'em'),
				_Utils_Tuple2(
				'font-size',
				$elm$core$String$fromFloat(converted.size) + 'em')
			]));
};
var $mdgriffith$elm_ui$Internal$Model$typefaceAdjustment = function (typefaces) {
	return A3(
		$elm$core$List$foldl,
		F2(
			function (face, found) {
				if (found.$ === 'Nothing') {
					if (face.$ === 'FontWith') {
						var _with = face.a;
						var _v2 = _with.adjustment;
						if (_v2.$ === 'Nothing') {
							return found;
						} else {
							var adjustment = _v2.a;
							return $elm$core$Maybe$Just(
								_Utils_Tuple2(
									$mdgriffith$elm_ui$Internal$Model$fontAdjustmentRules(
										function ($) {
											return $.full;
										}(
											$mdgriffith$elm_ui$Internal$Model$convertAdjustment(adjustment))),
									$mdgriffith$elm_ui$Internal$Model$fontAdjustmentRules(
										function ($) {
											return $.capital;
										}(
											$mdgriffith$elm_ui$Internal$Model$convertAdjustment(adjustment)))));
						}
					} else {
						return found;
					}
				} else {
					return found;
				}
			}),
		$elm$core$Maybe$Nothing,
		typefaces);
};
var $mdgriffith$elm_ui$Internal$Model$renderTopLevelValues = function (rules) {
	var withImport = function (font) {
		if (font.$ === 'ImportFont') {
			var url = font.b;
			return $elm$core$Maybe$Just('@import url(\'' + (url + '\');'));
		} else {
			return $elm$core$Maybe$Nothing;
		}
	};
	var fontImports = function (_v2) {
		var name = _v2.a;
		var typefaces = _v2.b;
		var imports = A2(
			$elm$core$String$join,
			'\n',
			A2($elm$core$List$filterMap, withImport, typefaces));
		return imports;
	};
	var allNames = A2($elm$core$List$map, $elm$core$Tuple$first, rules);
	var fontAdjustments = function (_v1) {
		var name = _v1.a;
		var typefaces = _v1.b;
		var _v0 = $mdgriffith$elm_ui$Internal$Model$typefaceAdjustment(typefaces);
		if (_v0.$ === 'Nothing') {
			return A2(
				$elm$core$String$join,
				'',
				A2(
					$elm$core$List$map,
					$mdgriffith$elm_ui$Internal$Model$renderNullAdjustmentRule(name),
					allNames));
		} else {
			var adjustment = _v0.a;
			return A2(
				$elm$core$String$join,
				'',
				A2(
					$elm$core$List$map,
					A2($mdgriffith$elm_ui$Internal$Model$renderFontAdjustmentRule, name, adjustment),
					allNames));
		}
	};
	return _Utils_ap(
		A2(
			$elm$core$String$join,
			'\n',
			A2($elm$core$List$map, fontImports, rules)),
		A2(
			$elm$core$String$join,
			'\n',
			A2($elm$core$List$map, fontAdjustments, rules)));
};
var $mdgriffith$elm_ui$Internal$Model$topLevelValue = function (rule) {
	if (rule.$ === 'FontFamily') {
		var name = rule.a;
		var typefaces = rule.b;
		return $elm$core$Maybe$Just(
			_Utils_Tuple2(name, typefaces));
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $mdgriffith$elm_ui$Internal$Model$toStyleSheetString = F2(
	function (options, stylesheet) {
		var combine = F2(
			function (style, rendered) {
				return {
					rules: _Utils_ap(
						rendered.rules,
						A3($mdgriffith$elm_ui$Internal$Model$renderStyleRule, options, style, $elm$core$Maybe$Nothing)),
					topLevel: function () {
						var _v1 = $mdgriffith$elm_ui$Internal$Model$topLevelValue(style);
						if (_v1.$ === 'Nothing') {
							return rendered.topLevel;
						} else {
							var topLevel = _v1.a;
							return A2($elm$core$List$cons, topLevel, rendered.topLevel);
						}
					}()
				};
			});
		var _v0 = A3(
			$elm$core$List$foldl,
			combine,
			{rules: _List_Nil, topLevel: _List_Nil},
			stylesheet);
		var topLevel = _v0.topLevel;
		var rules = _v0.rules;
		return _Utils_ap(
			$mdgriffith$elm_ui$Internal$Model$renderTopLevelValues(topLevel),
			$elm$core$String$concat(rules));
	});
var $mdgriffith$elm_ui$Internal$Model$toStyleSheet = F2(
	function (options, styleSheet) {
		var _v0 = options.mode;
		switch (_v0.$) {
			case 'Layout':
				return A3(
					$elm$virtual_dom$VirtualDom$node,
					'div',
					_List_Nil,
					_List_fromArray(
						[
							A3(
							$elm$virtual_dom$VirtualDom$node,
							'style',
							_List_Nil,
							_List_fromArray(
								[
									$elm$virtual_dom$VirtualDom$text(
									A2($mdgriffith$elm_ui$Internal$Model$toStyleSheetString, options, styleSheet))
								]))
						]));
			case 'NoStaticStyleSheet':
				return A3(
					$elm$virtual_dom$VirtualDom$node,
					'div',
					_List_Nil,
					_List_fromArray(
						[
							A3(
							$elm$virtual_dom$VirtualDom$node,
							'style',
							_List_Nil,
							_List_fromArray(
								[
									$elm$virtual_dom$VirtualDom$text(
									A2($mdgriffith$elm_ui$Internal$Model$toStyleSheetString, options, styleSheet))
								]))
						]));
			default:
				return A3(
					$elm$virtual_dom$VirtualDom$node,
					'elm-ui-rules',
					_List_fromArray(
						[
							A2(
							$elm$virtual_dom$VirtualDom$property,
							'rules',
							A2($mdgriffith$elm_ui$Internal$Model$encodeStyles, options, styleSheet))
						]),
					_List_Nil);
		}
	});
var $mdgriffith$elm_ui$Internal$Model$embedKeyed = F4(
	function (_static, opts, styles, children) {
		var dynamicStyleSheet = A2(
			$mdgriffith$elm_ui$Internal$Model$toStyleSheet,
			opts,
			A3(
				$elm$core$List$foldl,
				$mdgriffith$elm_ui$Internal$Model$reduceStyles,
				_Utils_Tuple2(
					$elm$core$Set$empty,
					$mdgriffith$elm_ui$Internal$Model$renderFocusStyle(opts.focus)),
				styles).b);
		return _static ? A2(
			$elm$core$List$cons,
			_Utils_Tuple2(
				'static-stylesheet',
				$mdgriffith$elm_ui$Internal$Model$staticRoot(opts)),
			A2(
				$elm$core$List$cons,
				_Utils_Tuple2('dynamic-stylesheet', dynamicStyleSheet),
				children)) : A2(
			$elm$core$List$cons,
			_Utils_Tuple2('dynamic-stylesheet', dynamicStyleSheet),
			children);
	});
var $mdgriffith$elm_ui$Internal$Model$embedWith = F4(
	function (_static, opts, styles, children) {
		var dynamicStyleSheet = A2(
			$mdgriffith$elm_ui$Internal$Model$toStyleSheet,
			opts,
			A3(
				$elm$core$List$foldl,
				$mdgriffith$elm_ui$Internal$Model$reduceStyles,
				_Utils_Tuple2(
					$elm$core$Set$empty,
					$mdgriffith$elm_ui$Internal$Model$renderFocusStyle(opts.focus)),
				styles).b);
		return _static ? A2(
			$elm$core$List$cons,
			$mdgriffith$elm_ui$Internal$Model$staticRoot(opts),
			A2($elm$core$List$cons, dynamicStyleSheet, children)) : A2($elm$core$List$cons, dynamicStyleSheet, children);
	});
var $mdgriffith$elm_ui$Internal$Flag$heightBetween = $mdgriffith$elm_ui$Internal$Flag$flag(45);
var $mdgriffith$elm_ui$Internal$Flag$heightFill = $mdgriffith$elm_ui$Internal$Flag$flag(37);
var $elm$virtual_dom$VirtualDom$keyedNode = function (tag) {
	return _VirtualDom_keyedNode(
		_VirtualDom_noScript(tag));
};
var $elm$html$Html$p = _VirtualDom_node('p');
var $elm$core$Bitwise$and = _Bitwise_and;
var $mdgriffith$elm_ui$Internal$Flag$present = F2(
	function (myFlag, _v0) {
		var fieldOne = _v0.a;
		var fieldTwo = _v0.b;
		if (myFlag.$ === 'Flag') {
			var first = myFlag.a;
			return _Utils_eq(first & fieldOne, first);
		} else {
			var second = myFlag.a;
			return _Utils_eq(second & fieldTwo, second);
		}
	});
var $elm$html$Html$s = _VirtualDom_node('s');
var $elm$html$Html$u = _VirtualDom_node('u');
var $mdgriffith$elm_ui$Internal$Flag$widthBetween = $mdgriffith$elm_ui$Internal$Flag$flag(44);
var $mdgriffith$elm_ui$Internal$Flag$widthFill = $mdgriffith$elm_ui$Internal$Flag$flag(39);
var $mdgriffith$elm_ui$Internal$Model$finalizeNode = F6(
	function (has, node, attributes, children, embedMode, parentContext) {
		var createNode = F2(
			function (nodeName, attrs) {
				if (children.$ === 'Keyed') {
					var keyed = children.a;
					return A3(
						$elm$virtual_dom$VirtualDom$keyedNode,
						nodeName,
						attrs,
						function () {
							switch (embedMode.$) {
								case 'NoStyleSheet':
									return keyed;
								case 'OnlyDynamic':
									var opts = embedMode.a;
									var styles = embedMode.b;
									return A4($mdgriffith$elm_ui$Internal$Model$embedKeyed, false, opts, styles, keyed);
								default:
									var opts = embedMode.a;
									var styles = embedMode.b;
									return A4($mdgriffith$elm_ui$Internal$Model$embedKeyed, true, opts, styles, keyed);
							}
						}());
				} else {
					var unkeyed = children.a;
					return A2(
						function () {
							switch (nodeName) {
								case 'div':
									return $elm$html$Html$div;
								case 'p':
									return $elm$html$Html$p;
								default:
									return $elm$virtual_dom$VirtualDom$node(nodeName);
							}
						}(),
						attrs,
						function () {
							switch (embedMode.$) {
								case 'NoStyleSheet':
									return unkeyed;
								case 'OnlyDynamic':
									var opts = embedMode.a;
									var styles = embedMode.b;
									return A4($mdgriffith$elm_ui$Internal$Model$embedWith, false, opts, styles, unkeyed);
								default:
									var opts = embedMode.a;
									var styles = embedMode.b;
									return A4($mdgriffith$elm_ui$Internal$Model$embedWith, true, opts, styles, unkeyed);
							}
						}());
				}
			});
		var html = function () {
			switch (node.$) {
				case 'Generic':
					return A2(createNode, 'div', attributes);
				case 'NodeName':
					var nodeName = node.a;
					return A2(createNode, nodeName, attributes);
				default:
					var nodeName = node.a;
					var internal = node.b;
					return A3(
						$elm$virtual_dom$VirtualDom$node,
						nodeName,
						attributes,
						_List_fromArray(
							[
								A2(
								createNode,
								internal,
								_List_fromArray(
									[
										$elm$html$Html$Attributes$class($mdgriffith$elm_ui$Internal$Style$classes.any + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.single))
									]))
							]));
			}
		}();
		switch (parentContext.$) {
			case 'AsRow':
				return (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$widthFill, has) && (!A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$widthBetween, has))) ? html : (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$alignRight, has) ? A2(
					$elm$html$Html$u,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class(
							A2(
								$elm$core$String$join,
								' ',
								_List_fromArray(
									[$mdgriffith$elm_ui$Internal$Style$classes.any, $mdgriffith$elm_ui$Internal$Style$classes.single, $mdgriffith$elm_ui$Internal$Style$classes.container, $mdgriffith$elm_ui$Internal$Style$classes.contentCenterY, $mdgriffith$elm_ui$Internal$Style$classes.alignContainerRight])))
						]),
					_List_fromArray(
						[html])) : (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$centerX, has) ? A2(
					$elm$html$Html$s,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class(
							A2(
								$elm$core$String$join,
								' ',
								_List_fromArray(
									[$mdgriffith$elm_ui$Internal$Style$classes.any, $mdgriffith$elm_ui$Internal$Style$classes.single, $mdgriffith$elm_ui$Internal$Style$classes.container, $mdgriffith$elm_ui$Internal$Style$classes.contentCenterY, $mdgriffith$elm_ui$Internal$Style$classes.alignContainerCenterX])))
						]),
					_List_fromArray(
						[html])) : html));
			case 'AsColumn':
				return (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$heightFill, has) && (!A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$heightBetween, has))) ? html : (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$centerY, has) ? A2(
					$elm$html$Html$s,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class(
							A2(
								$elm$core$String$join,
								' ',
								_List_fromArray(
									[$mdgriffith$elm_ui$Internal$Style$classes.any, $mdgriffith$elm_ui$Internal$Style$classes.single, $mdgriffith$elm_ui$Internal$Style$classes.container, $mdgriffith$elm_ui$Internal$Style$classes.alignContainerCenterY])))
						]),
					_List_fromArray(
						[html])) : (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$alignBottom, has) ? A2(
					$elm$html$Html$u,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class(
							A2(
								$elm$core$String$join,
								' ',
								_List_fromArray(
									[$mdgriffith$elm_ui$Internal$Style$classes.any, $mdgriffith$elm_ui$Internal$Style$classes.single, $mdgriffith$elm_ui$Internal$Style$classes.container, $mdgriffith$elm_ui$Internal$Style$classes.alignContainerBottom])))
						]),
					_List_fromArray(
						[html])) : html));
			default:
				return html;
		}
	});
var $elm$core$List$isEmpty = function (xs) {
	if (!xs.b) {
		return true;
	} else {
		return false;
	}
};
var $elm$html$Html$text = $elm$virtual_dom$VirtualDom$text;
var $mdgriffith$elm_ui$Internal$Model$textElementClasses = $mdgriffith$elm_ui$Internal$Style$classes.any + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.text + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.widthContent + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.heightContent)))));
var $mdgriffith$elm_ui$Internal$Model$textElement = function (str) {
	return A2(
		$elm$html$Html$div,
		_List_fromArray(
			[
				$elm$html$Html$Attributes$class($mdgriffith$elm_ui$Internal$Model$textElementClasses)
			]),
		_List_fromArray(
			[
				$elm$html$Html$text(str)
			]));
};
var $mdgriffith$elm_ui$Internal$Model$textElementFillClasses = $mdgriffith$elm_ui$Internal$Style$classes.any + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.text + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.widthFill + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.heightFill)))));
var $mdgriffith$elm_ui$Internal$Model$textElementFill = function (str) {
	return A2(
		$elm$html$Html$div,
		_List_fromArray(
			[
				$elm$html$Html$Attributes$class($mdgriffith$elm_ui$Internal$Model$textElementFillClasses)
			]),
		_List_fromArray(
			[
				$elm$html$Html$text(str)
			]));
};
var $mdgriffith$elm_ui$Internal$Model$createElement = F3(
	function (context, children, rendered) {
		var gatherKeyed = F2(
			function (_v8, _v9) {
				var key = _v8.a;
				var child = _v8.b;
				var htmls = _v9.a;
				var existingStyles = _v9.b;
				switch (child.$) {
					case 'Unstyled':
						var html = child.a;
						return _Utils_eq(context, $mdgriffith$elm_ui$Internal$Model$asParagraph) ? _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								_Utils_Tuple2(
									key,
									html(context)),
								htmls),
							existingStyles) : _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								_Utils_Tuple2(
									key,
									html(context)),
								htmls),
							existingStyles);
					case 'Styled':
						var styled = child.a;
						return _Utils_eq(context, $mdgriffith$elm_ui$Internal$Model$asParagraph) ? _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								_Utils_Tuple2(
									key,
									A2(styled.html, $mdgriffith$elm_ui$Internal$Model$NoStyleSheet, context)),
								htmls),
							$elm$core$List$isEmpty(existingStyles) ? styled.styles : _Utils_ap(styled.styles, existingStyles)) : _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								_Utils_Tuple2(
									key,
									A2(styled.html, $mdgriffith$elm_ui$Internal$Model$NoStyleSheet, context)),
								htmls),
							$elm$core$List$isEmpty(existingStyles) ? styled.styles : _Utils_ap(styled.styles, existingStyles));
					case 'Text':
						var str = child.a;
						return _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								_Utils_Tuple2(
									key,
									_Utils_eq(context, $mdgriffith$elm_ui$Internal$Model$asEl) ? $mdgriffith$elm_ui$Internal$Model$textElementFill(str) : $mdgriffith$elm_ui$Internal$Model$textElement(str)),
								htmls),
							existingStyles);
					default:
						return _Utils_Tuple2(htmls, existingStyles);
				}
			});
		var gather = F2(
			function (child, _v6) {
				var htmls = _v6.a;
				var existingStyles = _v6.b;
				switch (child.$) {
					case 'Unstyled':
						var html = child.a;
						return _Utils_eq(context, $mdgriffith$elm_ui$Internal$Model$asParagraph) ? _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								html(context),
								htmls),
							existingStyles) : _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								html(context),
								htmls),
							existingStyles);
					case 'Styled':
						var styled = child.a;
						return _Utils_eq(context, $mdgriffith$elm_ui$Internal$Model$asParagraph) ? _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								A2(styled.html, $mdgriffith$elm_ui$Internal$Model$NoStyleSheet, context),
								htmls),
							$elm$core$List$isEmpty(existingStyles) ? styled.styles : _Utils_ap(styled.styles, existingStyles)) : _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								A2(styled.html, $mdgriffith$elm_ui$Internal$Model$NoStyleSheet, context),
								htmls),
							$elm$core$List$isEmpty(existingStyles) ? styled.styles : _Utils_ap(styled.styles, existingStyles));
					case 'Text':
						var str = child.a;
						return _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								_Utils_eq(context, $mdgriffith$elm_ui$Internal$Model$asEl) ? $mdgriffith$elm_ui$Internal$Model$textElementFill(str) : $mdgriffith$elm_ui$Internal$Model$textElement(str),
								htmls),
							existingStyles);
					default:
						return _Utils_Tuple2(htmls, existingStyles);
				}
			});
		if (children.$ === 'Keyed') {
			var keyedChildren = children.a;
			var _v1 = A3(
				$elm$core$List$foldr,
				gatherKeyed,
				_Utils_Tuple2(_List_Nil, _List_Nil),
				keyedChildren);
			var keyed = _v1.a;
			var styles = _v1.b;
			var newStyles = $elm$core$List$isEmpty(styles) ? rendered.styles : _Utils_ap(rendered.styles, styles);
			if (!newStyles.b) {
				return $mdgriffith$elm_ui$Internal$Model$Unstyled(
					A5(
						$mdgriffith$elm_ui$Internal$Model$finalizeNode,
						rendered.has,
						rendered.node,
						rendered.attributes,
						$mdgriffith$elm_ui$Internal$Model$Keyed(
							A3($mdgriffith$elm_ui$Internal$Model$addKeyedChildren, 'nearby-element-pls', keyed, rendered.children)),
						$mdgriffith$elm_ui$Internal$Model$NoStyleSheet));
			} else {
				var allStyles = newStyles;
				return $mdgriffith$elm_ui$Internal$Model$Styled(
					{
						html: A4(
							$mdgriffith$elm_ui$Internal$Model$finalizeNode,
							rendered.has,
							rendered.node,
							rendered.attributes,
							$mdgriffith$elm_ui$Internal$Model$Keyed(
								A3($mdgriffith$elm_ui$Internal$Model$addKeyedChildren, 'nearby-element-pls', keyed, rendered.children))),
						styles: allStyles
					});
			}
		} else {
			var unkeyedChildren = children.a;
			var _v3 = A3(
				$elm$core$List$foldr,
				gather,
				_Utils_Tuple2(_List_Nil, _List_Nil),
				unkeyedChildren);
			var unkeyed = _v3.a;
			var styles = _v3.b;
			var newStyles = $elm$core$List$isEmpty(styles) ? rendered.styles : _Utils_ap(rendered.styles, styles);
			if (!newStyles.b) {
				return $mdgriffith$elm_ui$Internal$Model$Unstyled(
					A5(
						$mdgriffith$elm_ui$Internal$Model$finalizeNode,
						rendered.has,
						rendered.node,
						rendered.attributes,
						$mdgriffith$elm_ui$Internal$Model$Unkeyed(
							A2($mdgriffith$elm_ui$Internal$Model$addChildren, unkeyed, rendered.children)),
						$mdgriffith$elm_ui$Internal$Model$NoStyleSheet));
			} else {
				var allStyles = newStyles;
				return $mdgriffith$elm_ui$Internal$Model$Styled(
					{
						html: A4(
							$mdgriffith$elm_ui$Internal$Model$finalizeNode,
							rendered.has,
							rendered.node,
							rendered.attributes,
							$mdgriffith$elm_ui$Internal$Model$Unkeyed(
								A2($mdgriffith$elm_ui$Internal$Model$addChildren, unkeyed, rendered.children))),
						styles: allStyles
					});
			}
		}
	});
var $mdgriffith$elm_ui$Internal$Model$Single = F3(
	function (a, b, c) {
		return {$: 'Single', a: a, b: b, c: c};
	});
var $mdgriffith$elm_ui$Internal$Model$Transform = function (a) {
	return {$: 'Transform', a: a};
};
var $mdgriffith$elm_ui$Internal$Flag$Field = F2(
	function (a, b) {
		return {$: 'Field', a: a, b: b};
	});
var $elm$core$Bitwise$or = _Bitwise_or;
var $mdgriffith$elm_ui$Internal$Flag$add = F2(
	function (myFlag, _v0) {
		var one = _v0.a;
		var two = _v0.b;
		if (myFlag.$ === 'Flag') {
			var first = myFlag.a;
			return A2($mdgriffith$elm_ui$Internal$Flag$Field, first | one, two);
		} else {
			var second = myFlag.a;
			return A2($mdgriffith$elm_ui$Internal$Flag$Field, one, second | two);
		}
	});
var $mdgriffith$elm_ui$Internal$Model$ChildrenBehind = function (a) {
	return {$: 'ChildrenBehind', a: a};
};
var $mdgriffith$elm_ui$Internal$Model$ChildrenBehindAndInFront = F2(
	function (a, b) {
		return {$: 'ChildrenBehindAndInFront', a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Model$ChildrenInFront = function (a) {
	return {$: 'ChildrenInFront', a: a};
};
var $mdgriffith$elm_ui$Internal$Model$nearbyElement = F2(
	function (location, elem) {
		return A2(
			$elm$html$Html$div,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$class(
					function () {
						switch (location.$) {
							case 'Above':
								return A2(
									$elm$core$String$join,
									' ',
									_List_fromArray(
										[$mdgriffith$elm_ui$Internal$Style$classes.nearby, $mdgriffith$elm_ui$Internal$Style$classes.single, $mdgriffith$elm_ui$Internal$Style$classes.above]));
							case 'Below':
								return A2(
									$elm$core$String$join,
									' ',
									_List_fromArray(
										[$mdgriffith$elm_ui$Internal$Style$classes.nearby, $mdgriffith$elm_ui$Internal$Style$classes.single, $mdgriffith$elm_ui$Internal$Style$classes.below]));
							case 'OnRight':
								return A2(
									$elm$core$String$join,
									' ',
									_List_fromArray(
										[$mdgriffith$elm_ui$Internal$Style$classes.nearby, $mdgriffith$elm_ui$Internal$Style$classes.single, $mdgriffith$elm_ui$Internal$Style$classes.onRight]));
							case 'OnLeft':
								return A2(
									$elm$core$String$join,
									' ',
									_List_fromArray(
										[$mdgriffith$elm_ui$Internal$Style$classes.nearby, $mdgriffith$elm_ui$Internal$Style$classes.single, $mdgriffith$elm_ui$Internal$Style$classes.onLeft]));
							case 'InFront':
								return A2(
									$elm$core$String$join,
									' ',
									_List_fromArray(
										[$mdgriffith$elm_ui$Internal$Style$classes.nearby, $mdgriffith$elm_ui$Internal$Style$classes.single, $mdgriffith$elm_ui$Internal$Style$classes.inFront]));
							default:
								return A2(
									$elm$core$String$join,
									' ',
									_List_fromArray(
										[$mdgriffith$elm_ui$Internal$Style$classes.nearby, $mdgriffith$elm_ui$Internal$Style$classes.single, $mdgriffith$elm_ui$Internal$Style$classes.behind]));
						}
					}())
				]),
			_List_fromArray(
				[
					function () {
					switch (elem.$) {
						case 'Empty':
							return $elm$virtual_dom$VirtualDom$text('');
						case 'Text':
							var str = elem.a;
							return $mdgriffith$elm_ui$Internal$Model$textElement(str);
						case 'Unstyled':
							var html = elem.a;
							return html($mdgriffith$elm_ui$Internal$Model$asEl);
						default:
							var styled = elem.a;
							return A2(styled.html, $mdgriffith$elm_ui$Internal$Model$NoStyleSheet, $mdgriffith$elm_ui$Internal$Model$asEl);
					}
				}()
				]));
	});
var $mdgriffith$elm_ui$Internal$Model$addNearbyElement = F3(
	function (location, elem, existing) {
		var nearby = A2($mdgriffith$elm_ui$Internal$Model$nearbyElement, location, elem);
		switch (existing.$) {
			case 'NoNearbyChildren':
				if (location.$ === 'Behind') {
					return $mdgriffith$elm_ui$Internal$Model$ChildrenBehind(
						_List_fromArray(
							[nearby]));
				} else {
					return $mdgriffith$elm_ui$Internal$Model$ChildrenInFront(
						_List_fromArray(
							[nearby]));
				}
			case 'ChildrenBehind':
				var existingBehind = existing.a;
				if (location.$ === 'Behind') {
					return $mdgriffith$elm_ui$Internal$Model$ChildrenBehind(
						A2($elm$core$List$cons, nearby, existingBehind));
				} else {
					return A2(
						$mdgriffith$elm_ui$Internal$Model$ChildrenBehindAndInFront,
						existingBehind,
						_List_fromArray(
							[nearby]));
				}
			case 'ChildrenInFront':
				var existingInFront = existing.a;
				if (location.$ === 'Behind') {
					return A2(
						$mdgriffith$elm_ui$Internal$Model$ChildrenBehindAndInFront,
						_List_fromArray(
							[nearby]),
						existingInFront);
				} else {
					return $mdgriffith$elm_ui$Internal$Model$ChildrenInFront(
						A2($elm$core$List$cons, nearby, existingInFront));
				}
			default:
				var existingBehind = existing.a;
				var existingInFront = existing.b;
				if (location.$ === 'Behind') {
					return A2(
						$mdgriffith$elm_ui$Internal$Model$ChildrenBehindAndInFront,
						A2($elm$core$List$cons, nearby, existingBehind),
						existingInFront);
				} else {
					return A2(
						$mdgriffith$elm_ui$Internal$Model$ChildrenBehindAndInFront,
						existingBehind,
						A2($elm$core$List$cons, nearby, existingInFront));
				}
		}
	});
var $mdgriffith$elm_ui$Internal$Model$Embedded = F2(
	function (a, b) {
		return {$: 'Embedded', a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Model$NodeName = function (a) {
	return {$: 'NodeName', a: a};
};
var $mdgriffith$elm_ui$Internal$Model$addNodeName = F2(
	function (newNode, old) {
		switch (old.$) {
			case 'Generic':
				return $mdgriffith$elm_ui$Internal$Model$NodeName(newNode);
			case 'NodeName':
				var name = old.a;
				return A2($mdgriffith$elm_ui$Internal$Model$Embedded, name, newNode);
			default:
				var x = old.a;
				var y = old.b;
				return A2($mdgriffith$elm_ui$Internal$Model$Embedded, x, y);
		}
	});
var $mdgriffith$elm_ui$Internal$Model$alignXName = function (align) {
	switch (align.$) {
		case 'Left':
			return $mdgriffith$elm_ui$Internal$Style$classes.alignedHorizontally + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.alignLeft);
		case 'Right':
			return $mdgriffith$elm_ui$Internal$Style$classes.alignedHorizontally + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.alignRight);
		default:
			return $mdgriffith$elm_ui$Internal$Style$classes.alignedHorizontally + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.alignCenterX);
	}
};
var $mdgriffith$elm_ui$Internal$Model$alignYName = function (align) {
	switch (align.$) {
		case 'Top':
			return $mdgriffith$elm_ui$Internal$Style$classes.alignedVertically + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.alignTop);
		case 'Bottom':
			return $mdgriffith$elm_ui$Internal$Style$classes.alignedVertically + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.alignBottom);
		default:
			return $mdgriffith$elm_ui$Internal$Style$classes.alignedVertically + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.alignCenterY);
	}
};
var $elm$virtual_dom$VirtualDom$attribute = F2(
	function (key, value) {
		return A2(
			_VirtualDom_attribute,
			_VirtualDom_noOnOrFormAction(key),
			_VirtualDom_noJavaScriptOrHtmlUri(value));
	});
var $mdgriffith$elm_ui$Internal$Model$FullTransform = F4(
	function (a, b, c, d) {
		return {$: 'FullTransform', a: a, b: b, c: c, d: d};
	});
var $mdgriffith$elm_ui$Internal$Model$Moved = function (a) {
	return {$: 'Moved', a: a};
};
var $mdgriffith$elm_ui$Internal$Model$composeTransformation = F2(
	function (transform, component) {
		switch (transform.$) {
			case 'Untransformed':
				switch (component.$) {
					case 'MoveX':
						var x = component.a;
						return $mdgriffith$elm_ui$Internal$Model$Moved(
							_Utils_Tuple3(x, 0, 0));
					case 'MoveY':
						var y = component.a;
						return $mdgriffith$elm_ui$Internal$Model$Moved(
							_Utils_Tuple3(0, y, 0));
					case 'MoveZ':
						var z = component.a;
						return $mdgriffith$elm_ui$Internal$Model$Moved(
							_Utils_Tuple3(0, 0, z));
					case 'MoveXYZ':
						var xyz = component.a;
						return $mdgriffith$elm_ui$Internal$Model$Moved(xyz);
					case 'Rotate':
						var xyz = component.a;
						var angle = component.b;
						return A4(
							$mdgriffith$elm_ui$Internal$Model$FullTransform,
							_Utils_Tuple3(0, 0, 0),
							_Utils_Tuple3(1, 1, 1),
							xyz,
							angle);
					default:
						var xyz = component.a;
						return A4(
							$mdgriffith$elm_ui$Internal$Model$FullTransform,
							_Utils_Tuple3(0, 0, 0),
							xyz,
							_Utils_Tuple3(0, 0, 1),
							0);
				}
			case 'Moved':
				var moved = transform.a;
				var x = moved.a;
				var y = moved.b;
				var z = moved.c;
				switch (component.$) {
					case 'MoveX':
						var newX = component.a;
						return $mdgriffith$elm_ui$Internal$Model$Moved(
							_Utils_Tuple3(newX, y, z));
					case 'MoveY':
						var newY = component.a;
						return $mdgriffith$elm_ui$Internal$Model$Moved(
							_Utils_Tuple3(x, newY, z));
					case 'MoveZ':
						var newZ = component.a;
						return $mdgriffith$elm_ui$Internal$Model$Moved(
							_Utils_Tuple3(x, y, newZ));
					case 'MoveXYZ':
						var xyz = component.a;
						return $mdgriffith$elm_ui$Internal$Model$Moved(xyz);
					case 'Rotate':
						var xyz = component.a;
						var angle = component.b;
						return A4(
							$mdgriffith$elm_ui$Internal$Model$FullTransform,
							moved,
							_Utils_Tuple3(1, 1, 1),
							xyz,
							angle);
					default:
						var scale = component.a;
						return A4(
							$mdgriffith$elm_ui$Internal$Model$FullTransform,
							moved,
							scale,
							_Utils_Tuple3(0, 0, 1),
							0);
				}
			default:
				var moved = transform.a;
				var x = moved.a;
				var y = moved.b;
				var z = moved.c;
				var scaled = transform.b;
				var origin = transform.c;
				var angle = transform.d;
				switch (component.$) {
					case 'MoveX':
						var newX = component.a;
						return A4(
							$mdgriffith$elm_ui$Internal$Model$FullTransform,
							_Utils_Tuple3(newX, y, z),
							scaled,
							origin,
							angle);
					case 'MoveY':
						var newY = component.a;
						return A4(
							$mdgriffith$elm_ui$Internal$Model$FullTransform,
							_Utils_Tuple3(x, newY, z),
							scaled,
							origin,
							angle);
					case 'MoveZ':
						var newZ = component.a;
						return A4(
							$mdgriffith$elm_ui$Internal$Model$FullTransform,
							_Utils_Tuple3(x, y, newZ),
							scaled,
							origin,
							angle);
					case 'MoveXYZ':
						var newMove = component.a;
						return A4($mdgriffith$elm_ui$Internal$Model$FullTransform, newMove, scaled, origin, angle);
					case 'Rotate':
						var newOrigin = component.a;
						var newAngle = component.b;
						return A4($mdgriffith$elm_ui$Internal$Model$FullTransform, moved, scaled, newOrigin, newAngle);
					default:
						var newScale = component.a;
						return A4($mdgriffith$elm_ui$Internal$Model$FullTransform, moved, newScale, origin, angle);
				}
		}
	});
var $mdgriffith$elm_ui$Internal$Flag$height = $mdgriffith$elm_ui$Internal$Flag$flag(7);
var $mdgriffith$elm_ui$Internal$Flag$heightContent = $mdgriffith$elm_ui$Internal$Flag$flag(36);
var $mdgriffith$elm_ui$Internal$Flag$merge = F2(
	function (_v0, _v1) {
		var one = _v0.a;
		var two = _v0.b;
		var three = _v1.a;
		var four = _v1.b;
		return A2($mdgriffith$elm_ui$Internal$Flag$Field, one | three, two | four);
	});
var $mdgriffith$elm_ui$Internal$Flag$none = A2($mdgriffith$elm_ui$Internal$Flag$Field, 0, 0);
var $mdgriffith$elm_ui$Internal$Model$renderHeight = function (h) {
	switch (h.$) {
		case 'Px':
			var px = h.a;
			var val = $elm$core$String$fromInt(px);
			var name = 'height-px-' + val;
			return _Utils_Tuple3(
				$mdgriffith$elm_ui$Internal$Flag$none,
				$mdgriffith$elm_ui$Internal$Style$classes.heightExact + (' ' + name),
				_List_fromArray(
					[
						A3($mdgriffith$elm_ui$Internal$Model$Single, name, 'height', val + 'px')
					]));
		case 'Content':
			return _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$heightContent, $mdgriffith$elm_ui$Internal$Flag$none),
				$mdgriffith$elm_ui$Internal$Style$classes.heightContent,
				_List_Nil);
		case 'Fill':
			var portion = h.a;
			return (portion === 1) ? _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$heightFill, $mdgriffith$elm_ui$Internal$Flag$none),
				$mdgriffith$elm_ui$Internal$Style$classes.heightFill,
				_List_Nil) : _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$heightFill, $mdgriffith$elm_ui$Internal$Flag$none),
				$mdgriffith$elm_ui$Internal$Style$classes.heightFillPortion + (' height-fill-' + $elm$core$String$fromInt(portion)),
				_List_fromArray(
					[
						A3(
						$mdgriffith$elm_ui$Internal$Model$Single,
						$mdgriffith$elm_ui$Internal$Style$classes.any + ('.' + ($mdgriffith$elm_ui$Internal$Style$classes.column + (' > ' + $mdgriffith$elm_ui$Internal$Style$dot(
							'height-fill-' + $elm$core$String$fromInt(portion))))),
						'flex-grow',
						$elm$core$String$fromInt(portion * 100000))
					]));
		case 'Min':
			var minSize = h.a;
			var len = h.b;
			var cls = 'min-height-' + $elm$core$String$fromInt(minSize);
			var style = A3(
				$mdgriffith$elm_ui$Internal$Model$Single,
				cls,
				'min-height',
				$elm$core$String$fromInt(minSize) + 'px !important');
			var _v1 = $mdgriffith$elm_ui$Internal$Model$renderHeight(len);
			var newFlag = _v1.a;
			var newAttrs = _v1.b;
			var newStyle = _v1.c;
			return _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$heightBetween, newFlag),
				cls + (' ' + newAttrs),
				A2($elm$core$List$cons, style, newStyle));
		default:
			var maxSize = h.a;
			var len = h.b;
			var cls = 'max-height-' + $elm$core$String$fromInt(maxSize);
			var style = A3(
				$mdgriffith$elm_ui$Internal$Model$Single,
				cls,
				'max-height',
				$elm$core$String$fromInt(maxSize) + 'px');
			var _v2 = $mdgriffith$elm_ui$Internal$Model$renderHeight(len);
			var newFlag = _v2.a;
			var newAttrs = _v2.b;
			var newStyle = _v2.c;
			return _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$heightBetween, newFlag),
				cls + (' ' + newAttrs),
				A2($elm$core$List$cons, style, newStyle));
	}
};
var $mdgriffith$elm_ui$Internal$Flag$widthContent = $mdgriffith$elm_ui$Internal$Flag$flag(38);
var $mdgriffith$elm_ui$Internal$Model$renderWidth = function (w) {
	switch (w.$) {
		case 'Px':
			var px = w.a;
			return _Utils_Tuple3(
				$mdgriffith$elm_ui$Internal$Flag$none,
				$mdgriffith$elm_ui$Internal$Style$classes.widthExact + (' width-px-' + $elm$core$String$fromInt(px)),
				_List_fromArray(
					[
						A3(
						$mdgriffith$elm_ui$Internal$Model$Single,
						'width-px-' + $elm$core$String$fromInt(px),
						'width',
						$elm$core$String$fromInt(px) + 'px')
					]));
		case 'Content':
			return _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$widthContent, $mdgriffith$elm_ui$Internal$Flag$none),
				$mdgriffith$elm_ui$Internal$Style$classes.widthContent,
				_List_Nil);
		case 'Fill':
			var portion = w.a;
			return (portion === 1) ? _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$widthFill, $mdgriffith$elm_ui$Internal$Flag$none),
				$mdgriffith$elm_ui$Internal$Style$classes.widthFill,
				_List_Nil) : _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$widthFill, $mdgriffith$elm_ui$Internal$Flag$none),
				$mdgriffith$elm_ui$Internal$Style$classes.widthFillPortion + (' width-fill-' + $elm$core$String$fromInt(portion)),
				_List_fromArray(
					[
						A3(
						$mdgriffith$elm_ui$Internal$Model$Single,
						$mdgriffith$elm_ui$Internal$Style$classes.any + ('.' + ($mdgriffith$elm_ui$Internal$Style$classes.row + (' > ' + $mdgriffith$elm_ui$Internal$Style$dot(
							'width-fill-' + $elm$core$String$fromInt(portion))))),
						'flex-grow',
						$elm$core$String$fromInt(portion * 100000))
					]));
		case 'Min':
			var minSize = w.a;
			var len = w.b;
			var cls = 'min-width-' + $elm$core$String$fromInt(minSize);
			var style = A3(
				$mdgriffith$elm_ui$Internal$Model$Single,
				cls,
				'min-width',
				$elm$core$String$fromInt(minSize) + 'px');
			var _v1 = $mdgriffith$elm_ui$Internal$Model$renderWidth(len);
			var newFlag = _v1.a;
			var newAttrs = _v1.b;
			var newStyle = _v1.c;
			return _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$widthBetween, newFlag),
				cls + (' ' + newAttrs),
				A2($elm$core$List$cons, style, newStyle));
		default:
			var maxSize = w.a;
			var len = w.b;
			var cls = 'max-width-' + $elm$core$String$fromInt(maxSize);
			var style = A3(
				$mdgriffith$elm_ui$Internal$Model$Single,
				cls,
				'max-width',
				$elm$core$String$fromInt(maxSize) + 'px');
			var _v2 = $mdgriffith$elm_ui$Internal$Model$renderWidth(len);
			var newFlag = _v2.a;
			var newAttrs = _v2.b;
			var newStyle = _v2.c;
			return _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$widthBetween, newFlag),
				cls + (' ' + newAttrs),
				A2($elm$core$List$cons, style, newStyle));
	}
};
var $mdgriffith$elm_ui$Internal$Flag$borderWidth = $mdgriffith$elm_ui$Internal$Flag$flag(27);
var $elm$core$Basics$ge = _Utils_ge;
var $mdgriffith$elm_ui$Internal$Model$skippable = F2(
	function (flag, style) {
		if (_Utils_eq(flag, $mdgriffith$elm_ui$Internal$Flag$borderWidth)) {
			if (style.$ === 'Single') {
				var val = style.c;
				switch (val) {
					case '0px':
						return true;
					case '1px':
						return true;
					case '2px':
						return true;
					case '3px':
						return true;
					case '4px':
						return true;
					case '5px':
						return true;
					case '6px':
						return true;
					default:
						return false;
				}
			} else {
				return false;
			}
		} else {
			switch (style.$) {
				case 'FontSize':
					var i = style.a;
					return (i >= 8) && (i <= 32);
				case 'PaddingStyle':
					var name = style.a;
					var t = style.b;
					var r = style.c;
					var b = style.d;
					var l = style.e;
					return _Utils_eq(t, b) && (_Utils_eq(t, r) && (_Utils_eq(t, l) && ((t >= 0) && (t <= 24))));
				default:
					return false;
			}
		}
	});
var $mdgriffith$elm_ui$Internal$Flag$width = $mdgriffith$elm_ui$Internal$Flag$flag(6);
var $mdgriffith$elm_ui$Internal$Flag$xAlign = $mdgriffith$elm_ui$Internal$Flag$flag(30);
var $mdgriffith$elm_ui$Internal$Flag$yAlign = $mdgriffith$elm_ui$Internal$Flag$flag(29);
var $mdgriffith$elm_ui$Internal$Model$gatherAttrRecursive = F8(
	function (classes, node, has, transform, styles, attrs, children, elementAttrs) {
		gatherAttrRecursive:
		while (true) {
			if (!elementAttrs.b) {
				var _v1 = $mdgriffith$elm_ui$Internal$Model$transformClass(transform);
				if (_v1.$ === 'Nothing') {
					return {
						attributes: A2(
							$elm$core$List$cons,
							$elm$html$Html$Attributes$class(classes),
							attrs),
						children: children,
						has: has,
						node: node,
						styles: styles
					};
				} else {
					var _class = _v1.a;
					return {
						attributes: A2(
							$elm$core$List$cons,
							$elm$html$Html$Attributes$class(classes + (' ' + _class)),
							attrs),
						children: children,
						has: has,
						node: node,
						styles: A2(
							$elm$core$List$cons,
							$mdgriffith$elm_ui$Internal$Model$Transform(transform),
							styles)
					};
				}
			} else {
				var attribute = elementAttrs.a;
				var remaining = elementAttrs.b;
				switch (attribute.$) {
					case 'NoAttribute':
						var $temp$classes = classes,
							$temp$node = node,
							$temp$has = has,
							$temp$transform = transform,
							$temp$styles = styles,
							$temp$attrs = attrs,
							$temp$children = children,
							$temp$elementAttrs = remaining;
						classes = $temp$classes;
						node = $temp$node;
						has = $temp$has;
						transform = $temp$transform;
						styles = $temp$styles;
						attrs = $temp$attrs;
						children = $temp$children;
						elementAttrs = $temp$elementAttrs;
						continue gatherAttrRecursive;
					case 'Class':
						var flag = attribute.a;
						var exactClassName = attribute.b;
						if (A2($mdgriffith$elm_ui$Internal$Flag$present, flag, has)) {
							var $temp$classes = classes,
								$temp$node = node,
								$temp$has = has,
								$temp$transform = transform,
								$temp$styles = styles,
								$temp$attrs = attrs,
								$temp$children = children,
								$temp$elementAttrs = remaining;
							classes = $temp$classes;
							node = $temp$node;
							has = $temp$has;
							transform = $temp$transform;
							styles = $temp$styles;
							attrs = $temp$attrs;
							children = $temp$children;
							elementAttrs = $temp$elementAttrs;
							continue gatherAttrRecursive;
						} else {
							var $temp$classes = exactClassName + (' ' + classes),
								$temp$node = node,
								$temp$has = A2($mdgriffith$elm_ui$Internal$Flag$add, flag, has),
								$temp$transform = transform,
								$temp$styles = styles,
								$temp$attrs = attrs,
								$temp$children = children,
								$temp$elementAttrs = remaining;
							classes = $temp$classes;
							node = $temp$node;
							has = $temp$has;
							transform = $temp$transform;
							styles = $temp$styles;
							attrs = $temp$attrs;
							children = $temp$children;
							elementAttrs = $temp$elementAttrs;
							continue gatherAttrRecursive;
						}
					case 'Attr':
						var actualAttribute = attribute.a;
						var $temp$classes = classes,
							$temp$node = node,
							$temp$has = has,
							$temp$transform = transform,
							$temp$styles = styles,
							$temp$attrs = A2($elm$core$List$cons, actualAttribute, attrs),
							$temp$children = children,
							$temp$elementAttrs = remaining;
						classes = $temp$classes;
						node = $temp$node;
						has = $temp$has;
						transform = $temp$transform;
						styles = $temp$styles;
						attrs = $temp$attrs;
						children = $temp$children;
						elementAttrs = $temp$elementAttrs;
						continue gatherAttrRecursive;
					case 'StyleClass':
						var flag = attribute.a;
						var style = attribute.b;
						if (A2($mdgriffith$elm_ui$Internal$Flag$present, flag, has)) {
							var $temp$classes = classes,
								$temp$node = node,
								$temp$has = has,
								$temp$transform = transform,
								$temp$styles = styles,
								$temp$attrs = attrs,
								$temp$children = children,
								$temp$elementAttrs = remaining;
							classes = $temp$classes;
							node = $temp$node;
							has = $temp$has;
							transform = $temp$transform;
							styles = $temp$styles;
							attrs = $temp$attrs;
							children = $temp$children;
							elementAttrs = $temp$elementAttrs;
							continue gatherAttrRecursive;
						} else {
							if (A2($mdgriffith$elm_ui$Internal$Model$skippable, flag, style)) {
								var $temp$classes = $mdgriffith$elm_ui$Internal$Model$getStyleName(style) + (' ' + classes),
									$temp$node = node,
									$temp$has = A2($mdgriffith$elm_ui$Internal$Flag$add, flag, has),
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = attrs,
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							} else {
								var $temp$classes = $mdgriffith$elm_ui$Internal$Model$getStyleName(style) + (' ' + classes),
									$temp$node = node,
									$temp$has = A2($mdgriffith$elm_ui$Internal$Flag$add, flag, has),
									$temp$transform = transform,
									$temp$styles = A2($elm$core$List$cons, style, styles),
									$temp$attrs = attrs,
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							}
						}
					case 'TransformComponent':
						var flag = attribute.a;
						var component = attribute.b;
						var $temp$classes = classes,
							$temp$node = node,
							$temp$has = A2($mdgriffith$elm_ui$Internal$Flag$add, flag, has),
							$temp$transform = A2($mdgriffith$elm_ui$Internal$Model$composeTransformation, transform, component),
							$temp$styles = styles,
							$temp$attrs = attrs,
							$temp$children = children,
							$temp$elementAttrs = remaining;
						classes = $temp$classes;
						node = $temp$node;
						has = $temp$has;
						transform = $temp$transform;
						styles = $temp$styles;
						attrs = $temp$attrs;
						children = $temp$children;
						elementAttrs = $temp$elementAttrs;
						continue gatherAttrRecursive;
					case 'Width':
						var width = attribute.a;
						if (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$width, has)) {
							var $temp$classes = classes,
								$temp$node = node,
								$temp$has = has,
								$temp$transform = transform,
								$temp$styles = styles,
								$temp$attrs = attrs,
								$temp$children = children,
								$temp$elementAttrs = remaining;
							classes = $temp$classes;
							node = $temp$node;
							has = $temp$has;
							transform = $temp$transform;
							styles = $temp$styles;
							attrs = $temp$attrs;
							children = $temp$children;
							elementAttrs = $temp$elementAttrs;
							continue gatherAttrRecursive;
						} else {
							switch (width.$) {
								case 'Px':
									var px = width.a;
									var $temp$classes = ($mdgriffith$elm_ui$Internal$Style$classes.widthExact + (' width-px-' + $elm$core$String$fromInt(px))) + (' ' + classes),
										$temp$node = node,
										$temp$has = A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$width, has),
										$temp$transform = transform,
										$temp$styles = A2(
										$elm$core$List$cons,
										A3(
											$mdgriffith$elm_ui$Internal$Model$Single,
											'width-px-' + $elm$core$String$fromInt(px),
											'width',
											$elm$core$String$fromInt(px) + 'px'),
										styles),
										$temp$attrs = attrs,
										$temp$children = children,
										$temp$elementAttrs = remaining;
									classes = $temp$classes;
									node = $temp$node;
									has = $temp$has;
									transform = $temp$transform;
									styles = $temp$styles;
									attrs = $temp$attrs;
									children = $temp$children;
									elementAttrs = $temp$elementAttrs;
									continue gatherAttrRecursive;
								case 'Content':
									var $temp$classes = classes + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.widthContent),
										$temp$node = node,
										$temp$has = A2(
										$mdgriffith$elm_ui$Internal$Flag$add,
										$mdgriffith$elm_ui$Internal$Flag$widthContent,
										A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$width, has)),
										$temp$transform = transform,
										$temp$styles = styles,
										$temp$attrs = attrs,
										$temp$children = children,
										$temp$elementAttrs = remaining;
									classes = $temp$classes;
									node = $temp$node;
									has = $temp$has;
									transform = $temp$transform;
									styles = $temp$styles;
									attrs = $temp$attrs;
									children = $temp$children;
									elementAttrs = $temp$elementAttrs;
									continue gatherAttrRecursive;
								case 'Fill':
									var portion = width.a;
									if (portion === 1) {
										var $temp$classes = classes + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.widthFill),
											$temp$node = node,
											$temp$has = A2(
											$mdgriffith$elm_ui$Internal$Flag$add,
											$mdgriffith$elm_ui$Internal$Flag$widthFill,
											A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$width, has)),
											$temp$transform = transform,
											$temp$styles = styles,
											$temp$attrs = attrs,
											$temp$children = children,
											$temp$elementAttrs = remaining;
										classes = $temp$classes;
										node = $temp$node;
										has = $temp$has;
										transform = $temp$transform;
										styles = $temp$styles;
										attrs = $temp$attrs;
										children = $temp$children;
										elementAttrs = $temp$elementAttrs;
										continue gatherAttrRecursive;
									} else {
										var $temp$classes = classes + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.widthFillPortion + (' width-fill-' + $elm$core$String$fromInt(portion)))),
											$temp$node = node,
											$temp$has = A2(
											$mdgriffith$elm_ui$Internal$Flag$add,
											$mdgriffith$elm_ui$Internal$Flag$widthFill,
											A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$width, has)),
											$temp$transform = transform,
											$temp$styles = A2(
											$elm$core$List$cons,
											A3(
												$mdgriffith$elm_ui$Internal$Model$Single,
												$mdgriffith$elm_ui$Internal$Style$classes.any + ('.' + ($mdgriffith$elm_ui$Internal$Style$classes.row + (' > ' + $mdgriffith$elm_ui$Internal$Style$dot(
													'width-fill-' + $elm$core$String$fromInt(portion))))),
												'flex-grow',
												$elm$core$String$fromInt(portion * 100000)),
											styles),
											$temp$attrs = attrs,
											$temp$children = children,
											$temp$elementAttrs = remaining;
										classes = $temp$classes;
										node = $temp$node;
										has = $temp$has;
										transform = $temp$transform;
										styles = $temp$styles;
										attrs = $temp$attrs;
										children = $temp$children;
										elementAttrs = $temp$elementAttrs;
										continue gatherAttrRecursive;
									}
								default:
									var _v4 = $mdgriffith$elm_ui$Internal$Model$renderWidth(width);
									var addToFlags = _v4.a;
									var newClass = _v4.b;
									var newStyles = _v4.c;
									var $temp$classes = classes + (' ' + newClass),
										$temp$node = node,
										$temp$has = A2(
										$mdgriffith$elm_ui$Internal$Flag$merge,
										addToFlags,
										A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$width, has)),
										$temp$transform = transform,
										$temp$styles = _Utils_ap(newStyles, styles),
										$temp$attrs = attrs,
										$temp$children = children,
										$temp$elementAttrs = remaining;
									classes = $temp$classes;
									node = $temp$node;
									has = $temp$has;
									transform = $temp$transform;
									styles = $temp$styles;
									attrs = $temp$attrs;
									children = $temp$children;
									elementAttrs = $temp$elementAttrs;
									continue gatherAttrRecursive;
							}
						}
					case 'Height':
						var height = attribute.a;
						if (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$height, has)) {
							var $temp$classes = classes,
								$temp$node = node,
								$temp$has = has,
								$temp$transform = transform,
								$temp$styles = styles,
								$temp$attrs = attrs,
								$temp$children = children,
								$temp$elementAttrs = remaining;
							classes = $temp$classes;
							node = $temp$node;
							has = $temp$has;
							transform = $temp$transform;
							styles = $temp$styles;
							attrs = $temp$attrs;
							children = $temp$children;
							elementAttrs = $temp$elementAttrs;
							continue gatherAttrRecursive;
						} else {
							switch (height.$) {
								case 'Px':
									var px = height.a;
									var val = $elm$core$String$fromInt(px) + 'px';
									var name = 'height-px-' + val;
									var $temp$classes = $mdgriffith$elm_ui$Internal$Style$classes.heightExact + (' ' + (name + (' ' + classes))),
										$temp$node = node,
										$temp$has = A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$height, has),
										$temp$transform = transform,
										$temp$styles = A2(
										$elm$core$List$cons,
										A3($mdgriffith$elm_ui$Internal$Model$Single, name, 'height ', val),
										styles),
										$temp$attrs = attrs,
										$temp$children = children,
										$temp$elementAttrs = remaining;
									classes = $temp$classes;
									node = $temp$node;
									has = $temp$has;
									transform = $temp$transform;
									styles = $temp$styles;
									attrs = $temp$attrs;
									children = $temp$children;
									elementAttrs = $temp$elementAttrs;
									continue gatherAttrRecursive;
								case 'Content':
									var $temp$classes = $mdgriffith$elm_ui$Internal$Style$classes.heightContent + (' ' + classes),
										$temp$node = node,
										$temp$has = A2(
										$mdgriffith$elm_ui$Internal$Flag$add,
										$mdgriffith$elm_ui$Internal$Flag$heightContent,
										A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$height, has)),
										$temp$transform = transform,
										$temp$styles = styles,
										$temp$attrs = attrs,
										$temp$children = children,
										$temp$elementAttrs = remaining;
									classes = $temp$classes;
									node = $temp$node;
									has = $temp$has;
									transform = $temp$transform;
									styles = $temp$styles;
									attrs = $temp$attrs;
									children = $temp$children;
									elementAttrs = $temp$elementAttrs;
									continue gatherAttrRecursive;
								case 'Fill':
									var portion = height.a;
									if (portion === 1) {
										var $temp$classes = $mdgriffith$elm_ui$Internal$Style$classes.heightFill + (' ' + classes),
											$temp$node = node,
											$temp$has = A2(
											$mdgriffith$elm_ui$Internal$Flag$add,
											$mdgriffith$elm_ui$Internal$Flag$heightFill,
											A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$height, has)),
											$temp$transform = transform,
											$temp$styles = styles,
											$temp$attrs = attrs,
											$temp$children = children,
											$temp$elementAttrs = remaining;
										classes = $temp$classes;
										node = $temp$node;
										has = $temp$has;
										transform = $temp$transform;
										styles = $temp$styles;
										attrs = $temp$attrs;
										children = $temp$children;
										elementAttrs = $temp$elementAttrs;
										continue gatherAttrRecursive;
									} else {
										var $temp$classes = classes + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.heightFillPortion + (' height-fill-' + $elm$core$String$fromInt(portion)))),
											$temp$node = node,
											$temp$has = A2(
											$mdgriffith$elm_ui$Internal$Flag$add,
											$mdgriffith$elm_ui$Internal$Flag$heightFill,
											A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$height, has)),
											$temp$transform = transform,
											$temp$styles = A2(
											$elm$core$List$cons,
											A3(
												$mdgriffith$elm_ui$Internal$Model$Single,
												$mdgriffith$elm_ui$Internal$Style$classes.any + ('.' + ($mdgriffith$elm_ui$Internal$Style$classes.column + (' > ' + $mdgriffith$elm_ui$Internal$Style$dot(
													'height-fill-' + $elm$core$String$fromInt(portion))))),
												'flex-grow',
												$elm$core$String$fromInt(portion * 100000)),
											styles),
											$temp$attrs = attrs,
											$temp$children = children,
											$temp$elementAttrs = remaining;
										classes = $temp$classes;
										node = $temp$node;
										has = $temp$has;
										transform = $temp$transform;
										styles = $temp$styles;
										attrs = $temp$attrs;
										children = $temp$children;
										elementAttrs = $temp$elementAttrs;
										continue gatherAttrRecursive;
									}
								default:
									var _v6 = $mdgriffith$elm_ui$Internal$Model$renderHeight(height);
									var addToFlags = _v6.a;
									var newClass = _v6.b;
									var newStyles = _v6.c;
									var $temp$classes = classes + (' ' + newClass),
										$temp$node = node,
										$temp$has = A2(
										$mdgriffith$elm_ui$Internal$Flag$merge,
										addToFlags,
										A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$height, has)),
										$temp$transform = transform,
										$temp$styles = _Utils_ap(newStyles, styles),
										$temp$attrs = attrs,
										$temp$children = children,
										$temp$elementAttrs = remaining;
									classes = $temp$classes;
									node = $temp$node;
									has = $temp$has;
									transform = $temp$transform;
									styles = $temp$styles;
									attrs = $temp$attrs;
									children = $temp$children;
									elementAttrs = $temp$elementAttrs;
									continue gatherAttrRecursive;
							}
						}
					case 'Describe':
						var description = attribute.a;
						switch (description.$) {
							case 'Main':
								var $temp$classes = classes,
									$temp$node = A2($mdgriffith$elm_ui$Internal$Model$addNodeName, 'main', node),
									$temp$has = has,
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = attrs,
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							case 'Navigation':
								var $temp$classes = classes,
									$temp$node = A2($mdgriffith$elm_ui$Internal$Model$addNodeName, 'nav', node),
									$temp$has = has,
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = attrs,
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							case 'ContentInfo':
								var $temp$classes = classes,
									$temp$node = A2($mdgriffith$elm_ui$Internal$Model$addNodeName, 'footer', node),
									$temp$has = has,
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = attrs,
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							case 'Complementary':
								var $temp$classes = classes,
									$temp$node = A2($mdgriffith$elm_ui$Internal$Model$addNodeName, 'aside', node),
									$temp$has = has,
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = attrs,
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							case 'Heading':
								var i = description.a;
								if (i <= 1) {
									var $temp$classes = classes,
										$temp$node = A2($mdgriffith$elm_ui$Internal$Model$addNodeName, 'h1', node),
										$temp$has = has,
										$temp$transform = transform,
										$temp$styles = styles,
										$temp$attrs = attrs,
										$temp$children = children,
										$temp$elementAttrs = remaining;
									classes = $temp$classes;
									node = $temp$node;
									has = $temp$has;
									transform = $temp$transform;
									styles = $temp$styles;
									attrs = $temp$attrs;
									children = $temp$children;
									elementAttrs = $temp$elementAttrs;
									continue gatherAttrRecursive;
								} else {
									if (i < 7) {
										var $temp$classes = classes,
											$temp$node = A2(
											$mdgriffith$elm_ui$Internal$Model$addNodeName,
											'h' + $elm$core$String$fromInt(i),
											node),
											$temp$has = has,
											$temp$transform = transform,
											$temp$styles = styles,
											$temp$attrs = attrs,
											$temp$children = children,
											$temp$elementAttrs = remaining;
										classes = $temp$classes;
										node = $temp$node;
										has = $temp$has;
										transform = $temp$transform;
										styles = $temp$styles;
										attrs = $temp$attrs;
										children = $temp$children;
										elementAttrs = $temp$elementAttrs;
										continue gatherAttrRecursive;
									} else {
										var $temp$classes = classes,
											$temp$node = A2($mdgriffith$elm_ui$Internal$Model$addNodeName, 'h6', node),
											$temp$has = has,
											$temp$transform = transform,
											$temp$styles = styles,
											$temp$attrs = attrs,
											$temp$children = children,
											$temp$elementAttrs = remaining;
										classes = $temp$classes;
										node = $temp$node;
										has = $temp$has;
										transform = $temp$transform;
										styles = $temp$styles;
										attrs = $temp$attrs;
										children = $temp$children;
										elementAttrs = $temp$elementAttrs;
										continue gatherAttrRecursive;
									}
								}
							case 'Paragraph':
								var $temp$classes = classes,
									$temp$node = node,
									$temp$has = has,
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = attrs,
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							case 'Button':
								var $temp$classes = classes,
									$temp$node = node,
									$temp$has = has,
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = A2(
									$elm$core$List$cons,
									A2($elm$virtual_dom$VirtualDom$attribute, 'role', 'button'),
									attrs),
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							case 'Label':
								var label = description.a;
								var $temp$classes = classes,
									$temp$node = node,
									$temp$has = has,
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = A2(
									$elm$core$List$cons,
									A2($elm$virtual_dom$VirtualDom$attribute, 'aria-label', label),
									attrs),
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							case 'LivePolite':
								var $temp$classes = classes,
									$temp$node = node,
									$temp$has = has,
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = A2(
									$elm$core$List$cons,
									A2($elm$virtual_dom$VirtualDom$attribute, 'aria-live', 'polite'),
									attrs),
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							default:
								var $temp$classes = classes,
									$temp$node = node,
									$temp$has = has,
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = A2(
									$elm$core$List$cons,
									A2($elm$virtual_dom$VirtualDom$attribute, 'aria-live', 'assertive'),
									attrs),
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
						}
					case 'Nearby':
						var location = attribute.a;
						var elem = attribute.b;
						var newStyles = function () {
							switch (elem.$) {
								case 'Empty':
									return styles;
								case 'Text':
									var str = elem.a;
									return styles;
								case 'Unstyled':
									var html = elem.a;
									return styles;
								default:
									var styled = elem.a;
									return _Utils_ap(styles, styled.styles);
							}
						}();
						var $temp$classes = classes,
							$temp$node = node,
							$temp$has = has,
							$temp$transform = transform,
							$temp$styles = newStyles,
							$temp$attrs = attrs,
							$temp$children = A3($mdgriffith$elm_ui$Internal$Model$addNearbyElement, location, elem, children),
							$temp$elementAttrs = remaining;
						classes = $temp$classes;
						node = $temp$node;
						has = $temp$has;
						transform = $temp$transform;
						styles = $temp$styles;
						attrs = $temp$attrs;
						children = $temp$children;
						elementAttrs = $temp$elementAttrs;
						continue gatherAttrRecursive;
					case 'AlignX':
						var x = attribute.a;
						if (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$xAlign, has)) {
							var $temp$classes = classes,
								$temp$node = node,
								$temp$has = has,
								$temp$transform = transform,
								$temp$styles = styles,
								$temp$attrs = attrs,
								$temp$children = children,
								$temp$elementAttrs = remaining;
							classes = $temp$classes;
							node = $temp$node;
							has = $temp$has;
							transform = $temp$transform;
							styles = $temp$styles;
							attrs = $temp$attrs;
							children = $temp$children;
							elementAttrs = $temp$elementAttrs;
							continue gatherAttrRecursive;
						} else {
							var $temp$classes = $mdgriffith$elm_ui$Internal$Model$alignXName(x) + (' ' + classes),
								$temp$node = node,
								$temp$has = function (flags) {
								switch (x.$) {
									case 'CenterX':
										return A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$centerX, flags);
									case 'Right':
										return A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$alignRight, flags);
									default:
										return flags;
								}
							}(
								A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$xAlign, has)),
								$temp$transform = transform,
								$temp$styles = styles,
								$temp$attrs = attrs,
								$temp$children = children,
								$temp$elementAttrs = remaining;
							classes = $temp$classes;
							node = $temp$node;
							has = $temp$has;
							transform = $temp$transform;
							styles = $temp$styles;
							attrs = $temp$attrs;
							children = $temp$children;
							elementAttrs = $temp$elementAttrs;
							continue gatherAttrRecursive;
						}
					default:
						var y = attribute.a;
						if (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$yAlign, has)) {
							var $temp$classes = classes,
								$temp$node = node,
								$temp$has = has,
								$temp$transform = transform,
								$temp$styles = styles,
								$temp$attrs = attrs,
								$temp$children = children,
								$temp$elementAttrs = remaining;
							classes = $temp$classes;
							node = $temp$node;
							has = $temp$has;
							transform = $temp$transform;
							styles = $temp$styles;
							attrs = $temp$attrs;
							children = $temp$children;
							elementAttrs = $temp$elementAttrs;
							continue gatherAttrRecursive;
						} else {
							var $temp$classes = $mdgriffith$elm_ui$Internal$Model$alignYName(y) + (' ' + classes),
								$temp$node = node,
								$temp$has = function (flags) {
								switch (y.$) {
									case 'CenterY':
										return A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$centerY, flags);
									case 'Bottom':
										return A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$alignBottom, flags);
									default:
										return flags;
								}
							}(
								A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$yAlign, has)),
								$temp$transform = transform,
								$temp$styles = styles,
								$temp$attrs = attrs,
								$temp$children = children,
								$temp$elementAttrs = remaining;
							classes = $temp$classes;
							node = $temp$node;
							has = $temp$has;
							transform = $temp$transform;
							styles = $temp$styles;
							attrs = $temp$attrs;
							children = $temp$children;
							elementAttrs = $temp$elementAttrs;
							continue gatherAttrRecursive;
						}
				}
			}
		}
	});
var $mdgriffith$elm_ui$Internal$Model$Untransformed = {$: 'Untransformed'};
var $mdgriffith$elm_ui$Internal$Model$untransformed = $mdgriffith$elm_ui$Internal$Model$Untransformed;
var $mdgriffith$elm_ui$Internal$Model$element = F4(
	function (context, node, attributes, children) {
		return A3(
			$mdgriffith$elm_ui$Internal$Model$createElement,
			context,
			children,
			A8(
				$mdgriffith$elm_ui$Internal$Model$gatherAttrRecursive,
				$mdgriffith$elm_ui$Internal$Model$contextClasses(context),
				node,
				$mdgriffith$elm_ui$Internal$Flag$none,
				$mdgriffith$elm_ui$Internal$Model$untransformed,
				_List_Nil,
				_List_Nil,
				$mdgriffith$elm_ui$Internal$Model$NoNearbyChildren,
				$elm$core$List$reverse(attributes)));
	});
var $mdgriffith$elm_ui$Internal$Model$Height = function (a) {
	return {$: 'Height', a: a};
};
var $mdgriffith$elm_ui$Element$height = $mdgriffith$elm_ui$Internal$Model$Height;
var $mdgriffith$elm_ui$Internal$Model$Attr = function (a) {
	return {$: 'Attr', a: a};
};
var $mdgriffith$elm_ui$Internal$Model$htmlClass = function (cls) {
	return $mdgriffith$elm_ui$Internal$Model$Attr(
		$elm$html$Html$Attributes$class(cls));
};
var $mdgriffith$elm_ui$Internal$Model$Content = {$: 'Content'};
var $mdgriffith$elm_ui$Element$shrink = $mdgriffith$elm_ui$Internal$Model$Content;
var $mdgriffith$elm_ui$Internal$Model$Width = function (a) {
	return {$: 'Width', a: a};
};
var $mdgriffith$elm_ui$Element$width = $mdgriffith$elm_ui$Internal$Model$Width;
var $mdgriffith$elm_ui$Element$column = F2(
	function (attrs, children) {
		return A4(
			$mdgriffith$elm_ui$Internal$Model$element,
			$mdgriffith$elm_ui$Internal$Model$asColumn,
			$mdgriffith$elm_ui$Internal$Model$div,
			A2(
				$elm$core$List$cons,
				$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.contentTop + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.contentLeft)),
				A2(
					$elm$core$List$cons,
					$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$shrink),
					A2(
						$elm$core$List$cons,
						$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$shrink),
						attrs))),
			$mdgriffith$elm_ui$Internal$Model$Unkeyed(children));
	});
var $mdgriffith$elm_ui$Internal$Model$Fill = function (a) {
	return {$: 'Fill', a: a};
};
var $mdgriffith$elm_ui$Element$fill = $mdgriffith$elm_ui$Internal$Model$Fill(1);
var $mdgriffith$elm_ui$Internal$Model$Button = {$: 'Button'};
var $mdgriffith$elm_ui$Internal$Model$Describe = function (a) {
	return {$: 'Describe', a: a};
};
var $elm$json$Json$Encode$bool = _Json_wrap;
var $elm$html$Html$Attributes$boolProperty = F2(
	function (key, bool) {
		return A2(
			_VirtualDom_property,
			key,
			$elm$json$Json$Encode$bool(bool));
	});
var $elm$html$Html$Attributes$disabled = $elm$html$Html$Attributes$boolProperty('disabled');
var $mdgriffith$elm_ui$Element$Input$enter = 'Enter';
var $mdgriffith$elm_ui$Internal$Model$NoAttribute = {$: 'NoAttribute'};
var $mdgriffith$elm_ui$Element$Input$hasFocusStyle = function (attr) {
	if (((attr.$ === 'StyleClass') && (attr.b.$ === 'PseudoSelector')) && (attr.b.a.$ === 'Focus')) {
		var _v1 = attr.b;
		var _v2 = _v1.a;
		return true;
	} else {
		return false;
	}
};
var $mdgriffith$elm_ui$Element$Input$focusDefault = function (attrs) {
	return A2($elm$core$List$any, $mdgriffith$elm_ui$Element$Input$hasFocusStyle, attrs) ? $mdgriffith$elm_ui$Internal$Model$NoAttribute : $mdgriffith$elm_ui$Internal$Model$htmlClass('focusable');
};
var $elm$virtual_dom$VirtualDom$Normal = function (a) {
	return {$: 'Normal', a: a};
};
var $elm$virtual_dom$VirtualDom$on = _VirtualDom_on;
var $elm$html$Html$Events$on = F2(
	function (event, decoder) {
		return A2(
			$elm$virtual_dom$VirtualDom$on,
			event,
			$elm$virtual_dom$VirtualDom$Normal(decoder));
	});
var $elm$html$Html$Events$onClick = function (msg) {
	return A2(
		$elm$html$Html$Events$on,
		'click',
		$elm$json$Json$Decode$succeed(msg));
};
var $mdgriffith$elm_ui$Element$Events$onClick = A2($elm$core$Basics$composeL, $mdgriffith$elm_ui$Internal$Model$Attr, $elm$html$Html$Events$onClick);
var $elm$json$Json$Decode$fail = _Json_fail;
var $elm$virtual_dom$VirtualDom$MayPreventDefault = function (a) {
	return {$: 'MayPreventDefault', a: a};
};
var $elm$html$Html$Events$preventDefaultOn = F2(
	function (event, decoder) {
		return A2(
			$elm$virtual_dom$VirtualDom$on,
			event,
			$elm$virtual_dom$VirtualDom$MayPreventDefault(decoder));
	});
var $mdgriffith$elm_ui$Element$Input$onKeyLookup = function (lookup) {
	var decode = function (code) {
		var _v0 = lookup(code);
		if (_v0.$ === 'Nothing') {
			return $elm$json$Json$Decode$fail('No key matched');
		} else {
			var msg = _v0.a;
			return $elm$json$Json$Decode$succeed(msg);
		}
	};
	var isKey = A2(
		$elm$json$Json$Decode$andThen,
		decode,
		A2($elm$json$Json$Decode$field, 'key', $elm$json$Json$Decode$string));
	return $mdgriffith$elm_ui$Internal$Model$Attr(
		A2(
			$elm$html$Html$Events$preventDefaultOn,
			'keydown',
			A2(
				$elm$json$Json$Decode$map,
				function (fired) {
					return _Utils_Tuple2(fired, true);
				},
				isKey)));
};
var $mdgriffith$elm_ui$Internal$Model$Class = F2(
	function (a, b) {
		return {$: 'Class', a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Flag$cursor = $mdgriffith$elm_ui$Internal$Flag$flag(21);
var $mdgriffith$elm_ui$Element$pointer = A2($mdgriffith$elm_ui$Internal$Model$Class, $mdgriffith$elm_ui$Internal$Flag$cursor, $mdgriffith$elm_ui$Internal$Style$classes.cursorPointer);
var $mdgriffith$elm_ui$Element$Input$space = ' ';
var $elm$html$Html$Attributes$tabindex = function (n) {
	return A2(
		_VirtualDom_attribute,
		'tabIndex',
		$elm$core$String$fromInt(n));
};
var $mdgriffith$elm_ui$Element$Input$button = F2(
	function (attrs, _v0) {
		var onPress = _v0.onPress;
		var label = _v0.label;
		return A4(
			$mdgriffith$elm_ui$Internal$Model$element,
			$mdgriffith$elm_ui$Internal$Model$asEl,
			$mdgriffith$elm_ui$Internal$Model$div,
			A2(
				$elm$core$List$cons,
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$shrink),
				A2(
					$elm$core$List$cons,
					$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$shrink),
					A2(
						$elm$core$List$cons,
						$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.contentCenterX + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.contentCenterY + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.seButton + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.noTextSelection)))))),
						A2(
							$elm$core$List$cons,
							$mdgriffith$elm_ui$Element$pointer,
							A2(
								$elm$core$List$cons,
								$mdgriffith$elm_ui$Element$Input$focusDefault(attrs),
								A2(
									$elm$core$List$cons,
									$mdgriffith$elm_ui$Internal$Model$Describe($mdgriffith$elm_ui$Internal$Model$Button),
									A2(
										$elm$core$List$cons,
										$mdgriffith$elm_ui$Internal$Model$Attr(
											$elm$html$Html$Attributes$tabindex(0)),
										function () {
											if (onPress.$ === 'Nothing') {
												return A2(
													$elm$core$List$cons,
													$mdgriffith$elm_ui$Internal$Model$Attr(
														$elm$html$Html$Attributes$disabled(true)),
													attrs);
											} else {
												var msg = onPress.a;
												return A2(
													$elm$core$List$cons,
													$mdgriffith$elm_ui$Element$Events$onClick(msg),
													A2(
														$elm$core$List$cons,
														$mdgriffith$elm_ui$Element$Input$onKeyLookup(
															function (code) {
																return _Utils_eq(code, $mdgriffith$elm_ui$Element$Input$enter) ? $elm$core$Maybe$Just(msg) : (_Utils_eq(code, $mdgriffith$elm_ui$Element$Input$space) ? $elm$core$Maybe$Just(msg) : $elm$core$Maybe$Nothing);
															}),
														attrs));
											}
										}()))))))),
			$mdgriffith$elm_ui$Internal$Model$Unkeyed(
				_List_fromArray(
					[label])));
	});
var $mdgriffith$elm_ui$Internal$Model$AlignX = function (a) {
	return {$: 'AlignX', a: a};
};
var $mdgriffith$elm_ui$Internal$Model$CenterX = {$: 'CenterX'};
var $mdgriffith$elm_ui$Element$centerX = $mdgriffith$elm_ui$Internal$Model$AlignX($mdgriffith$elm_ui$Internal$Model$CenterX);
var $mdgriffith$elm_ui$Internal$Model$Colored = F3(
	function (a, b, c) {
		return {$: 'Colored', a: a, b: b, c: c};
	});
var $mdgriffith$elm_ui$Internal$Model$StyleClass = F2(
	function (a, b) {
		return {$: 'StyleClass', a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Flag$fontColor = $mdgriffith$elm_ui$Internal$Flag$flag(14);
var $mdgriffith$elm_ui$Internal$Model$formatColorClass = function (_v0) {
	var red = _v0.a;
	var green = _v0.b;
	var blue = _v0.c;
	var alpha = _v0.d;
	return $mdgriffith$elm_ui$Internal$Model$floatClass(red) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(green) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(blue) + ('-' + $mdgriffith$elm_ui$Internal$Model$floatClass(alpha))))));
};
var $mdgriffith$elm_ui$Element$Font$color = function (fontColor) {
	return A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$fontColor,
		A3(
			$mdgriffith$elm_ui$Internal$Model$Colored,
			'fc-' + $mdgriffith$elm_ui$Internal$Model$formatColorClass(fontColor),
			'color',
			fontColor));
};
var $mdgriffith$elm_ui$Element$el = F2(
	function (attrs, child) {
		return A4(
			$mdgriffith$elm_ui$Internal$Model$element,
			$mdgriffith$elm_ui$Internal$Model$asEl,
			$mdgriffith$elm_ui$Internal$Model$div,
			A2(
				$elm$core$List$cons,
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$shrink),
				A2(
					$elm$core$List$cons,
					$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$shrink),
					attrs)),
			$mdgriffith$elm_ui$Internal$Model$Unkeyed(
				_List_fromArray(
					[child])));
	});
var $mdgriffith$elm_ui$Internal$Model$Rgba = F4(
	function (a, b, c, d) {
		return {$: 'Rgba', a: a, b: b, c: c, d: d};
	});
var $mdgriffith$elm_ui$Element$rgb = F3(
	function (r, g, b) {
		return A4($mdgriffith$elm_ui$Internal$Model$Rgba, r, g, b, 1);
	});
var $mdgriffith$elm_ui$Internal$Model$FontSize = function (a) {
	return {$: 'FontSize', a: a};
};
var $mdgriffith$elm_ui$Internal$Flag$fontSize = $mdgriffith$elm_ui$Internal$Flag$flag(4);
var $mdgriffith$elm_ui$Element$Font$size = function (i) {
	return A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$fontSize,
		$mdgriffith$elm_ui$Internal$Model$FontSize(i));
};
var $mdgriffith$elm_ui$Internal$Model$Text = function (a) {
	return {$: 'Text', a: a};
};
var $mdgriffith$elm_ui$Element$text = function (content) {
	return $mdgriffith$elm_ui$Internal$Model$Text(content);
};
var $author$project$Buttons$buttonWrap = F2(
	function (description, button) {
		var descriptionStyle = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$Font$color(
				A3($mdgriffith$elm_ui$Element$rgb, 0.5, 0.5, 0.5)),
				$mdgriffith$elm_ui$Element$Font$size(10),
				$mdgriffith$elm_ui$Element$centerX
			]);
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[$mdgriffith$elm_ui$Element$centerX]),
			_List_fromArray(
				[
					button,
					A2(
					$mdgriffith$elm_ui$Element$el,
					descriptionStyle,
					$mdgriffith$elm_ui$Element$text(description))
				]));
	});
var $author$project$Buttons$aboutButton = function (size) {
	var theButton = A2(
		$mdgriffith$elm_ui$Element$Input$button,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$centerX,
				$mdgriffith$elm_ui$Element$Font$color(
				A3($mdgriffith$elm_ui$Element$rgb, 0.8, 0.8, 0.8))
			]),
		{
			label: A2(
				$mdgriffith$elm_ui$Element$el,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$Font$size(size)
					]),
				$mdgriffith$elm_ui$Element$text('A')),
			onPress: $elm$core$Maybe$Just($author$project$Messages$GotoAbout)
		});
	return A2($author$project$Buttons$buttonWrap, 'About', theButton);
};
var $mdgriffith$elm_ui$Internal$Flag$bgColor = $mdgriffith$elm_ui$Internal$Flag$flag(8);
var $mdgriffith$elm_ui$Element$Background$color = function (clr) {
	return A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$bgColor,
		A3(
			$mdgriffith$elm_ui$Internal$Model$Colored,
			'bg-' + $mdgriffith$elm_ui$Internal$Model$formatColorClass(clr),
			'background-color',
			clr));
};
var $lemol$ant_design_icons_elm_ui$Ant$Icon$Height = function (a) {
	return {$: 'Height', a: a};
};
var $lemol$ant_design_icons_elm_ui$Ant$Icon$height = $lemol$ant_design_icons_elm_ui$Ant$Icon$Height;
var $elm$svg$Svg$Attributes$d = _VirtualDom_attribute('d');
var $elm$svg$Svg$trustedNode = _VirtualDom_nodeNS('http://www.w3.org/2000/svg');
var $elm$svg$Svg$path = $elm$svg$Svg$trustedNode('path');
var $elm$svg$Svg$svg = $elm$svg$Svg$trustedNode('svg');
var $elm$svg$Svg$Attributes$viewBox = _VirtualDom_attribute('viewBox');
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$HomeOutlined$viewWithAttributes = function (attributes) {
	return A2(
		$elm$svg$Svg$svg,
		_Utils_ap(
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$viewBox('64 64 896 896')
				]),
			attributes),
		_List_fromArray(
			[
				A2(
				$elm$svg$Svg$path,
				_List_fromArray(
					[
						$elm$svg$Svg$Attributes$d('M946.5 505L560.1 118.8l-25.9-25.9a31.5 31.5 0 00-44.4 0L77.5 505a63.9 63.9 0 00-18.8 46c.4 35.2 29.7 63.3 64.9 63.3h42.5V940h691.8V614.3h43.4c17.1 0 33.2-6.7 45.3-18.8a63.6 63.6 0 0018.7-45.3c0-17-6.7-33.1-18.8-45.2zM568 868H456V664h112v204zm217.9-325.7V868H632V640c0-22.1-17.9-40-40-40H432c-22.1 0-40 17.9-40 40v228H238.1V542.3h-96l370-369.7 23.1 23.1L882 542.3h-96.1z')
					]),
				_List_Nil)
			]));
};
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$homeOutlined = $lemol$ant_design_icons_elm$Ant$Icons$Svg$HomeOutlined$viewWithAttributes;
var $elm$svg$Svg$Attributes$fill = _VirtualDom_attribute('fill');
var $lemol$ant_design_icons_elm_ui$Ant$Icon$defaultProps = {fill: $elm$core$Maybe$Nothing, height: $elm$core$Maybe$Nothing, rotate: $elm$core$Maybe$Nothing, spin: false, style: _List_Nil, twoToneColor: $elm$core$Maybe$Nothing, width: $elm$core$Maybe$Nothing};
var $lemol$ant_design_icons_elm_ui$Ant$Icon$fromAttributes = function () {
	var f = F2(
		function (act, acc) {
			switch (act.$) {
				case 'Spin':
					return _Utils_update(
						acc,
						{spin: true});
				case 'Rotate':
					var x = act.a;
					return _Utils_update(
						acc,
						{
							rotate: $elm$core$Maybe$Just(x)
						});
				case 'Width':
					var x = act.a;
					return _Utils_update(
						acc,
						{
							width: $elm$core$Maybe$Just(x)
						});
				case 'Height':
					var x = act.a;
					return _Utils_update(
						acc,
						{
							height: $elm$core$Maybe$Just(x)
						});
				case 'Fill':
					var x = act.a;
					return _Utils_update(
						acc,
						{
							fill: $elm$core$Maybe$Just(x)
						});
				case 'Style':
					var x = act.a;
					return _Utils_update(
						acc,
						{style: x});
				default:
					var x = act.a;
					return _Utils_update(
						acc,
						{
							twoToneColor: $elm$core$Maybe$Just(x)
						});
			}
		});
	return A2($elm$core$List$foldl, f, $lemol$ant_design_icons_elm_ui$Ant$Icon$defaultProps);
}();
var $elm$svg$Svg$Attributes$height = _VirtualDom_attribute('height');
var $elm$core$Basics$always = F2(
	function (a, _v0) {
		return a;
	});
var $mdgriffith$elm_ui$Internal$Model$unstyled = A2($elm$core$Basics$composeL, $mdgriffith$elm_ui$Internal$Model$Unstyled, $elm$core$Basics$always);
var $mdgriffith$elm_ui$Element$html = $mdgriffith$elm_ui$Internal$Model$unstyled;
var $mdgriffith$elm_ui$Internal$Model$Rotate = F2(
	function (a, b) {
		return {$: 'Rotate', a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Model$TransformComponent = F2(
	function (a, b) {
		return {$: 'TransformComponent', a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Flag$rotate = $mdgriffith$elm_ui$Internal$Flag$flag(24);
var $mdgriffith$elm_ui$Element$rotate = function (angle) {
	return A2(
		$mdgriffith$elm_ui$Internal$Model$TransformComponent,
		$mdgriffith$elm_ui$Internal$Flag$rotate,
		A2(
			$mdgriffith$elm_ui$Internal$Model$Rotate,
			_Utils_Tuple3(0, 0, 1),
			angle));
};
var $elm$core$List$singleton = function (value) {
	return _List_fromArray(
		[value]);
};
var $elm$virtual_dom$VirtualDom$style = _VirtualDom_style;
var $elm$html$Html$Attributes$style = $elm$virtual_dom$VirtualDom$style;
var $elm$svg$Svg$Attributes$width = _VirtualDom_attribute('width');
var $lemol$ant_design_icons_elm_ui$Ant$Icon$iconBase = F3(
	function (theme, attrs, svgIcon) {
		var props = $lemol$ant_design_icons_elm_ui$Ant$Icon$fromAttributes(attrs);
		var rotate_ = A2(
			$elm$core$Maybe$withDefault,
			_List_Nil,
			A2(
				$elm$core$Maybe$map,
				$elm$core$List$singleton,
				A2($elm$core$Maybe$map, $mdgriffith$elm_ui$Element$rotate, props.rotate)));
		var spin_ = props.spin ? _List_fromArray(
			[
				A2($elm$html$Html$Attributes$style, 'animation', 'loadingCircle 1s infinite linear')
			]) : _List_Nil;
		var svgAttributes = _Utils_ap(
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$width('1em'),
					$elm$svg$Svg$Attributes$height('1em'),
					$elm$svg$Svg$Attributes$fill('currentColor')
				]),
			spin_);
		var width_ = A2($elm$core$Maybe$withDefault, 1 * 14, props.width);
		var height_ = A2($elm$core$Maybe$withDefault, 1 * 14, props.width);
		var fill_ = A2(
			$elm$core$Maybe$withDefault,
			_List_Nil,
			A2(
				$elm$core$Maybe$map,
				$elm$core$List$singleton,
				A2($elm$core$Maybe$map, $mdgriffith$elm_ui$Element$Font$color, props.fill)));
		var elAttributes = _Utils_ap(
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Font$size(
					A2($elm$core$Basics$max, width_, height_))
				]),
			_Utils_ap(rotate_, fill_));
		return A2(
			$mdgriffith$elm_ui$Element$el,
			elAttributes,
			$mdgriffith$elm_ui$Element$html(
				svgIcon(svgAttributes)));
	});
var $lemol$ant_design_icons_elm_ui$Ant$Icon$icon = $lemol$ant_design_icons_elm_ui$Ant$Icon$iconBase(
	{});
var $lemol$ant_design_icons_elm_ui$Ant$Icons$homeOutlined = function (attrs) {
	return A2($lemol$ant_design_icons_elm_ui$Ant$Icon$icon, attrs, $lemol$ant_design_icons_elm$Ant$Icons$Svg$homeOutlined);
};
var $lemol$ant_design_icons_elm_ui$Ant$Icon$Width = function (a) {
	return {$: 'Width', a: a};
};
var $lemol$ant_design_icons_elm_ui$Ant$Icon$width = $lemol$ant_design_icons_elm_ui$Ant$Icon$Width;
var $author$project$Buttons$homeButton = function (size) {
	var theButton = A2(
		$mdgriffith$elm_ui$Element$Input$button,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$centerX,
				$mdgriffith$elm_ui$Element$Font$color(
				A3($mdgriffith$elm_ui$Element$rgb, 0.8, 0.8, 0.8))
			]),
		{
			label: $lemol$ant_design_icons_elm_ui$Ant$Icons$homeOutlined(
				_List_fromArray(
					[
						$lemol$ant_design_icons_elm_ui$Ant$Icon$width(size),
						$lemol$ant_design_icons_elm_ui$Ant$Icon$height(size)
					])),
			onPress: $elm$core$Maybe$Just($author$project$Messages$GotoHome)
		});
	return A2($author$project$Buttons$buttonWrap, 'Home/Contents', theButton);
};
var $mdgriffith$elm_ui$Internal$Model$Max = F2(
	function (a, b) {
		return {$: 'Max', a: a, b: b};
	});
var $mdgriffith$elm_ui$Element$maximum = F2(
	function (i, l) {
		return A2($mdgriffith$elm_ui$Internal$Model$Max, i, l);
	});
var $mdgriffith$elm_ui$Internal$Model$PaddingStyle = F5(
	function (a, b, c, d, e) {
		return {$: 'PaddingStyle', a: a, b: b, c: c, d: d, e: e};
	});
var $mdgriffith$elm_ui$Internal$Flag$padding = $mdgriffith$elm_ui$Internal$Flag$flag(2);
var $mdgriffith$elm_ui$Element$padding = function (x) {
	var f = x;
	return A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$padding,
		A5(
			$mdgriffith$elm_ui$Internal$Model$PaddingStyle,
			'p-' + $elm$core$String$fromInt(x),
			f,
			f,
			f,
			f));
};
var $mdgriffith$elm_ui$Internal$Model$AsRow = {$: 'AsRow'};
var $mdgriffith$elm_ui$Internal$Model$asRow = $mdgriffith$elm_ui$Internal$Model$AsRow;
var $mdgriffith$elm_ui$Element$row = F2(
	function (attrs, children) {
		return A4(
			$mdgriffith$elm_ui$Internal$Model$element,
			$mdgriffith$elm_ui$Internal$Model$asRow,
			$mdgriffith$elm_ui$Internal$Model$div,
			A2(
				$elm$core$List$cons,
				$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.contentLeft + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.contentCenterY)),
				A2(
					$elm$core$List$cons,
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$shrink),
					A2(
						$elm$core$List$cons,
						$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$shrink),
						attrs))),
			$mdgriffith$elm_ui$Internal$Model$Unkeyed(children));
	});
var $author$project$Main$headerOfPage = function (height) {
	var buttonHeight = $elm$core$Basics$round(height * 0.50);
	var padding = $elm$core$Basics$round((height - buttonHeight) * 0.25);
	return A2(
		$mdgriffith$elm_ui$Element$row,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$height(
				A2($mdgriffith$elm_ui$Element$maximum, height, $mdgriffith$elm_ui$Element$fill)),
				$mdgriffith$elm_ui$Element$Background$color(
				A3($mdgriffith$elm_ui$Element$rgb, 0.2, 0.2, 0.2))
			]),
		_List_fromArray(
			[
				A2(
				$mdgriffith$elm_ui$Element$el,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$padding(padding)
					]),
				$author$project$Buttons$homeButton(buttonHeight)),
				A2(
				$mdgriffith$elm_ui$Element$el,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$padding(padding)
					]),
				$author$project$Buttons$aboutButton(buttonHeight))
			]));
};
var $author$project$FontSize$Normal = {$: 'Normal'};
var $author$project$FontSize$getFontSize = F2(
	function (f, deviceType) {
		switch (f.$) {
			case 'Head':
				switch (deviceType.$) {
					case 'XXL':
						return 30;
					case 'XL':
						return 25;
					case 'Large':
						return 20;
					case 'Small':
						return 18;
					default:
						return 15;
				}
			case 'Title':
				switch (deviceType.$) {
					case 'XXL':
						return 50;
					case 'XL':
						return 45;
					case 'Large':
						return 30;
					case 'Small':
						return 30;
					default:
						return 25;
				}
			case 'Emph':
				switch (deviceType.$) {
					case 'XXL':
						return 22;
					case 'XL':
						return 19;
					case 'Large':
						return 17;
					case 'Small':
						return 14;
					default:
						return 12;
				}
			default:
				switch (deviceType.$) {
					case 'XXL':
						return 18;
					case 'XL':
						return 16;
					case 'Large':
						return 14;
					case 'Small':
						return 12;
					default:
						return 10;
				}
		}
	});
var $author$project$Main$layOutAttributes = function (deviceType) {
	return _List_fromArray(
		[
			$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$fill),
			$mdgriffith$elm_ui$Element$Background$color(
			A3($mdgriffith$elm_ui$Element$rgb, 0.2, 0.2, 0.2)),
			$mdgriffith$elm_ui$Element$Font$size(
			A2($author$project$FontSize$getFontSize, $author$project$FontSize$Normal, deviceType))
		]);
};
var $mdgriffith$elm_ui$Internal$Model$FocusStyleOption = function (a) {
	return {$: 'FocusStyleOption', a: a};
};
var $mdgriffith$elm_ui$Element$focusStyle = $mdgriffith$elm_ui$Internal$Model$FocusStyleOption;
var $author$project$Main$layOutOptions = {
	options: _List_fromArray(
		[
			$mdgriffith$elm_ui$Element$focusStyle(
			{backgroundColor: $elm$core$Maybe$Nothing, borderColor: $elm$core$Maybe$Nothing, shadow: $elm$core$Maybe$Nothing})
		])
};
var $mdgriffith$elm_ui$Internal$Model$OnlyDynamic = F2(
	function (a, b) {
		return {$: 'OnlyDynamic', a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Model$StaticRootAndDynamic = F2(
	function (a, b) {
		return {$: 'StaticRootAndDynamic', a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Model$AllowHover = {$: 'AllowHover'};
var $mdgriffith$elm_ui$Internal$Model$Layout = {$: 'Layout'};
var $mdgriffith$elm_ui$Internal$Model$focusDefaultStyle = {
	backgroundColor: $elm$core$Maybe$Nothing,
	borderColor: $elm$core$Maybe$Nothing,
	shadow: $elm$core$Maybe$Just(
		{
			blur: 0,
			color: A4($mdgriffith$elm_ui$Internal$Model$Rgba, 155 / 255, 203 / 255, 1, 1),
			offset: _Utils_Tuple2(0, 0),
			size: 3
		})
};
var $mdgriffith$elm_ui$Internal$Model$optionsToRecord = function (options) {
	var combine = F2(
		function (opt, record) {
			switch (opt.$) {
				case 'HoverOption':
					var hoverable = opt.a;
					var _v4 = record.hover;
					if (_v4.$ === 'Nothing') {
						return _Utils_update(
							record,
							{
								hover: $elm$core$Maybe$Just(hoverable)
							});
					} else {
						return record;
					}
				case 'FocusStyleOption':
					var focusStyle = opt.a;
					var _v5 = record.focus;
					if (_v5.$ === 'Nothing') {
						return _Utils_update(
							record,
							{
								focus: $elm$core$Maybe$Just(focusStyle)
							});
					} else {
						return record;
					}
				default:
					var renderMode = opt.a;
					var _v6 = record.mode;
					if (_v6.$ === 'Nothing') {
						return _Utils_update(
							record,
							{
								mode: $elm$core$Maybe$Just(renderMode)
							});
					} else {
						return record;
					}
			}
		});
	var andFinally = function (record) {
		return {
			focus: function () {
				var _v0 = record.focus;
				if (_v0.$ === 'Nothing') {
					return $mdgriffith$elm_ui$Internal$Model$focusDefaultStyle;
				} else {
					var focusable = _v0.a;
					return focusable;
				}
			}(),
			hover: function () {
				var _v1 = record.hover;
				if (_v1.$ === 'Nothing') {
					return $mdgriffith$elm_ui$Internal$Model$AllowHover;
				} else {
					var hoverable = _v1.a;
					return hoverable;
				}
			}(),
			mode: function () {
				var _v2 = record.mode;
				if (_v2.$ === 'Nothing') {
					return $mdgriffith$elm_ui$Internal$Model$Layout;
				} else {
					var actualMode = _v2.a;
					return actualMode;
				}
			}()
		};
	};
	return andFinally(
		A3(
			$elm$core$List$foldr,
			combine,
			{focus: $elm$core$Maybe$Nothing, hover: $elm$core$Maybe$Nothing, mode: $elm$core$Maybe$Nothing},
			options));
};
var $mdgriffith$elm_ui$Internal$Model$toHtml = F2(
	function (mode, el) {
		switch (el.$) {
			case 'Unstyled':
				var html = el.a;
				return html($mdgriffith$elm_ui$Internal$Model$asEl);
			case 'Styled':
				var styles = el.a.styles;
				var html = el.a.html;
				return A2(
					html,
					mode(styles),
					$mdgriffith$elm_ui$Internal$Model$asEl);
			case 'Text':
				var text = el.a;
				return $mdgriffith$elm_ui$Internal$Model$textElement(text);
			default:
				return $mdgriffith$elm_ui$Internal$Model$textElement('');
		}
	});
var $mdgriffith$elm_ui$Internal$Model$renderRoot = F3(
	function (optionList, attributes, child) {
		var options = $mdgriffith$elm_ui$Internal$Model$optionsToRecord(optionList);
		var embedStyle = function () {
			var _v0 = options.mode;
			if (_v0.$ === 'NoStaticStyleSheet') {
				return $mdgriffith$elm_ui$Internal$Model$OnlyDynamic(options);
			} else {
				return $mdgriffith$elm_ui$Internal$Model$StaticRootAndDynamic(options);
			}
		}();
		return A2(
			$mdgriffith$elm_ui$Internal$Model$toHtml,
			embedStyle,
			A4(
				$mdgriffith$elm_ui$Internal$Model$element,
				$mdgriffith$elm_ui$Internal$Model$asEl,
				$mdgriffith$elm_ui$Internal$Model$div,
				attributes,
				$mdgriffith$elm_ui$Internal$Model$Unkeyed(
					_List_fromArray(
						[child]))));
	});
var $mdgriffith$elm_ui$Internal$Model$FontFamily = F2(
	function (a, b) {
		return {$: 'FontFamily', a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Model$SansSerif = {$: 'SansSerif'};
var $mdgriffith$elm_ui$Internal$Model$Typeface = function (a) {
	return {$: 'Typeface', a: a};
};
var $mdgriffith$elm_ui$Internal$Flag$fontFamily = $mdgriffith$elm_ui$Internal$Flag$flag(5);
var $elm$core$String$toLower = _String_toLower;
var $elm$core$String$words = _String_words;
var $mdgriffith$elm_ui$Internal$Model$renderFontClassName = F2(
	function (font, current) {
		return _Utils_ap(
			current,
			function () {
				switch (font.$) {
					case 'Serif':
						return 'serif';
					case 'SansSerif':
						return 'sans-serif';
					case 'Monospace':
						return 'monospace';
					case 'Typeface':
						var name = font.a;
						return A2(
							$elm$core$String$join,
							'-',
							$elm$core$String$words(
								$elm$core$String$toLower(name)));
					case 'ImportFont':
						var name = font.a;
						var url = font.b;
						return A2(
							$elm$core$String$join,
							'-',
							$elm$core$String$words(
								$elm$core$String$toLower(name)));
					default:
						var name = font.a.name;
						return A2(
							$elm$core$String$join,
							'-',
							$elm$core$String$words(
								$elm$core$String$toLower(name)));
				}
			}());
	});
var $mdgriffith$elm_ui$Internal$Model$rootStyle = function () {
	var families = _List_fromArray(
		[
			$mdgriffith$elm_ui$Internal$Model$Typeface('Open Sans'),
			$mdgriffith$elm_ui$Internal$Model$Typeface('Helvetica'),
			$mdgriffith$elm_ui$Internal$Model$Typeface('Verdana'),
			$mdgriffith$elm_ui$Internal$Model$SansSerif
		]);
	return _List_fromArray(
		[
			A2(
			$mdgriffith$elm_ui$Internal$Model$StyleClass,
			$mdgriffith$elm_ui$Internal$Flag$bgColor,
			A3(
				$mdgriffith$elm_ui$Internal$Model$Colored,
				'bg-' + $mdgriffith$elm_ui$Internal$Model$formatColorClass(
					A4($mdgriffith$elm_ui$Internal$Model$Rgba, 1, 1, 1, 0)),
				'background-color',
				A4($mdgriffith$elm_ui$Internal$Model$Rgba, 1, 1, 1, 0))),
			A2(
			$mdgriffith$elm_ui$Internal$Model$StyleClass,
			$mdgriffith$elm_ui$Internal$Flag$fontColor,
			A3(
				$mdgriffith$elm_ui$Internal$Model$Colored,
				'fc-' + $mdgriffith$elm_ui$Internal$Model$formatColorClass(
					A4($mdgriffith$elm_ui$Internal$Model$Rgba, 0, 0, 0, 1)),
				'color',
				A4($mdgriffith$elm_ui$Internal$Model$Rgba, 0, 0, 0, 1))),
			A2(
			$mdgriffith$elm_ui$Internal$Model$StyleClass,
			$mdgriffith$elm_ui$Internal$Flag$fontSize,
			$mdgriffith$elm_ui$Internal$Model$FontSize(20)),
			A2(
			$mdgriffith$elm_ui$Internal$Model$StyleClass,
			$mdgriffith$elm_ui$Internal$Flag$fontFamily,
			A2(
				$mdgriffith$elm_ui$Internal$Model$FontFamily,
				A3($elm$core$List$foldl, $mdgriffith$elm_ui$Internal$Model$renderFontClassName, 'font-', families),
				families))
		]);
}();
var $mdgriffith$elm_ui$Element$layoutWith = F3(
	function (_v0, attrs, child) {
		var options = _v0.options;
		return A3(
			$mdgriffith$elm_ui$Internal$Model$renderRoot,
			options,
			A2(
				$elm$core$List$cons,
				$mdgriffith$elm_ui$Internal$Model$htmlClass(
					A2(
						$elm$core$String$join,
						' ',
						_List_fromArray(
							[$mdgriffith$elm_ui$Internal$Style$classes.root, $mdgriffith$elm_ui$Internal$Style$classes.any, $mdgriffith$elm_ui$Internal$Style$classes.single]))),
				_Utils_ap($mdgriffith$elm_ui$Internal$Model$rootStyle, attrs)),
			child);
	});
var $mdgriffith$elm_ui$Internal$Model$Left = {$: 'Left'};
var $mdgriffith$elm_ui$Element$alignLeft = $mdgriffith$elm_ui$Internal$Model$AlignX($mdgriffith$elm_ui$Internal$Model$Left);
var $mdgriffith$elm_ui$Internal$Model$AlignY = function (a) {
	return {$: 'AlignY', a: a};
};
var $mdgriffith$elm_ui$Internal$Model$CenterY = {$: 'CenterY'};
var $mdgriffith$elm_ui$Element$centerY = $mdgriffith$elm_ui$Internal$Model$AlignY($mdgriffith$elm_ui$Internal$Model$CenterY);
var $mdgriffith$elm_ui$Internal$Flag$fontWeight = $mdgriffith$elm_ui$Internal$Flag$flag(13);
var $mdgriffith$elm_ui$Element$Font$heavy = A2($mdgriffith$elm_ui$Internal$Model$Class, $mdgriffith$elm_ui$Internal$Flag$fontWeight, $mdgriffith$elm_ui$Internal$Style$classes.textHeavy);
var $mdgriffith$elm_ui$Internal$Model$Min = F2(
	function (a, b) {
		return {$: 'Min', a: a, b: b};
	});
var $mdgriffith$elm_ui$Element$minimum = F2(
	function (i, l) {
		return A2($mdgriffith$elm_ui$Internal$Model$Min, i, l);
	});
var $mdgriffith$elm_ui$Internal$Model$paddingName = F4(
	function (top, right, bottom, left) {
		return 'pad-' + ($elm$core$String$fromInt(top) + ('-' + ($elm$core$String$fromInt(right) + ('-' + ($elm$core$String$fromInt(bottom) + ('-' + $elm$core$String$fromInt(left)))))));
	});
var $mdgriffith$elm_ui$Element$paddingEach = function (_v0) {
	var top = _v0.top;
	var right = _v0.right;
	var bottom = _v0.bottom;
	var left = _v0.left;
	if (_Utils_eq(top, right) && (_Utils_eq(top, bottom) && _Utils_eq(top, left))) {
		var topFloat = top;
		return A2(
			$mdgriffith$elm_ui$Internal$Model$StyleClass,
			$mdgriffith$elm_ui$Internal$Flag$padding,
			A5(
				$mdgriffith$elm_ui$Internal$Model$PaddingStyle,
				'p-' + $elm$core$String$fromInt(top),
				topFloat,
				topFloat,
				topFloat,
				topFloat));
	} else {
		return A2(
			$mdgriffith$elm_ui$Internal$Model$StyleClass,
			$mdgriffith$elm_ui$Internal$Flag$padding,
			A5(
				$mdgriffith$elm_ui$Internal$Model$PaddingStyle,
				A4($mdgriffith$elm_ui$Internal$Model$paddingName, top, right, bottom, left),
				top,
				right,
				bottom,
				left));
	}
};
var $mdgriffith$elm_ui$Element$paddingXY = F2(
	function (x, y) {
		if (_Utils_eq(x, y)) {
			var f = x;
			return A2(
				$mdgriffith$elm_ui$Internal$Model$StyleClass,
				$mdgriffith$elm_ui$Internal$Flag$padding,
				A5(
					$mdgriffith$elm_ui$Internal$Model$PaddingStyle,
					'p-' + $elm$core$String$fromInt(x),
					f,
					f,
					f,
					f));
		} else {
			var yFloat = y;
			var xFloat = x;
			return A2(
				$mdgriffith$elm_ui$Internal$Model$StyleClass,
				$mdgriffith$elm_ui$Internal$Flag$padding,
				A5(
					$mdgriffith$elm_ui$Internal$Model$PaddingStyle,
					'p-' + ($elm$core$String$fromInt(x) + ('-' + $elm$core$String$fromInt(y))),
					yFloat,
					xFloat,
					yFloat,
					xFloat));
		}
	});
var $mdgriffith$elm_ui$Internal$Model$Paragraph = {$: 'Paragraph'};
var $mdgriffith$elm_ui$Internal$Model$SpacingStyle = F3(
	function (a, b, c) {
		return {$: 'SpacingStyle', a: a, b: b, c: c};
	});
var $mdgriffith$elm_ui$Internal$Flag$spacing = $mdgriffith$elm_ui$Internal$Flag$flag(3);
var $mdgriffith$elm_ui$Internal$Model$spacingName = F2(
	function (x, y) {
		return 'spacing-' + ($elm$core$String$fromInt(x) + ('-' + $elm$core$String$fromInt(y)));
	});
var $mdgriffith$elm_ui$Element$spacing = function (x) {
	return A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$spacing,
		A3(
			$mdgriffith$elm_ui$Internal$Model$SpacingStyle,
			A2($mdgriffith$elm_ui$Internal$Model$spacingName, x, x),
			x,
			x));
};
var $mdgriffith$elm_ui$Element$paragraph = F2(
	function (attrs, children) {
		return A4(
			$mdgriffith$elm_ui$Internal$Model$element,
			$mdgriffith$elm_ui$Internal$Model$asParagraph,
			$mdgriffith$elm_ui$Internal$Model$div,
			A2(
				$elm$core$List$cons,
				$mdgriffith$elm_ui$Internal$Model$Describe($mdgriffith$elm_ui$Internal$Model$Paragraph),
				A2(
					$elm$core$List$cons,
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
					A2(
						$elm$core$List$cons,
						$mdgriffith$elm_ui$Element$spacing(5),
						attrs))),
			$mdgriffith$elm_ui$Internal$Model$Unkeyed(children));
	});
var $mdgriffith$elm_ui$Internal$Flag$borderRound = $mdgriffith$elm_ui$Internal$Flag$flag(17);
var $mdgriffith$elm_ui$Element$Border$rounded = function (radius) {
	return A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$borderRound,
		A3(
			$mdgriffith$elm_ui$Internal$Model$Single,
			'br-' + $elm$core$String$fromInt(radius),
			'border-radius',
			$elm$core$String$fromInt(radius) + 'px'));
};
var $mdgriffith$elm_ui$Element$spacingXY = F2(
	function (x, y) {
		return A2(
			$mdgriffith$elm_ui$Internal$Model$StyleClass,
			$mdgriffith$elm_ui$Internal$Flag$spacing,
			A3(
				$mdgriffith$elm_ui$Internal$Model$SpacingStyle,
				A2($mdgriffith$elm_ui$Internal$Model$spacingName, x, y),
				x,
				y));
	});
var $author$project$Main$aboutProject = F2(
	function (width, height) {
		var capitalT = '\n            T\n            ';
		var aim = '\n            The aim of this project is to develop visual intuition for some of\n            the popular graph theory problems. Although, in mathematics formal\n            methods are used to describe terms, definitions and theorems.\n            Visual representation of the concepts can act as an aid to the\n            practioner to enrich his understanding or look at the same concept\n            in a different light.\n            ';
		var aboutText = ' \n            here are numerous phenomenon in science which can be best\n            studied when they are abstracted as graphs. Graphs can be used to\n            represent social networks, biological networks such as protien\n            - protien interaction in cells, neural networks and ecological\n            networks.  \n            ';
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Font$color(
					A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
					$mdgriffith$elm_ui$Element$Font$heavy,
					A2($mdgriffith$elm_ui$Element$spacingXY, 10, 15),
					A2($mdgriffith$elm_ui$Element$paddingXY, 30, 50),
					$mdgriffith$elm_ui$Element$width(
					A2($mdgriffith$elm_ui$Element$maximum, width * 2, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$height(
					A2($mdgriffith$elm_ui$Element$minimum, height, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$Border$rounded(10),
					$mdgriffith$elm_ui$Element$centerY,
					$mdgriffith$elm_ui$Element$centerX,
					$mdgriffith$elm_ui$Element$paddingEach(
					{bottom: 50, left: 10, right: 10, top: 10})
				]),
			_List_fromArray(
				[
					A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$Font$size(30),
							$mdgriffith$elm_ui$Element$centerX
						]),
					$mdgriffith$elm_ui$Element$text('Visualization of Classical ')),
					A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$Font$size(45),
							$mdgriffith$elm_ui$Element$centerX
						]),
					$mdgriffith$elm_ui$Element$text('Graph Theory Problems')),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_fromArray(
						[$mdgriffith$elm_ui$Element$centerX]),
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Element$el,
							_List_fromArray(
								[
									$mdgriffith$elm_ui$Element$alignLeft,
									$mdgriffith$elm_ui$Element$Font$size(40)
								]),
							$mdgriffith$elm_ui$Element$text(capitalT)),
							$mdgriffith$elm_ui$Element$text(aboutText),
							$mdgriffith$elm_ui$Element$text(aim)
						]))
				]));
	});
var $author$project$Main$acknowledgement = F2(
	function (width, height) {
		var thanks = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n                  This project would not have been possible without the\n                  the help, aid and advice of friends and family.\n                  ')
			]);
		var sofiat = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n                  I would like to thank my supervisor \n                  '),
				$mdgriffith$elm_ui$Element$text('Sofiat'),
				$mdgriffith$elm_ui$Element$text('\n                  for giving me a wonderful opportunity to explore the topics\n                  of Graph Theory.  Her constant support and guidance\n                  throughout the project was essential in building the app.\n                  ')
			]);
		var shrey = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n               Finaly, I would like to thank my friend \n               '),
				$mdgriffith$elm_ui$Element$text('Shrey'),
				$mdgriffith$elm_ui$Element$text('\n               for introducing\n               me to the Elm programming language.\n               ')
			]);
		var father = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n                  I would also like to thank my \n                  '),
				$mdgriffith$elm_ui$Element$text('father'),
				$mdgriffith$elm_ui$Element$text('\n                  for encouraging, believing and\n                  supporting me constantly in both the good and bad days.\n                  ')
			]);
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Font$color(
					A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
					$mdgriffith$elm_ui$Element$Font$heavy,
					A2($mdgriffith$elm_ui$Element$spacingXY, 10, 15),
					A2($mdgriffith$elm_ui$Element$paddingXY, 30, 50),
					$mdgriffith$elm_ui$Element$width(
					A2(
						$mdgriffith$elm_ui$Element$maximum,
						$elm$core$Basics$round(width),
						$mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$height(
					A2($mdgriffith$elm_ui$Element$minimum, height, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$Border$rounded(10),
					$mdgriffith$elm_ui$Element$paddingEach(
					{bottom: 50, left: 10, right: 10, top: 10})
				]),
			_List_fromArray(
				[
					A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$Font$size(30),
							$mdgriffith$elm_ui$Element$centerX
						]),
					$mdgriffith$elm_ui$Element$text('Acknowledgement')),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_fromArray(
						[$mdgriffith$elm_ui$Element$centerX]),
					sofiat),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_fromArray(
						[$mdgriffith$elm_ui$Element$centerX]),
					father),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_fromArray(
						[$mdgriffith$elm_ui$Element$centerX]),
					shrey),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_fromArray(
						[$mdgriffith$elm_ui$Element$centerX]),
					thanks)
				]));
	});
var $mdgriffith$elm_ui$Internal$Model$Right = {$: 'Right'};
var $mdgriffith$elm_ui$Element$alignRight = $mdgriffith$elm_ui$Internal$Model$AlignX($mdgriffith$elm_ui$Internal$Model$Right);
var $mdgriffith$elm_ui$Internal$Flag$borderColor = $mdgriffith$elm_ui$Internal$Flag$flag(28);
var $mdgriffith$elm_ui$Element$Border$color = function (clr) {
	return A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$borderColor,
		A3(
			$mdgriffith$elm_ui$Internal$Model$Colored,
			'bc-' + $mdgriffith$elm_ui$Internal$Model$formatColorClass(clr),
			'border-color',
			clr));
};
var $author$project$Main$emoji = F2(
	function (width, height) {
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Font$color(
					A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
					$mdgriffith$elm_ui$Element$Font$heavy,
					A2($mdgriffith$elm_ui$Element$spacingXY, 10, 15),
					$mdgriffith$elm_ui$Element$width(
					A2($mdgriffith$elm_ui$Element$maximum, width - 1, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$height(
					A2($mdgriffith$elm_ui$Element$minimum, height * 2, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$Border$rounded(20),
					$mdgriffith$elm_ui$Element$alignLeft,
					$mdgriffith$elm_ui$Element$centerY
				]),
			_List_fromArray(
				[
					A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$Font$size(250),
							$mdgriffith$elm_ui$Element$centerY
						]),
					$mdgriffith$elm_ui$Element$text(' \uD83D\uDE4F'))
				]));
	});
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$GithubFilled$viewWithAttributes = function (attributes) {
	return A2(
		$elm$svg$Svg$svg,
		_Utils_ap(
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$viewBox('64 64 896 896')
				]),
			attributes),
		_List_fromArray(
			[
				A2(
				$elm$svg$Svg$path,
				_List_fromArray(
					[
						$elm$svg$Svg$Attributes$d('M511.6 76.3C264.3 76.2 64 276.4 64 523.5 64 718.9 189.3 885 363.8 946c23.5 5.9 19.9-10.8 19.9-22.2v-77.5c-135.7 15.9-141.2-73.9-150.3-88.9C215 726 171.5 718 184.5 703c30.9-15.9 62.4 4 98.9 57.9 26.4 39.1 77.9 32.5 104 26 5.7-23.5 17.9-44.5 34.7-60.8-140.6-25.2-199.2-111-199.2-213 0-49.5 16.3-95 48.3-131.7-20.4-60.5 1.9-112.3 4.9-120 58.1-5.2 118.5 41.6 123.2 45.3 33-8.9 70.7-13.6 112.9-13.6 42.4 0 80.2 4.9 113.5 13.9 11.3-8.6 67.3-48.8 121.3-43.9 2.9 7.7 24.7 58.3 5.5 118 32.4 36.8 48.9 82.7 48.9 132.3 0 102.2-59 188.1-200 212.9a127.5 127.5 0 0138.1 91v112.5c.8 9 0 17.9 15 17.9 177.1-59.7 304.6-227 304.6-424.1 0-247.2-200.4-447.3-447.5-447.3z')
					]),
				_List_Nil)
			]));
};
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$githubFilled = $lemol$ant_design_icons_elm$Ant$Icons$Svg$GithubFilled$viewWithAttributes;
var $lemol$ant_design_icons_elm_ui$Ant$Icons$githubFilled = function (attrs) {
	return A2($lemol$ant_design_icons_elm_ui$Ant$Icon$icon, attrs, $lemol$ant_design_icons_elm$Ant$Icons$Svg$githubFilled);
};
var $elm$html$Html$Attributes$href = function (url) {
	return A2(
		$elm$html$Html$Attributes$stringProperty,
		'href',
		_VirtualDom_noJavaScriptUri(url));
};
var $elm$html$Html$Attributes$rel = _VirtualDom_attribute('rel');
var $elm$html$Html$Attributes$target = $elm$html$Html$Attributes$stringProperty('target');
var $mdgriffith$elm_ui$Element$newTabLink = F2(
	function (attrs, _v0) {
		var url = _v0.url;
		var label = _v0.label;
		return A4(
			$mdgriffith$elm_ui$Internal$Model$element,
			$mdgriffith$elm_ui$Internal$Model$asEl,
			$mdgriffith$elm_ui$Internal$Model$NodeName('a'),
			A2(
				$elm$core$List$cons,
				$mdgriffith$elm_ui$Internal$Model$Attr(
					$elm$html$Html$Attributes$href(url)),
				A2(
					$elm$core$List$cons,
					$mdgriffith$elm_ui$Internal$Model$Attr(
						$elm$html$Html$Attributes$rel('noopener noreferrer')),
					A2(
						$elm$core$List$cons,
						$mdgriffith$elm_ui$Internal$Model$Attr(
							$elm$html$Html$Attributes$target('_blank')),
						A2(
							$elm$core$List$cons,
							$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$shrink),
							A2(
								$elm$core$List$cons,
								$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$shrink),
								A2(
									$elm$core$List$cons,
									$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.contentCenterX + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.contentCenterY + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.link)))),
									attrs)))))),
			$mdgriffith$elm_ui$Internal$Model$Unkeyed(
				_List_fromArray(
					[label])));
	});
var $author$project$Buttons$gitHubButton = function () {
	var github = A2(
		$mdgriffith$elm_ui$Element$newTabLink,
		_List_Nil,
		{
			label: $lemol$ant_design_icons_elm_ui$Ant$Icons$githubFilled(
				_List_fromArray(
					[
						$lemol$ant_design_icons_elm_ui$Ant$Icon$width(40),
						$lemol$ant_design_icons_elm_ui$Ant$Icon$height(40)
					])),
			url: 'https://github.com/FatmaSayegh/'
		});
	return A2($author$project$Buttons$buttonWrap, 'GitHub', github);
}();
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$LinkedinFilled$viewWithAttributes = function (attributes) {
	return A2(
		$elm$svg$Svg$svg,
		_Utils_ap(
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$viewBox('64 64 896 896')
				]),
			attributes),
		_List_fromArray(
			[
				A2(
				$elm$svg$Svg$path,
				_List_fromArray(
					[
						$elm$svg$Svg$Attributes$d('M880 112H144c-17.7 0-32 14.3-32 32v736c0 17.7 14.3 32 32 32h736c17.7 0 32-14.3 32-32V144c0-17.7-14.3-32-32-32zM349.3 793.7H230.6V411.9h118.7v381.8zm-59.3-434a68.8 68.8 0 1168.8-68.8c-.1 38-30.9 68.8-68.8 68.8zm503.7 434H675.1V608c0-44.3-.8-101.2-61.7-101.2-61.7 0-71.2 48.2-71.2 98v188.9H423.7V411.9h113.8v52.2h1.6c15.8-30 54.5-61.7 112.3-61.7 120.2 0 142.3 79.1 142.3 181.9v209.4z')
					]),
				_List_Nil)
			]));
};
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$linkedinFilled = $lemol$ant_design_icons_elm$Ant$Icons$Svg$LinkedinFilled$viewWithAttributes;
var $lemol$ant_design_icons_elm_ui$Ant$Icons$linkedinFilled = function (attrs) {
	return A2($lemol$ant_design_icons_elm_ui$Ant$Icon$icon, attrs, $lemol$ant_design_icons_elm$Ant$Icons$Svg$linkedinFilled);
};
var $author$project$Buttons$linkedInFatmaButton = function () {
	var linkedIn = A2(
		$mdgriffith$elm_ui$Element$newTabLink,
		_List_Nil,
		{
			label: $lemol$ant_design_icons_elm_ui$Ant$Icons$linkedinFilled(
				_List_fromArray(
					[
						$lemol$ant_design_icons_elm_ui$Ant$Icon$width(40),
						$lemol$ant_design_icons_elm_ui$Ant$Icon$height(40)
					])),
			url: 'https://www.linkedin.com/in/fatma-alsayegh-1a060220a/'
		});
	return A2($author$project$Buttons$buttonWrap, 'LinkedIn', linkedIn);
}();
var $author$project$Buttons$fatmaButtons = A2(
	$mdgriffith$elm_ui$Element$row,
	_List_fromArray(
		[
			$mdgriffith$elm_ui$Element$centerX,
			$mdgriffith$elm_ui$Element$spacing(20)
		]),
	_List_fromArray(
		[$author$project$Buttons$linkedInFatmaButton, $author$project$Buttons$gitHubButton]));
var $author$project$Main$introFatma = F2(
	function (width, height) {
		var fatmasIntro = '\n            I am a fourth year Software Engineering student in University\n            of Glasgow. This web app was built for my final year\n            project. My intrests are maths, functional programming and drawing.\n            ';
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Font$color(
					A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
					$mdgriffith$elm_ui$Element$Font$heavy,
					A2($mdgriffith$elm_ui$Element$spacingXY, 10, 15),
					A2($mdgriffith$elm_ui$Element$paddingXY, 30, 50),
					$mdgriffith$elm_ui$Element$width(
					A2($mdgriffith$elm_ui$Element$maximum, width, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$height(
					A2($mdgriffith$elm_ui$Element$minimum, height, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$Border$rounded(10),
					$mdgriffith$elm_ui$Element$alignLeft
				]),
			_List_fromArray(
				[
					A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$Font$size(30)
						]),
					$mdgriffith$elm_ui$Element$text('Fatma Alsayegh')),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_Nil,
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Element$el,
							_List_Nil,
							$mdgriffith$elm_ui$Element$text('Hi I am ')),
							A2(
							$mdgriffith$elm_ui$Element$el,
							_List_fromArray(
								[
									$mdgriffith$elm_ui$Element$Font$color(
									A3($mdgriffith$elm_ui$Element$rgb, 0.5, 0.9, 0.7)),
									$mdgriffith$elm_ui$Element$Font$size(25)
								]),
							$mdgriffith$elm_ui$Element$text('Fatma! ')),
							A2(
							$mdgriffith$elm_ui$Element$el,
							_List_Nil,
							$mdgriffith$elm_ui$Element$text(fatmasIntro))
						])),
					$author$project$Buttons$fatmaButtons
				]));
	});
var $author$project$Buttons$linkedInSofiat = function () {
	var linkedIn = A2(
		$mdgriffith$elm_ui$Element$newTabLink,
		_List_Nil,
		{
			label: $lemol$ant_design_icons_elm_ui$Ant$Icons$linkedinFilled(
				_List_fromArray(
					[
						$lemol$ant_design_icons_elm_ui$Ant$Icon$width(40),
						$lemol$ant_design_icons_elm_ui$Ant$Icon$height(40)
					])),
			url: 'https://www.linkedin.com/in/sofiatolaosebikan/'
		});
	return A2($author$project$Buttons$buttonWrap, 'LinkedIn', linkedIn);
}();
var $author$project$Buttons$websiteSofiat = function () {
	var website = A2(
		$mdgriffith$elm_ui$Element$newTabLink,
		_List_Nil,
		{
			label: A2(
				$mdgriffith$elm_ui$Element$el,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$Font$size(40)
					]),
				$mdgriffith$elm_ui$Element$text('W')),
			url: 'https://www.dcs.gla.ac.uk/~sofiat/'
		});
	return A2($author$project$Buttons$buttonWrap, 'Website', website);
}();
var $author$project$Buttons$sofiatButtons = A2(
	$mdgriffith$elm_ui$Element$row,
	_List_fromArray(
		[
			$mdgriffith$elm_ui$Element$centerX,
			$mdgriffith$elm_ui$Element$spacing(20)
		]),
	_List_fromArray(
		[$author$project$Buttons$linkedInSofiat, $author$project$Buttons$websiteSofiat]));
var $author$project$Main$introSuperVisor = F2(
	function (width, height) {
		var intro = '\n             Olaosebikan is a Lecturer in Algorithms and Complexity in the\n            School of Computing Science at the University of Glasgow. She has a\n            PhD in Computing Science from the University of Glasgow, Scotland;\n            an MSc in Mathematical Sciences from the African Institute for\n            Mathematical Sciences (AIMS), Ghana; and a BSc in Mathematics from\n            the University of Ibadan, Nigeria.  \n            ';
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Font$color(
					A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
					$mdgriffith$elm_ui$Element$Font$heavy,
					A2($mdgriffith$elm_ui$Element$spacingXY, 10, 15),
					A2($mdgriffith$elm_ui$Element$paddingXY, 30, 50),
					$mdgriffith$elm_ui$Element$width(
					A2($mdgriffith$elm_ui$Element$maximum, width, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$height(
					A2($mdgriffith$elm_ui$Element$minimum, height, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$Border$rounded(10)
				]),
			_List_fromArray(
				[
					A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$Font$size(30)
						]),
					$mdgriffith$elm_ui$Element$text('My Supervisor')),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_Nil,
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Element$el,
							_List_fromArray(
								[
									$mdgriffith$elm_ui$Element$Font$color(
									A3($mdgriffith$elm_ui$Element$rgb, 0.5, 0.9, 0.7)),
									$mdgriffith$elm_ui$Element$Font$size(25)
								]),
							$mdgriffith$elm_ui$Element$text('Sofiat ')),
							A2(
							$mdgriffith$elm_ui$Element$el,
							_List_Nil,
							$mdgriffith$elm_ui$Element$text(intro))
						])),
					$author$project$Buttons$sofiatButtons
				]));
	});
var $mdgriffith$elm_ui$Internal$Flag$overflow = $mdgriffith$elm_ui$Internal$Flag$flag(20);
var $mdgriffith$elm_ui$Element$clip = A2($mdgriffith$elm_ui$Internal$Model$Class, $mdgriffith$elm_ui$Internal$Flag$overflow, $mdgriffith$elm_ui$Internal$Style$classes.clip);
var $elm$html$Html$Attributes$alt = $elm$html$Html$Attributes$stringProperty('alt');
var $elm$html$Html$Attributes$src = function (url) {
	return A2(
		$elm$html$Html$Attributes$stringProperty,
		'src',
		_VirtualDom_noJavaScriptOrHtmlUri(url));
};
var $mdgriffith$elm_ui$Element$image = F2(
	function (attrs, _v0) {
		var src = _v0.src;
		var description = _v0.description;
		var imageAttributes = A2(
			$elm$core$List$filter,
			function (a) {
				switch (a.$) {
					case 'Width':
						return true;
					case 'Height':
						return true;
					default:
						return false;
				}
			},
			attrs);
		return A4(
			$mdgriffith$elm_ui$Internal$Model$element,
			$mdgriffith$elm_ui$Internal$Model$asEl,
			$mdgriffith$elm_ui$Internal$Model$div,
			A2(
				$elm$core$List$cons,
				$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.imageContainer),
				attrs),
			$mdgriffith$elm_ui$Internal$Model$Unkeyed(
				_List_fromArray(
					[
						A4(
						$mdgriffith$elm_ui$Internal$Model$element,
						$mdgriffith$elm_ui$Internal$Model$asEl,
						$mdgriffith$elm_ui$Internal$Model$NodeName('img'),
						_Utils_ap(
							_List_fromArray(
								[
									$mdgriffith$elm_ui$Internal$Model$Attr(
									$elm$html$Html$Attributes$src(src)),
									$mdgriffith$elm_ui$Internal$Model$Attr(
									$elm$html$Html$Attributes$alt(description))
								]),
							imageAttributes),
						$mdgriffith$elm_ui$Internal$Model$Unkeyed(_List_Nil))
					])));
	});
var $author$project$Main$photoGraph = F2(
	function (width, height) {
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Font$color(
					A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
					$mdgriffith$elm_ui$Element$Font$heavy,
					A2($mdgriffith$elm_ui$Element$spacingXY, 10, 15),
					$mdgriffith$elm_ui$Element$width(
					A2($mdgriffith$elm_ui$Element$maximum, width - 1, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$height(
					A2($mdgriffith$elm_ui$Element$minimum, height, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$Border$rounded(20),
					$mdgriffith$elm_ui$Element$alignRight,
					$mdgriffith$elm_ui$Element$clip
				]),
			_List_fromArray(
				[
					A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$Border$rounded(200)
						]),
					A2(
						$mdgriffith$elm_ui$Element$image,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$width(
								A2($mdgriffith$elm_ui$Element$maximum, 400, $mdgriffith$elm_ui$Element$fill)),
								$mdgriffith$elm_ui$Element$Border$rounded(200)
							]),
						{description: '', src: 'images/fatma.jpeg'}))
				]));
	});
var $author$project$Main$photoGraphSuperVisor = F2(
	function (width, height) {
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Font$color(
					A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
					$mdgriffith$elm_ui$Element$Font$heavy,
					A2($mdgriffith$elm_ui$Element$spacingXY, 10, 15),
					$mdgriffith$elm_ui$Element$width(
					A2($mdgriffith$elm_ui$Element$maximum, width - 1, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$height(
					A2($mdgriffith$elm_ui$Element$minimum, height, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$Border$rounded(20),
					$mdgriffith$elm_ui$Element$alignRight,
					$mdgriffith$elm_ui$Element$clip
				]),
			_List_fromArray(
				[
					A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$Border$rounded(200)
						]),
					A2(
						$mdgriffith$elm_ui$Element$image,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$width(
								A2($mdgriffith$elm_ui$Element$maximum, 400, $mdgriffith$elm_ui$Element$fill)),
								$mdgriffith$elm_ui$Element$height(
								A2($mdgriffith$elm_ui$Element$maximum, 380, $mdgriffith$elm_ui$Element$fill))
							]),
						{description: '', src: 'images/sofiat.jpg'}))
				]));
	});
var $mdgriffith$elm_ui$Element$scrollbarY = A2($mdgriffith$elm_ui$Internal$Model$Class, $mdgriffith$elm_ui$Internal$Flag$overflow, $mdgriffith$elm_ui$Internal$Style$classes.scrollbarsY);
var $author$project$Main$aboutPage = F2(
	function (widthIn, heightIn) {
		var width = (widthIn / 3) | 0;
		var height = (heightIn / 4) | 0;
		var project = A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Border$rounded(40),
					$mdgriffith$elm_ui$Element$Border$color(
					A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
					$mdgriffith$elm_ui$Element$centerX,
					$mdgriffith$elm_ui$Element$Font$color(
					A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1))
				]),
			_List_fromArray(
				[
					A2($author$project$Main$aboutProject, width, height)
				]));
		var superVisor = A2(
			$mdgriffith$elm_ui$Element$row,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Border$rounded(40),
					$mdgriffith$elm_ui$Element$Border$color(
					A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
					$mdgriffith$elm_ui$Element$alignRight
				]),
			_List_fromArray(
				[
					A2($author$project$Main$introSuperVisor, width, height),
					A2($author$project$Main$photoGraphSuperVisor, widthIn - width, height)
				]));
		var fatmasDetails = A2(
			$mdgriffith$elm_ui$Element$row,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Border$rounded(40),
					$mdgriffith$elm_ui$Element$Border$color(
					A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
					$mdgriffith$elm_ui$Element$alignLeft
				]),
			_List_fromArray(
				[
					A2($author$project$Main$introFatma, width, height),
					A2($author$project$Main$photoGraph, widthIn - width, height)
				]));
		var acknowledge = A2(
			$mdgriffith$elm_ui$Element$row,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Border$rounded(40),
					$mdgriffith$elm_ui$Element$Border$color(
					A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
					$mdgriffith$elm_ui$Element$alignLeft
				]),
			_List_fromArray(
				[
					A2($author$project$Main$acknowledgement, width, height),
					A2($author$project$Main$emoji, width, height)
				]));
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					A2($mdgriffith$elm_ui$Element$spacingXY, 40, 50),
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$padding(40),
					$mdgriffith$elm_ui$Element$scrollbarY,
					$mdgriffith$elm_ui$Element$centerX,
					$mdgriffith$elm_ui$Element$centerY
				]),
			_List_fromArray(
				[project, fatmasDetails, superVisor, acknowledge]));
	});
var $author$project$Main$displayColumn = function (svgHtml) {
	return A2(
		$mdgriffith$elm_ui$Element$column,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$Font$color(
				A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
				$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$Background$color(
				A3($mdgriffith$elm_ui$Element$rgb, 0.2, 0.2, 0.2))
			]),
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$html(svgHtml)
			]));
};
var $author$project$FontSize$CuteBlue = {$: 'CuteBlue'};
var $author$project$FontSize$CuteGreen = {$: 'CuteGreen'};
var $author$project$Buttons$GraphColoringHelp = {$: 'GraphColoringHelp'};
var $author$project$FontSize$Head = {$: 'Head'};
var $author$project$FontSize$Pink = {$: 'Pink'};
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$ForwardOutlined$viewWithAttributes = function (attributes) {
	return A2(
		$elm$svg$Svg$svg,
		_Utils_ap(
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$viewBox('0 0 1024 1024')
				]),
			attributes),
		_List_fromArray(
			[
				A2(
				$elm$svg$Svg$path,
				_List_fromArray(
					[
						$elm$svg$Svg$Attributes$d('M825.8 498L538.4 249.9c-10.7-9.2-26.4-.9-26.4 14v496.3c0 14.9 15.7 23.2 26.4 14L825.8 526c8.3-7.2 8.3-20.8 0-28zm-320 0L218.4 249.9c-10.7-9.2-26.4-.9-26.4 14v496.3c0 14.9 15.7 23.2 26.4 14L505.8 526c4.1-3.6 6.2-8.8 6.2-14 0-5.2-2.1-10.4-6.2-14z')
					]),
				_List_Nil)
			]));
};
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$forwardOutlined = $lemol$ant_design_icons_elm$Ant$Icons$Svg$ForwardOutlined$viewWithAttributes;
var $lemol$ant_design_icons_elm_ui$Ant$Icons$forwardOutlined = function (attrs) {
	return A2($lemol$ant_design_icons_elm_ui$Ant$Icon$icon, attrs, $lemol$ant_design_icons_elm$Ant$Icons$Svg$forwardOutlined);
};
var $author$project$Buttons$nextTask = function () {
	var theButton = A2(
		$mdgriffith$elm_ui$Element$Input$button,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$Border$rounded(100),
				$mdgriffith$elm_ui$Element$centerX
			]),
		{
			label: $lemol$ant_design_icons_elm_ui$Ant$Icons$forwardOutlined(
				_List_fromArray(
					[
						$lemol$ant_design_icons_elm_ui$Ant$Icon$width(50),
						$lemol$ant_design_icons_elm_ui$Ant$Icon$height(50)
					])),
			onPress: $elm$core$Maybe$Just($author$project$Messages$NextAnimation)
		});
	return A2($author$project$Buttons$buttonWrap, 'Next Task', theButton);
}();
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$RollbackOutlined$viewWithAttributes = function (attributes) {
	return A2(
		$elm$svg$Svg$svg,
		_Utils_ap(
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$viewBox('64 64 896 896')
				]),
			attributes),
		_List_fromArray(
			[
				A2(
				$elm$svg$Svg$path,
				_List_fromArray(
					[
						$elm$svg$Svg$Attributes$d('M793 242H366v-74c0-6.7-7.7-10.4-12.9-6.3l-142 112a8 8 0 000 12.6l142 112c5.2 4.1 12.9.4 12.9-6.3v-74h415v470H175c-4.4 0-8 3.6-8 8v60c0 4.4 3.6 8 8 8h618c35.3 0 64-28.7 64-64V306c0-35.3-28.7-64-64-64z')
					]),
				_List_Nil)
			]));
};
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$rollbackOutlined = $lemol$ant_design_icons_elm$Ant$Icons$Svg$RollbackOutlined$viewWithAttributes;
var $lemol$ant_design_icons_elm_ui$Ant$Icons$rollbackOutlined = function (attrs) {
	return A2($lemol$ant_design_icons_elm_ui$Ant$Icon$icon, attrs, $lemol$ant_design_icons_elm$Ant$Icons$Svg$rollbackOutlined);
};
var $author$project$Buttons$unColorButton = A2(
	$author$project$Buttons$buttonWrap,
	'Uncolor all Vertices',
	A2(
		$mdgriffith$elm_ui$Element$Input$button,
		_List_fromArray(
			[$mdgriffith$elm_ui$Element$centerX]),
		{
			label: $lemol$ant_design_icons_elm_ui$Ant$Icons$rollbackOutlined(
				_List_fromArray(
					[
						$lemol$ant_design_icons_elm_ui$Ant$Icon$width(70),
						$lemol$ant_design_icons_elm_ui$Ant$Icon$height(50)
					])),
			onPress: $elm$core$Maybe$Just($author$project$Messages$VertexNonColor)
		}));
var $author$project$GraphColoring$colorButtons = function (displaySize) {
	return A2(
		$mdgriffith$elm_ui$Element$row,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$centerX,
				$mdgriffith$elm_ui$Element$spacing((displaySize.width / 10) | 0)
			]),
		_List_fromArray(
			[$author$project$Buttons$unColorButton, $author$project$Buttons$nextTask]));
};
var $author$project$Explanation$coloringExplanation = '\n   The graph coloring problems objective is to assign colors to the vertices of a graph such that no to adjacent\n   vertices have the same color such that the number of colors utilized are kept at minimum.\n   The graph shown in the picture, needs three colors to color it properly.\n   ';
var $author$project$FontSize$Emph = {$: 'Emph'};
var $mdgriffith$elm_ui$Element$rgb255 = F3(
	function (red, green, blue) {
		return A4($mdgriffith$elm_ui$Internal$Model$Rgba, red / 255, green / 255, blue / 255, 1);
	});
var $author$project$FontSize$giveFontColor = function (fntcol) {
	switch (fntcol.$) {
		case 'Pink':
			return A3($mdgriffith$elm_ui$Element$rgb, 0.8, 0.6, 0.7);
		case 'CuteGreen':
			return A3($mdgriffith$elm_ui$Element$rgb, 0.5, 0.9, 0.7);
		case 'CuteBlue':
			return A3($mdgriffith$elm_ui$Element$rgb, 0.4, 0.9, 0.9);
		case 'Gold':
			return A3($mdgriffith$elm_ui$Element$rgb255, 191, 137, 21);
		default:
			return A3($mdgriffith$elm_ui$Element$rgb, 0.2, 0.2, 1);
	}
};
var $author$project$FontSize$emphForScreen = F3(
	function (deviceType, fontCol, str) {
		return A2(
			$mdgriffith$elm_ui$Element$el,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Font$color(
					$author$project$FontSize$giveFontColor(fontCol)),
					$mdgriffith$elm_ui$Element$Font$size(
					A2($author$project$FontSize$getFontSize, $author$project$FontSize$Emph, deviceType))
				]),
			$mdgriffith$elm_ui$Element$text(str));
	});
var $mdgriffith$elm_ui$Element$Font$bold = A2($mdgriffith$elm_ui$Internal$Model$Class, $mdgriffith$elm_ui$Internal$Flag$fontWeight, $mdgriffith$elm_ui$Internal$Style$classes.bold);
var $author$project$Buttons$helpGraphColor = _List_fromArray(
	[
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 10),
				$mdgriffith$elm_ui$Element$Font$bold
			]),
		$mdgriffith$elm_ui$Element$text('Mouse Funcionality:')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('Click color on the palette: Select Color')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('Click Vertex: Color the vertex with the selected color'))
	]);
var $author$project$Buttons$helpIsomorphic = _List_fromArray(
	[
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 10),
				$mdgriffith$elm_ui$Element$Font$bold
			]),
		$mdgriffith$elm_ui$Element$text('Keyboard Shorcuts:')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('h: Toggle Help')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('p: Toggle between pause and play animation')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('r: Restart animation')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('1,2,3 ..... 8: Select/Unselect a vertex')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('n: Next topic')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('N: Previous topic')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 10),
				$mdgriffith$elm_ui$Element$Font$bold
			]),
		$mdgriffith$elm_ui$Element$text('Mouse Funcionality:')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('Hover Over Vertex: Select Vertex '))
	]);
var $author$project$Buttons$helpMaxCut = _List_fromArray(
	[
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 10),
				$mdgriffith$elm_ui$Element$Font$bold
			]),
		$mdgriffith$elm_ui$Element$text('Keyboard Shorcuts:')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('h: Toggle Help')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('p: Toggle between pause and play animation')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('r: Restart animation')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('n: Next topic')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('N: Previous topic')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('t: Next animation')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('l: Draw Max cut line(s)'))
	]);
var $author$project$Buttons$helpTreeWidth = _List_fromArray(
	[
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 10)
			]),
		$mdgriffith$elm_ui$Element$text('Keyboard Shorcuts:')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('h: Toggle Help')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('t: Next animation in tree width')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('T: Previous animation in tree width'))
	]);
var $author$project$Buttons$helpVertexCover = _List_fromArray(
	[
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 10),
				$mdgriffith$elm_ui$Element$Font$size(20)
			]),
		$mdgriffith$elm_ui$Element$text('Keyboard Shorcuts:')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('h: Toggle Help')),
		A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paddingXY, 5, 2)
			]),
		$mdgriffith$elm_ui$Element$text('1,2,3,4 ..... 8: Select/Unselect Vertex'))
	]);
var $author$project$Buttons$helpParagraph = function (helpkind) {
	var helpdetails = function () {
		switch (helpkind.$) {
			case 'IsomorphismHelp':
				return $author$project$Buttons$helpIsomorphic;
			case 'MaxCutHelp':
				return $author$project$Buttons$helpMaxCut;
			case 'GraphColoringHelp':
				return $author$project$Buttons$helpGraphColor;
			case 'VertexCoverHelp':
				return $author$project$Buttons$helpVertexCover;
			default:
				return $author$project$Buttons$helpTreeWidth;
		}
	}();
	return A2(
		$mdgriffith$elm_ui$Element$el,
		_List_Nil,
		A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Font$color(
					A3($mdgriffith$elm_ui$Element$rgb, 0.8, 1, 0.8)),
					$mdgriffith$elm_ui$Element$Font$size(18),
					$mdgriffith$elm_ui$Element$Background$color(
					A3($mdgriffith$elm_ui$Element$rgb, 0.2, 0.2, 0.2))
				]),
			helpdetails));
};
var $author$project$Explanation$howToColor = function (deviceType) {
	var emph = $author$project$FontSize$emphForScreen(deviceType);
	return _List_fromArray(
		[
			A2(emph, $author$project$FontSize$CuteGreen, '\n      Choose \n      '),
			$mdgriffith$elm_ui$Element$text('\n      a color from the color palette by \n      '),
			A2(emph, $author$project$FontSize$CuteBlue, '\n      clicking \n      '),
			$mdgriffith$elm_ui$Element$text('\n      on one of the colors and \n      '),
			A2(emph, $author$project$FontSize$CuteGreen, 'apply'),
			$mdgriffith$elm_ui$Element$text('\n       it to one of the vertices.\n      While coloring the graph make sure that \n      '),
			$mdgriffith$elm_ui$Element$text('\n      no two adjacent vertices are colored the same. For if they are, the\n      edges connecting them will be displayed differently to let you know of the mistake.\n      ')
		]);
};
var $mdgriffith$elm_ui$Internal$Model$Bottom = {$: 'Bottom'};
var $mdgriffith$elm_ui$Element$alignBottom = $mdgriffith$elm_ui$Internal$Model$AlignY($mdgriffith$elm_ui$Internal$Model$Bottom);
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$InfoCircleOutlined$viewWithAttributes = function (attributes) {
	return A2(
		$elm$svg$Svg$svg,
		_Utils_ap(
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$viewBox('64 64 896 896')
				]),
			attributes),
		_List_fromArray(
			[
				A2(
				$elm$svg$Svg$path,
				_List_fromArray(
					[
						$elm$svg$Svg$Attributes$d('M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm0 820c-205.4 0-372-166.6-372-372s166.6-372 372-372 372 166.6 372 372-166.6 372-372 372z')
					]),
				_List_Nil),
				A2(
				$elm$svg$Svg$path,
				_List_fromArray(
					[
						$elm$svg$Svg$Attributes$d('M464 336a48 48 0 1096 0 48 48 0 10-96 0zm72 112h-48c-4.4 0-8 3.6-8 8v272c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8V456c0-4.4-3.6-8-8-8z')
					]),
				_List_Nil)
			]));
};
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$infoCircleOutlined = $lemol$ant_design_icons_elm$Ant$Icons$Svg$InfoCircleOutlined$viewWithAttributes;
var $lemol$ant_design_icons_elm_ui$Ant$Icons$infoCircleOutlined = function (attrs) {
	return A2($lemol$ant_design_icons_elm_ui$Ant$Icon$icon, attrs, $lemol$ant_design_icons_elm$Ant$Icons$Svg$infoCircleOutlined);
};
var $mdgriffith$elm_ui$Element$htmlAttribute = $mdgriffith$elm_ui$Internal$Model$Attr;
var $phollyer$elm_cursor$Element$Cursor$cursor = $mdgriffith$elm_ui$Element$htmlAttribute;
var $phollyer$elm_cursor$Html$Cursor$cursor = $elm$html$Html$Attributes$style('cursor');
var $phollyer$elm_cursor$Html$Cursor$pointer = $phollyer$elm_cursor$Html$Cursor$cursor('pointer');
var $phollyer$elm_cursor$Element$Cursor$pointer = $phollyer$elm_cursor$Element$Cursor$cursor($phollyer$elm_cursor$Html$Cursor$pointer);
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$VerticalLeftOutlined$viewWithAttributes = function (attributes) {
	return A2(
		$elm$svg$Svg$svg,
		_Utils_ap(
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$viewBox('64 64 896 896')
				]),
			attributes),
		_List_fromArray(
			[
				A2(
				$elm$svg$Svg$path,
				_List_fromArray(
					[
						$elm$svg$Svg$Attributes$d('M762 164h-64c-4.4 0-8 3.6-8 8v688c0 4.4 3.6 8 8 8h64c4.4 0 8-3.6 8-8V172c0-4.4-3.6-8-8-8zm-508 0v72.4c0 9.5 4.2 18.4 11.4 24.5L564.6 512 265.4 763.1c-7.2 6.1-11.4 15-11.4 24.5V860c0 6.8 7.9 10.5 13.1 6.1L689 512 267.1 157.9A7.95 7.95 0 00254 164z')
					]),
				_List_Nil)
			]));
};
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$verticalLeftOutlined = $lemol$ant_design_icons_elm$Ant$Icons$Svg$VerticalLeftOutlined$viewWithAttributes;
var $lemol$ant_design_icons_elm_ui$Ant$Icons$verticalLeftOutlined = function (attrs) {
	return A2($lemol$ant_design_icons_elm_ui$Ant$Icon$icon, attrs, $lemol$ant_design_icons_elm$Ant$Icons$Svg$verticalLeftOutlined);
};
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$VerticalRightOutlined$viewWithAttributes = function (attributes) {
	return A2(
		$elm$svg$Svg$svg,
		_Utils_ap(
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$viewBox('64 64 896 896')
				]),
			attributes),
		_List_fromArray(
			[
				A2(
				$elm$svg$Svg$path,
				_List_fromArray(
					[
						$elm$svg$Svg$Attributes$d('M326 164h-64c-4.4 0-8 3.6-8 8v688c0 4.4 3.6 8 8 8h64c4.4 0 8-3.6 8-8V172c0-4.4-3.6-8-8-8zm444 72.4V164c0-6.8-7.9-10.5-13.1-6.1L335 512l421.9 354.1c5.2 4.4 13.1.7 13.1-6.1v-72.4c0-9.4-4.2-18.4-11.4-24.5L459.4 512l299.2-251.1c7.2-6.1 11.4-15.1 11.4-24.5z')
					]),
				_List_Nil)
			]));
};
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$verticalRightOutlined = $lemol$ant_design_icons_elm$Ant$Icons$Svg$VerticalRightOutlined$viewWithAttributes;
var $lemol$ant_design_icons_elm_ui$Ant$Icons$verticalRightOutlined = function (attrs) {
	return A2($lemol$ant_design_icons_elm_ui$Ant$Icon$icon, attrs, $lemol$ant_design_icons_elm$Ant$Icons$Svg$verticalRightOutlined);
};
var $author$project$Buttons$lowerNavigation = F2(
	function (leftTitle, rightTitle) {
		return A2(
			$mdgriffith$elm_ui$Element$row,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$alignBottom,
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$padding(20),
					$mdgriffith$elm_ui$Element$spacing(20)
				]),
			_List_fromArray(
				[
					A2(
					$mdgriffith$elm_ui$Element$Input$button,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$Border$rounded(100),
							$mdgriffith$elm_ui$Element$alignLeft
						]),
					{
						label: $lemol$ant_design_icons_elm_ui$Ant$Icons$verticalRightOutlined(
							_List_fromArray(
								[
									$lemol$ant_design_icons_elm_ui$Ant$Icon$width(40),
									$lemol$ant_design_icons_elm_ui$Ant$Icon$height(40)
								])),
						onPress: $elm$core$Maybe$Just($author$project$Messages$PreviousTopic)
					}),
					A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$alignLeft,
							$mdgriffith$elm_ui$Element$Events$onClick($author$project$Messages$PreviousTopic),
							$phollyer$elm_cursor$Element$Cursor$pointer
						]),
					$mdgriffith$elm_ui$Element$text(leftTitle)),
					A2(
					$mdgriffith$elm_ui$Element$Input$button,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$Border$rounded(100),
							$mdgriffith$elm_ui$Element$centerX
						]),
					{
						label: $lemol$ant_design_icons_elm_ui$Ant$Icons$infoCircleOutlined(
							_List_fromArray(
								[
									$lemol$ant_design_icons_elm_ui$Ant$Icon$width(40),
									$lemol$ant_design_icons_elm_ui$Ant$Icon$height(40)
								])),
						onPress: $elm$core$Maybe$Just($author$project$Messages$ToggleHelpStatus)
					}),
					A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$alignRight,
							$mdgriffith$elm_ui$Element$Events$onClick($author$project$Messages$NextTopic),
							$phollyer$elm_cursor$Element$Cursor$pointer
						]),
					$mdgriffith$elm_ui$Element$text(rightTitle)),
					A2(
					$mdgriffith$elm_ui$Element$Input$button,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$Border$rounded(100),
							$mdgriffith$elm_ui$Element$alignRight
						]),
					{
						label: $lemol$ant_design_icons_elm_ui$Ant$Icons$verticalLeftOutlined(
							_List_fromArray(
								[
									$lemol$ant_design_icons_elm_ui$Ant$Icon$width(40),
									$lemol$ant_design_icons_elm_ui$Ant$Icon$height(40)
								])),
						onPress: $elm$core$Maybe$Just($author$project$Messages$NextTopic)
					})
				]));
	});
var $author$project$Explanation$makeCongrats = function (deviceType) {
	var emph = $author$project$FontSize$emphForScreen(deviceType);
	return _List_fromArray(
		[
			A2(emph, $author$project$FontSize$CuteGreen, 'C'),
			A2(emph, $author$project$FontSize$CuteBlue, 'o'),
			A2(emph, $author$project$FontSize$Pink, 'n'),
			A2(emph, $author$project$FontSize$CuteGreen, 'g'),
			A2(emph, $author$project$FontSize$CuteBlue, 'r'),
			A2(emph, $author$project$FontSize$Pink, 'a'),
			A2(emph, $author$project$FontSize$CuteGreen, 't'),
			A2(emph, $author$project$FontSize$CuteBlue, 'u'),
			A2(emph, $author$project$FontSize$Pink, 'l'),
			A2(emph, $author$project$FontSize$CuteGreen, 'a'),
			A2(emph, $author$project$FontSize$CuteBlue, 't'),
			A2(emph, $author$project$FontSize$Pink, 'i'),
			A2(emph, $author$project$FontSize$CuteGreen, 'o'),
			A2(emph, $author$project$FontSize$CuteBlue, 'n'),
			A2(emph, $author$project$FontSize$Pink, 's'),
			A2(emph, $author$project$FontSize$CuteGreen, '!')
		]);
};
var $author$project$GraphColoring$miscolorText = F2(
	function (deviceType, e) {
		var emph = $author$project$FontSize$emphForScreen(deviceType);
		return _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('Vertex '),
				A2(
				emph,
				$author$project$FontSize$Pink,
				$elm$core$String$fromInt(e.vertexOne.name)),
				$mdgriffith$elm_ui$Element$text(' and vertex '),
				A2(
				emph,
				$author$project$FontSize$Pink,
				$elm$core$String$fromInt(e.vertexTwo.name)),
				$mdgriffith$elm_ui$Element$text(' which are '),
				A2(emph, $author$project$FontSize$Pink, 'adjacent '),
				$mdgriffith$elm_ui$Element$text('to each other are colored with the '),
				A2(emph, $author$project$FontSize$Pink, 'same color. ')
			]);
	});
var $mdgriffith$elm_ui$Internal$Model$Empty = {$: 'Empty'};
var $mdgriffith$elm_ui$Element$none = $mdgriffith$elm_ui$Internal$Model$Empty;
var $author$project$GraphColoring$explanationColoring = F3(
	function (colorDispSer, helpStatus, displaySize) {
		var verticesOfSameColor = function (edge) {
			return _Utils_eq(edge.vertexOne.color, edge.vertexTwo.color) && (!_Utils_eq(
				edge.vertexOne.color,
				A3($avh4$elm_color$Color$rgb, 1, 1, 1)));
		};
		var emph = $author$project$FontSize$emphForScreen(displaySize.deviceType);
		var colorDisp = function () {
			var _v0 = colorDispSer.state;
			if (_v0.$ === 'TwoColor') {
				return colorDispSer.colorDisplayA;
			} else {
				return colorDispSer.colorDisplayB;
			}
		}();
		var coloredVertices = A2(
			$elm$core$List$filter,
			function (v) {
				return !_Utils_eq(
					v.color,
					A3($avh4$elm_color$Color$rgb, 1, 1, 1));
			},
			colorDisp.graphA.vertices);
		var miscoloredEdges = A2(
			$elm$core$List$filter,
			function (e) {
				return verticesOfSameColor(e);
			},
			colorDisp.graphA.edges);
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Font$color(
					A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
					$mdgriffith$elm_ui$Element$spacing(20),
					$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$Background$color(
					A3($mdgriffith$elm_ui$Element$rgb, 0.2, 0.2, 0.2)),
					$mdgriffith$elm_ui$Element$width(
					A2($mdgriffith$elm_ui$Element$maximum, displaySize.width, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$scrollbarY
				]),
			_List_fromArray(
				[
					A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$Font$size(
							A2($author$project$FontSize$getFontSize, $author$project$FontSize$Head, displaySize.deviceType)),
							$mdgriffith$elm_ui$Element$Font$heavy
						]),
					$mdgriffith$elm_ui$Element$text('Graph Coloring')),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$spacing(8)
						]),
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$text($author$project$Explanation$coloringExplanation)
						])),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_Nil,
					$author$project$Explanation$howToColor(displaySize.deviceType)),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_Nil,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$text('\n                     As a challenge you may try to color\n                     the graph with only two colors and see if\n                     it is feasible.\n                     ')
						])),
					$author$project$GraphColoring$colorButtons(displaySize),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_Nil,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$text(
							$elm$core$List$isEmpty(coloredVertices) ? '' : '\n                                   Coloring has started.\n                                   ')
						])),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_Nil,
					(($elm$core$List$length(coloredVertices) > 1) && (!$elm$core$List$length(miscoloredEdges))) ? _List_fromArray(
						[
							A2(emph, $author$project$FontSize$CuteGreen, 'Good going! '),
							$mdgriffith$elm_ui$Element$text('Adjacent Vertices are colored differently.')
						]) : _List_fromArray(
						[$mdgriffith$elm_ui$Element$none])),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_Nil,
					$elm$core$List$isEmpty(miscoloredEdges) ? _List_fromArray(
						[$mdgriffith$elm_ui$Element$none]) : $elm$core$List$concat(
						A2(
							$elm$core$List$map,
							$author$project$GraphColoring$miscolorText(displaySize.deviceType),
							miscoloredEdges))),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_Nil,
					$elm$core$List$isEmpty(miscoloredEdges) ? _List_fromArray(
						[$mdgriffith$elm_ui$Element$none]) : _List_fromArray(
						[
							A2(emph, $author$project$FontSize$CuteBlue, 'Try '),
							$mdgriffith$elm_ui$Element$text('another color combination. '),
							A2(emph, $author$project$FontSize$CuteGreen, 'Remember the rule;'),
							A2(emph, $author$project$FontSize$Pink, '\n                                       No two adjacent\n                                       '),
							$mdgriffith$elm_ui$Element$text('\n                                       vertices must have the same color!\n                                       ')
						])),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_Nil,
					($elm$core$List$isEmpty(miscoloredEdges) && _Utils_eq(
						$elm$core$List$length(coloredVertices),
						$elm$core$List$length(colorDisp.graphA.vertices))) ? _Utils_ap(
						$author$project$Explanation$makeCongrats(displaySize.deviceType),
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$text('\n                                        Graph has been colored\n                                       '),
								A2(emph, $author$project$FontSize$CuteGreen, '\n                                       fully \n                                       '),
								$mdgriffith$elm_ui$Element$text('\n                                       and \n                                       '),
								A2(emph, $author$project$FontSize$CuteGreen, '\n                                       correctly.\n                                       '),
								$mdgriffith$elm_ui$Element$text('\n                                       i.e. No two adjacent vertices have the same color.\n                                       ')
							])) : _List_fromArray(
						[$mdgriffith$elm_ui$Element$none])),
					helpStatus ? $author$project$Buttons$helpParagraph($author$project$Buttons$GraphColoringHelp) : $mdgriffith$elm_ui$Element$none,
					A2($author$project$Buttons$lowerNavigation, 'Max Cut', 'Vertex Cover')
				]));
	});
var $author$project$Buttons$VertexCoverHelp = {$: 'VertexCoverHelp'};
var $author$project$Graph$getStringFromVertices = function (vs) {
	if (!vs.b) {
		return '';
	} else {
		if (!vs.b.b) {
			var x = vs.a;
			return $elm$core$String$fromInt(x.name);
		} else {
			if (!vs.b.b.b) {
				var x = vs.a;
				var _v1 = vs.b;
				var y = _v1.a;
				return $elm$core$String$fromInt(x.name) + (' and ' + $author$project$Graph$getStringFromVertices(
					_List_fromArray(
						[y])));
			} else {
				var x = vs.a;
				var xs = vs.b;
				return $elm$core$String$fromInt(x.name) + (', ' + $author$project$Graph$getStringFromVertices(xs));
			}
		}
	}
};
var $author$project$Graph$isEdgeIn = F2(
	function (e, vs) {
		var v2 = e.vertexTwo;
		var v1 = e.vertexOne;
		var _v0 = _Utils_Tuple2(
			A2($author$project$Graph$lookUpVertex, v1.name, vs),
			A2($author$project$Graph$lookUpVertex, v2.name, vs));
		if ((_v0.a.$ === 'Nothing') && (_v0.b.$ === 'Nothing')) {
			var _v1 = _v0.a;
			var _v2 = _v0.b;
			return false;
		} else {
			return true;
		}
	});
var $author$project$Graph$seperateEdges = function (g) {
	var specialVertices = A2(
		$elm$core$List$filter,
		function (ver) {
			return ver.glow;
		},
		g.vertices);
	var specialEdges = A2(
		$elm$core$List$filter,
		function (edge) {
			return A2($author$project$Graph$isEdgeIn, edge, specialVertices);
		},
		g.edges);
	var normalEdges = A2(
		$elm$core$List$filter,
		function (edge) {
			return !A2($author$project$Graph$isEdgeIn, edge, specialVertices);
		},
		g.edges);
	return _Utils_Tuple2(specialEdges, normalEdges);
};
var $author$project$Buttons$tryDifferent = function () {
	var theButton = A2(
		$mdgriffith$elm_ui$Element$Input$button,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$Border$rounded(100),
				$mdgriffith$elm_ui$Element$centerX
			]),
		{
			label: $lemol$ant_design_icons_elm_ui$Ant$Icons$forwardOutlined(
				_List_fromArray(
					[
						$lemol$ant_design_icons_elm_ui$Ant$Icon$width(50),
						$lemol$ant_design_icons_elm_ui$Ant$Icon$height(50)
					])),
			onPress: $elm$core$Maybe$Just($author$project$Messages$NextAnimation)
		});
	return A2($author$project$Buttons$buttonWrap, 'Try a different task', theButton);
}();
var $author$project$VertexCover$vertexButtons = A2(
	$mdgriffith$elm_ui$Element$row,
	_List_fromArray(
		[$mdgriffith$elm_ui$Element$centerX]),
	_List_fromArray(
		[$author$project$Buttons$tryDifferent]));
var $author$project$Explanation$vertexCoverExplanation = '\n   Minimum Vertex cover of a graph is the minimum amount of vertices such that,\n   all the edges in the graph must have one of such vertices as one of\n   their endpoints.\n   ';
var $author$project$VertexCover$explanationCover = F3(
	function (display, helpStatus, displaySize) {
		var graph = function () {
			var _v2 = display.state;
			if (_v2.$ === 'First') {
				return display.graphA;
			} else {
				return display.graphB;
			}
		}();
		var selected_vertices = A2(
			$elm$core$List$filter,
			function (ver) {
				return ver.glow;
			},
			graph.vertices);
		var noOfSelectedVertices = $elm$core$List$length(selected_vertices);
		var totalEdges = $elm$core$List$length(graph.edges);
		var totalVertices = $elm$core$List$length(graph.vertices);
		var emph = $author$project$FontSize$emphForScreen(displaySize.deviceType);
		var _v0 = $author$project$Graph$seperateEdges(graph);
		var coveredEdges = _v0.a;
		var noCoveredEdges = $elm$core$List$length(coveredEdges);
		var edgesRemainig = totalEdges - noCoveredEdges;
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Font$color(
					A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
					$mdgriffith$elm_ui$Element$spacing(20),
					$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$width(
					A2($mdgriffith$elm_ui$Element$maximum, displaySize.width, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$Background$color(
					A3($mdgriffith$elm_ui$Element$rgb, 0.2, 0.2, 0.2)),
					$mdgriffith$elm_ui$Element$scrollbarY
				]),
			_List_fromArray(
				[
					A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$Font$size(
							A2($author$project$FontSize$getFontSize, $author$project$FontSize$Head, displaySize.deviceType)),
							$mdgriffith$elm_ui$Element$Font$heavy
						]),
					$mdgriffith$elm_ui$Element$text('Vertex Cover')),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$spacing(8)
						]),
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$text($author$project$Explanation$vertexCoverExplanation)
						])),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_Nil,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$text('\n                     In the task on the right, selecting a vertex will cover all\n                     the edges\n                     '),
							A2(emph, $author$project$FontSize$CuteGreen, '\n                     incident \n                     '),
							$mdgriffith$elm_ui$Element$text('\n                     on it. Your objective is to select the\n                     '),
							A2(emph, $author$project$FontSize$CuteGreen, '\n                     minimum \n                     '),
							$mdgriffith$elm_ui$Element$text('\n                     number of vertices such that, all the edges of the\n                     graph are covered.\n                     ')
						])),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_Nil,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$text('\n                     To select a vertex you can \n                     '),
							A2(emph, $author$project$FontSize$CuteBlue, '\n                      press \n                     '),
							$mdgriffith$elm_ui$Element$text('\n                     , the vertex \n                     '),
							A2(emph, $author$project$FontSize$CuteBlue, '\n                      number\n                     '),
							$mdgriffith$elm_ui$Element$text('\n                     on the keyboard. To \n                     '),
							A2(emph, $author$project$FontSize$CuteBlue, '\n                     de-select \n                     '),
							$mdgriffith$elm_ui$Element$text('\n                     , press the same key again.\n                     ')
						])),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_Nil,
					(!noOfSelectedVertices) ? _List_fromArray(
						[$mdgriffith$elm_ui$Element$none]) : _List_fromArray(
						[
							$mdgriffith$elm_ui$Element$text('You have selected a total of '),
							A2(
							emph,
							$author$project$FontSize$Pink,
							$elm$core$String$fromInt(noOfSelectedVertices)),
							$mdgriffith$elm_ui$Element$text(' vertices '),
							A2(emph, $author$project$FontSize$CuteGreen, 'out of '),
							A2(
							emph,
							$author$project$FontSize$Pink,
							$elm$core$String$fromInt(totalVertices)),
							$mdgriffith$elm_ui$Element$text(' vertices. ')
						])),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_Nil,
					(!noCoveredEdges) ? _List_fromArray(
						[$mdgriffith$elm_ui$Element$none]) : _List_fromArray(
						[
							$mdgriffith$elm_ui$Element$text('You have covered a total of '),
							A2(
							emph,
							$author$project$FontSize$Pink,
							$elm$core$String$fromInt(noCoveredEdges)),
							$mdgriffith$elm_ui$Element$text(' edges '),
							A2(emph, $author$project$FontSize$CuteGreen, 'out of '),
							$mdgriffith$elm_ui$Element$text('a total of '),
							A2(
							emph,
							$author$project$FontSize$Pink,
							$elm$core$String$fromInt(totalEdges)),
							$mdgriffith$elm_ui$Element$text(' edges. ')
						])),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_Nil,
					function () {
						if (!edgesRemainig) {
							var _v1 = display.state;
							if (_v1.$ === 'First') {
								return (noOfSelectedVertices > 4) ? _List_fromArray(
									[
										$mdgriffith$elm_ui$Element$text('\n                                          You have covered all the edges.\n                                          but\n                                          you have done so by selecting\n                                          '),
										A2(
										emph,
										$author$project$FontSize$Pink,
										$elm$core$String$fromInt(noOfSelectedVertices)),
										$mdgriffith$elm_ui$Element$text('\n                                          vertices. The graph could have been covered by\n                                          selecting only \n                                          '),
										A2(emph, $author$project$FontSize$Pink, '\n                                          four! \n                                          '),
										$mdgriffith$elm_ui$Element$text('\n                                          Try again to see that\n                                          you can do it in just four.\n                                          ')
									]) : _Utils_ap(
									$author$project$Explanation$makeCongrats(displaySize.deviceType),
									_List_fromArray(
										[
											$mdgriffith$elm_ui$Element$text(' you have covered all '),
											A2(
											emph,
											$author$project$FontSize$CuteBlue,
											$elm$core$String$fromInt(noCoveredEdges)),
											$mdgriffith$elm_ui$Element$text(' edges. '),
											$mdgriffith$elm_ui$Element$text('You have done so by selecting the vertices '),
											A2(
											emph,
											$author$project$FontSize$CuteBlue,
											$author$project$Graph$getStringFromVertices(selected_vertices)),
											$mdgriffith$elm_ui$Element$text('. Therefore a vertex cover of this graph is the'),
											A2(emph, $author$project$FontSize$CuteGreen, ' set '),
											$mdgriffith$elm_ui$Element$text(' of vertices '),
											A2(
											emph,
											$author$project$FontSize$CuteBlue,
											$author$project$Graph$getStringFromVertices(selected_vertices)),
											$mdgriffith$elm_ui$Element$text('.')
										]));
							} else {
								return (noOfSelectedVertices > 6) ? _List_fromArray(
									[
										$mdgriffith$elm_ui$Element$text('\n                                          You have covered all the edges.\n                                          but\n                                          you have done so by selecting\n                                          '),
										A2(
										emph,
										$author$project$FontSize$Pink,
										$elm$core$String$fromInt(noOfSelectedVertices)),
										$mdgriffith$elm_ui$Element$text('\n                                          vertices. The graph could have been covered by\n                                          selecting only \n                                          '),
										A2(emph, $author$project$FontSize$Pink, '\n                                          six! \n                                          '),
										$mdgriffith$elm_ui$Element$text('\n                                          Try again to see that\n                                          you can do it in just \n                                          '),
										A2(emph, $author$project$FontSize$Pink, '\n                                          six.\n                                          ')
									]) : _Utils_ap(
									$author$project$Explanation$makeCongrats(displaySize.deviceType),
									_List_fromArray(
										[
											$mdgriffith$elm_ui$Element$text(' you have covered all '),
											A2(
											emph,
											$author$project$FontSize$CuteBlue,
											$elm$core$String$fromInt(noCoveredEdges)),
											$mdgriffith$elm_ui$Element$text(' edges. '),
											$mdgriffith$elm_ui$Element$text('You have done so by selecting the vertices '),
											A2(
											emph,
											$author$project$FontSize$CuteBlue,
											$author$project$Graph$getStringFromVertices(selected_vertices)),
											$mdgriffith$elm_ui$Element$text('. Therefore a vertex cover of this graph is the'),
											A2(emph, $author$project$FontSize$CuteGreen, ' set '),
											$mdgriffith$elm_ui$Element$text(' of vertices '),
											A2(
											emph,
											$author$project$FontSize$CuteBlue,
											$author$project$Graph$getStringFromVertices(selected_vertices)),
											$mdgriffith$elm_ui$Element$text('.')
										]));
							}
						} else {
							if (_Utils_eq(edgesRemainig, totalEdges)) {
								return _List_fromArray(
									[$mdgriffith$elm_ui$Element$none]);
							} else {
								return _List_fromArray(
									[
										A2(
										emph,
										$author$project$FontSize$Pink,
										$elm$core$String$fromInt(edgesRemainig)),
										$mdgriffith$elm_ui$Element$text(' edges more to be covered!')
									]);
							}
						}
					}()),
					helpStatus ? $author$project$Buttons$helpParagraph($author$project$Buttons$VertexCoverHelp) : $mdgriffith$elm_ui$Element$none,
					$author$project$VertexCover$vertexButtons,
					A2($author$project$Buttons$lowerNavigation, 'Graph Coloring', 'Tree Width')
				]));
	});
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$CheckOutlined$viewWithAttributes = function (attributes) {
	return A2(
		$elm$svg$Svg$svg,
		_Utils_ap(
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$viewBox('64 64 896 896')
				]),
			attributes),
		_List_fromArray(
			[
				A2(
				$elm$svg$Svg$path,
				_List_fromArray(
					[
						$elm$svg$Svg$Attributes$d('M912 190h-69.9c-9.8 0-19.1 4.5-25.1 12.2L404.7 724.5 207 474a32 32 0 00-25.1-12.2H112c-6.7 0-10.4 7.7-6.3 12.9l273.9 347c12.8 16.2 37.4 16.2 50.3 0l488.4-618.9c4.1-5.1.4-12.8-6.3-12.8z')
					]),
				_List_Nil)
			]));
};
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$checkOutlined = $lemol$ant_design_icons_elm$Ant$Icons$Svg$CheckOutlined$viewWithAttributes;
var $lemol$ant_design_icons_elm_ui$Ant$Icons$checkOutlined = function (attrs) {
	return A2($lemol$ant_design_icons_elm_ui$Ant$Icon$icon, attrs, $lemol$ant_design_icons_elm$Ant$Icons$Svg$checkOutlined);
};
var $author$project$Buttons$isoCheckButton = A2(
	$author$project$Buttons$buttonWrap,
	'Check your Choice',
	A2(
		$mdgriffith$elm_ui$Element$Input$button,
		_List_fromArray(
			[$mdgriffith$elm_ui$Element$centerX]),
		{
			label: $lemol$ant_design_icons_elm_ui$Ant$Icons$checkOutlined(
				_List_fromArray(
					[
						$lemol$ant_design_icons_elm_ui$Ant$Icon$width(70),
						$lemol$ant_design_icons_elm_ui$Ant$Icon$height(50)
					])),
			onPress: $elm$core$Maybe$Just($author$project$Messages$IsoCheck)
		}));
var $author$project$Messages$IsoReset = {$: 'IsoReset'};
var $author$project$Buttons$isoResetButton = A2(
	$author$project$Buttons$buttonWrap,
	'Start Over',
	A2(
		$mdgriffith$elm_ui$Element$Input$button,
		_List_fromArray(
			[$mdgriffith$elm_ui$Element$centerX]),
		{
			label: $lemol$ant_design_icons_elm_ui$Ant$Icons$rollbackOutlined(
				_List_fromArray(
					[
						$lemol$ant_design_icons_elm_ui$Ant$Icon$width(70),
						$lemol$ant_design_icons_elm_ui$Ant$Icon$height(50)
					])),
			onPress: $elm$core$Maybe$Just($author$project$Messages$IsoReset)
		}));
var $author$project$Buttons$taskButton = function (status) {
	var theButton = A2(
		$mdgriffith$elm_ui$Element$Input$button,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$Border$rounded(100),
				$mdgriffith$elm_ui$Element$centerX
			]),
		{
			label: $lemol$ant_design_icons_elm_ui$Ant$Icons$forwardOutlined(
				_List_fromArray(
					[
						$lemol$ant_design_icons_elm_ui$Ant$Icon$width(40),
						$lemol$ant_design_icons_elm_ui$Ant$Icon$height(40)
					])),
			onPress: $elm$core$Maybe$Just($author$project$Messages$NextAnimation)
		});
	var text = status ? 'Previous Animation' : 'Next Task';
	return A2($author$project$Buttons$buttonWrap, text, theButton);
};
var $author$project$Isomorphism$gameButtons = function (displaySize) {
	return A2(
		$mdgriffith$elm_ui$Element$row,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$centerX,
				$mdgriffith$elm_ui$Element$spacing((displaySize.width / 10) | 0)
			]),
		_List_fromArray(
			[
				$author$project$Buttons$isoCheckButton,
				$author$project$Buttons$isoResetButton,
				$author$project$Buttons$taskButton(true)
			]));
};
var $author$project$Isomorphism$gameStatusExplanation = F2(
	function (game, displaySize) {
		var emph = $author$project$FontSize$emphForScreen(displaySize.deviceType);
		var makeAChoice = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n            Make a choice by \n            '),
				A2(emph, $author$project$FontSize$CuteBlue, '\n            clicking \n            '),
				$mdgriffith$elm_ui$Element$text('\n            on one of the boxed graphs and then\n            '),
				A2(emph, $author$project$FontSize$CuteBlue, '\n            press \n            '),
				$mdgriffith$elm_ui$Element$text('\n            the check button.\n            ')
			]);
		var youAreRight = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n               Yes it\'s \n               '),
				A2(emph, $author$project$FontSize$Pink, '\n               correct! \n               '),
				$mdgriffith$elm_ui$Element$text('\n               Well done.\n               ')
			]);
		var youAreWrong = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n            It\'s \n            '),
				A2(emph, $author$project$FontSize$Pink, '\n            incorrect! \n            '),
				$mdgriffith$elm_ui$Element$text('\n            Maybe, go back to the explanation.\n            ')
			]);
		var choiceMadeSecond = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n            You have \n            '),
				A2(emph, $author$project$FontSize$CuteBlue, '\n            chosen \n            '),
				$mdgriffith$elm_ui$Element$text('\n            the \n            '),
				A2(emph, $author$project$FontSize$CuteGreen, '\n            second \n            '),
				$mdgriffith$elm_ui$Element$text('\n            graph.\n            ')
			]);
		var choiceMadeFirst = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n               You have \n               '),
				A2(emph, $author$project$FontSize$CuteBlue, '\n               chosen \n               '),
				$mdgriffith$elm_ui$Element$text('\n               the \n               '),
				A2(emph, $author$project$FontSize$CuteGreen, '\n               first \n               '),
				$mdgriffith$elm_ui$Element$text('\n               graph.\n               ')
			]);
		var choiceText = function () {
			var _v5 = _Utils_Tuple2(game.choiceState, game.gameState);
			switch (_v5.a.$) {
				case 'NoChoice':
					var _v6 = _v5.a;
					return makeAChoice;
				case 'FirstGraph':
					var _v7 = _v5.a;
					return choiceMadeFirst;
				default:
					var _v8 = _v5.a;
					return choiceMadeSecond;
			}
		}();
		var checkText = function () {
			var _v0 = _Utils_Tuple2(game.choiceState, game.gameState);
			_v0$2:
			while (true) {
				if (_v0.b.$ === 'Check') {
					switch (_v0.a.$) {
						case 'FirstGraph':
							var _v1 = _v0.a;
							var _v2 = _v0.b;
							return youAreRight;
						case 'SecondGraph':
							var _v3 = _v0.a;
							var _v4 = _v0.b;
							return youAreWrong;
						default:
							break _v0$2;
					}
				} else {
					break _v0$2;
				}
			}
			return _List_fromArray(
				[$mdgriffith$elm_ui$Element$none]);
		}();
		return _List_fromArray(
			[choiceText, checkText]);
	});
var $author$project$Explanation$isomorphismExplanation = '\n   Two graphs G1 and G2 are isomorphic if there is a one-one correspondence\n   between the vertices of G1 and G2 such that the number of edges between any\n   two vertices in G1 is equal to the number of edges joining the corresponding\n   vertices of G2. \n   Although the graphs may appear to be different in appearance and in\n   the labeling of the nodes and edges. But the way one vertex is connected to\n   another in one graph is same as another. \n\n   The animation shown here takes a graph and changes the positions of the\n   vertices without changing the edges which still connect the same vertices\n   throughout the motion. In the animation if there is an edge between any two\n   vertices in a graph, then there is a edge between the corresponding vertices\n   in the other graphs as well.\n   ';
var $author$project$Isomorphism$explanationGame = F3(
	function (game, helpStatus, displaySize) {
		var emph = $author$project$FontSize$emphForScreen(displaySize.deviceType);
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Font$color(
					A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
					$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$spacing(20),
					$mdgriffith$elm_ui$Element$Background$color(
					A3($mdgriffith$elm_ui$Element$rgb, 0.2, 0.2, 0.2)),
					$mdgriffith$elm_ui$Element$width(
					A2($mdgriffith$elm_ui$Element$maximum, displaySize.width, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$scrollbarY
				]),
			_Utils_ap(
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Element$el,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$Font$size(
								A2($author$project$FontSize$getFontSize, $author$project$FontSize$Head, displaySize.deviceType)),
								$mdgriffith$elm_ui$Element$Font$heavy
							]),
						$mdgriffith$elm_ui$Element$text('Graph Isomorphism')),
						A2(
						$mdgriffith$elm_ui$Element$paragraph,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$spacing(8)
							]),
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$text($author$project$Explanation$isomorphismExplanation)
							])),
						A2(
						$mdgriffith$elm_ui$Element$paragraph,
						_List_Nil,
						_List_fromArray(
							[
								A2(emph, $author$project$FontSize$CuteBlue, '\n                     Choose \n                     '),
								$mdgriffith$elm_ui$Element$text('\n                     which graph is isomorphic to the first one\n                     by \n                     '),
								A2(emph, $author$project$FontSize$CuteBlue, '\n                     clicking \n                     '),
								$mdgriffith$elm_ui$Element$text('\n                     on them.\n                     ')
							])),
						$author$project$Isomorphism$gameButtons(displaySize)
					]),
				_Utils_ap(
					A2(
						$elm$core$List$map,
						$mdgriffith$elm_ui$Element$paragraph(_List_Nil),
						A2($author$project$Isomorphism$gameStatusExplanation, game, displaySize)),
					_List_fromArray(
						[
							A2($author$project$Buttons$lowerNavigation, 'Tree Width', 'Max Cut')
						]))));
	});
var $author$project$Buttons$IsomorphismHelp = {$: 'IsomorphismHelp'};
var $author$project$Graph$isVertexInEdges = F2(
	function (v, es) {
		isVertexInEdges:
		while (true) {
			if (!es.b) {
				return false;
			} else {
				var x = es.a;
				var xs = es.b;
				if (_Utils_eq(v.name, x.vertexOne.name) || _Utils_eq(v.name, x.vertexTwo.name)) {
					return true;
				} else {
					var $temp$v = v,
						$temp$es = xs;
					v = $temp$v;
					es = $temp$es;
					continue isVertexInEdges;
				}
			}
		}
	});
var $author$project$Graph$isVertexInList = F2(
	function (v, vs) {
		var _v0 = A2($author$project$Graph$lookUpVertex, v.name, vs);
		if (_v0.$ === 'Just') {
			return true;
		} else {
			return false;
		}
	});
var $author$project$Graph$getHaloVertices = F2(
	function (g, es) {
		var glowingVertices = A2(
			$elm$core$List$filter,
			function (ver) {
				return ver.glow;
			},
			g.vertices);
		return A2(
			$elm$core$List$filter,
			function (v) {
				return !A2($author$project$Graph$isVertexInList, v, glowingVertices);
			},
			A2(
				$elm$core$List$filter,
				function (v) {
					return A2($author$project$Graph$isVertexInEdges, v, es);
				},
				g.vertices));
	});
var $elm$regex$Regex$Match = F4(
	function (match, index, number, submatches) {
		return {index: index, match: match, number: number, submatches: submatches};
	});
var $elm$regex$Regex$fromStringWith = _Regex_fromStringWith;
var $elm$regex$Regex$fromString = function (string) {
	return A2(
		$elm$regex$Regex$fromStringWith,
		{caseInsensitive: false, multiline: false},
		string);
};
var $elm$regex$Regex$never = _Regex_never;
var $jorgengranseth$elm_string_format$String$Format$regex = A2(
	$elm$core$Basics$composeR,
	$elm$regex$Regex$fromString,
	$elm$core$Maybe$withDefault($elm$regex$Regex$never));
var $elm$regex$Regex$replaceAtMost = _Regex_replaceAtMost;
var $jorgengranseth$elm_string_format$String$Format$value = function (val) {
	var emptyBraces = $jorgengranseth$elm_string_format$String$Format$regex('{{\\s*}}');
	return A3(
		$elm$regex$Regex$replaceAtMost,
		1,
		emptyBraces,
		function (_v0) {
			return val;
		});
};
var $author$project$Isomorphism$makeStory = F3(
	function (deviceType, shapeTransition, helpStatus) {
		var whichYouCanSee = ' Which you can see is true for both graphs.';
		var putyourmouse = '\n            Go ahead and put your mouse over a vertex of the graph.\n            Or press a number on the keyboard corresponding to a Vertex number.\n            ';
		var glowing_vertices = A2(
			$elm$core$List$filter,
			function (ver) {
				return ver.glow;
			},
			shapeTransition.graphB.vertices);
		var footer = function () {
			if (!glowing_vertices.b) {
				return '';
			} else {
				var x = glowing_vertices.a;
				var xs = glowing_vertices.b;
				return '\n                  You may want to visit other vertices to see that, each vertex\n                  is connected to the same vertices in both graphs.\n                  Inspecting each vertices connectivity with other vertices, in both graphs you can \n                  convince your self that the graphs are isomorphic to each other.\n                  ';
			}
		}();
		var emph = $author$project$FontSize$emphForScreen(deviceType);
		var connectedToThis = function (v) {
			return A2(
				$jorgengranseth$elm_string_format$String$Format$value,
				$elm$core$String$fromInt(v.name),
				'And connected to vertex {{ }} are the vertices ');
		};
		var _v0 = $author$project$Graph$seperateEdges(shapeTransition.graphB);
		var specialEdges = _v0.a;
		var relatedVertices = A2($author$project$Graph$getHaloVertices, shapeTransition.graphB, specialEdges);
		var listOfStories = function () {
			if (!glowing_vertices.b) {
				return _List_fromArray(
					[$mdgriffith$elm_ui$Element$none]);
			} else {
				var x = glowing_vertices.a;
				var xs = glowing_vertices.b;
				return _List_fromArray(
					[
						$mdgriffith$elm_ui$Element$text('You have selected '),
						A2(emph, $author$project$FontSize$CuteGreen, 'Vertex '),
						A2(
						emph,
						$author$project$FontSize$Pink,
						$elm$core$String$fromInt(x.name)),
						$mdgriffith$elm_ui$Element$text('. Connected to this vertex are'),
						A2(emph, $author$project$FontSize$CuteGreen, ' Vertices '),
						A2(
						emph,
						$author$project$FontSize$Pink,
						$author$project$Graph$getStringFromVertices(relatedVertices)),
						$mdgriffith$elm_ui$Element$text('.'),
						$mdgriffith$elm_ui$Element$text(whichYouCanSee)
					]);
			}
		}();
		return (!helpStatus) ? _List_fromArray(
			[
				A2($mdgriffith$elm_ui$Element$paragraph, _List_Nil, listOfStories),
				A2(
				$mdgriffith$elm_ui$Element$paragraph,
				_List_Nil,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$text(footer)
					]))
			]) : _List_fromArray(
			[
				$author$project$Buttons$helpParagraph($author$project$Buttons$IsomorphismHelp)
			]);
	});
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$CaretRightOutlined$viewWithAttributes = function (attributes) {
	return A2(
		$elm$svg$Svg$svg,
		_Utils_ap(
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$viewBox('0 0 1024 1024')
				]),
			attributes),
		_List_fromArray(
			[
				A2(
				$elm$svg$Svg$path,
				_List_fromArray(
					[
						$elm$svg$Svg$Attributes$d('M715.8 493.5L335 165.1c-14.2-12.2-35-1.2-35 18.5v656.8c0 19.7 20.8 30.7 35 18.5l380.8-328.4c10.9-9.4 10.9-27.6 0-37z')
					]),
				_List_Nil)
			]));
};
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$caretRightOutlined = $lemol$ant_design_icons_elm$Ant$Icons$Svg$CaretRightOutlined$viewWithAttributes;
var $lemol$ant_design_icons_elm_ui$Ant$Icons$caretRightOutlined = function (attrs) {
	return A2($lemol$ant_design_icons_elm_ui$Ant$Icon$icon, attrs, $lemol$ant_design_icons_elm$Ant$Icons$Svg$caretRightOutlined);
};
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$PauseOutlined$viewWithAttributes = function (attributes) {
	return A2(
		$elm$svg$Svg$svg,
		_Utils_ap(
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$viewBox('64 64 896 896')
				]),
			attributes),
		_List_fromArray(
			[
				A2(
				$elm$svg$Svg$path,
				_List_fromArray(
					[
						$elm$svg$Svg$Attributes$d('M304 176h80v672h-80zm408 0h-64c-4.4 0-8 3.6-8 8v656c0 4.4 3.6 8 8 8h64c4.4 0 8-3.6 8-8V184c0-4.4-3.6-8-8-8z')
					]),
				_List_Nil)
			]));
};
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$pauseOutlined = $lemol$ant_design_icons_elm$Ant$Icons$Svg$PauseOutlined$viewWithAttributes;
var $lemol$ant_design_icons_elm_ui$Ant$Icons$pauseOutlined = function (attrs) {
	return A2($lemol$ant_design_icons_elm_ui$Ant$Icon$icon, attrs, $lemol$ant_design_icons_elm$Ant$Icons$Svg$pauseOutlined);
};
var $author$project$Buttons$playButton = function (animationOn) {
	var theButton = A2(
		$mdgriffith$elm_ui$Element$Input$button,
		_List_Nil,
		{
			label: animationOn ? $lemol$ant_design_icons_elm_ui$Ant$Icons$pauseOutlined(
				_List_fromArray(
					[
						$lemol$ant_design_icons_elm_ui$Ant$Icon$width(50),
						$lemol$ant_design_icons_elm_ui$Ant$Icon$height(50)
					])) : $lemol$ant_design_icons_elm_ui$Ant$Icons$caretRightOutlined(
				_List_fromArray(
					[
						$lemol$ant_design_icons_elm_ui$Ant$Icon$width(50),
						$lemol$ant_design_icons_elm_ui$Ant$Icon$height(50)
					])),
			onPress: $elm$core$Maybe$Just($author$project$Messages$AnimationToggle)
		});
	return A2($author$project$Buttons$buttonWrap, 'Play/Pause', theButton);
};
var $author$project$Buttons$resetButton = function () {
	var theButton = A2(
		$mdgriffith$elm_ui$Element$Input$button,
		_List_Nil,
		{
			label: $lemol$ant_design_icons_elm_ui$Ant$Icons$rollbackOutlined(
				_List_fromArray(
					[
						$lemol$ant_design_icons_elm_ui$Ant$Icon$width(50),
						$lemol$ant_design_icons_elm_ui$Ant$Icon$height(50)
					])),
			onPress: $elm$core$Maybe$Just($author$project$Messages$AnimationStartOver)
		});
	return A2($author$project$Buttons$buttonWrap, 'Restart', theButton);
}();
var $author$project$Isomorphism$mediaButtons = F2(
	function (shapeTransition, displaySize) {
		return A2(
			$mdgriffith$elm_ui$Element$row,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$centerX,
					$mdgriffith$elm_ui$Element$spacing((displaySize.width / 10) | 0)
				]),
			_List_fromArray(
				[
					$author$project$Buttons$playButton(shapeTransition.animationOn),
					$author$project$Buttons$resetButton,
					$author$project$Buttons$taskButton(false)
				]));
	});
var $author$project$Isomorphism$explanationTransition = F3(
	function (shapeTransition, helpStatus, displaySize) {
		var emph = $author$project$FontSize$emphForScreen(displaySize.deviceType);
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Font$color(
					A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
					$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$spacing(20),
					$mdgriffith$elm_ui$Element$Background$color(
					A3($mdgriffith$elm_ui$Element$rgb, 0.2, 0.2, 0.2)),
					$mdgriffith$elm_ui$Element$width(
					A2($mdgriffith$elm_ui$Element$maximum, displaySize.width, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$scrollbarY
				]),
			_Utils_ap(
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Element$el,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$Font$size(
								A2($author$project$FontSize$getFontSize, $author$project$FontSize$Head, displaySize.deviceType)),
								$mdgriffith$elm_ui$Element$Font$heavy
							]),
						$mdgriffith$elm_ui$Element$text('Graph Isomorphism')),
						A2(
						$mdgriffith$elm_ui$Element$paragraph,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$spacing(8)
							]),
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$text($author$project$Explanation$isomorphismExplanation)
							])),
						A2(
						$mdgriffith$elm_ui$Element$paragraph,
						_List_Nil,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$text('You should now press the '),
								A2(emph, $author$project$FontSize$CuteBlue, 'Play'),
								$mdgriffith$elm_ui$Element$text('\n                      button, to set the animation rolling.\n                     Press the \n                     '),
								A2(emph, $author$project$FontSize$CuteBlue, 'Restart '),
								$mdgriffith$elm_ui$Element$text('\n                     button to see it all over again.\n                     ')
							])),
						A2($author$project$Isomorphism$mediaButtons, shapeTransition, displaySize),
						A2(
						$mdgriffith$elm_ui$Element$paragraph,
						_List_Nil,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$text('\n                     Go ahead and put your mouse over a \n                     '),
								A2(emph, $author$project$FontSize$CuteGreen, 'vertex'),
								$mdgriffith$elm_ui$Element$text('\n                     of the graph. \n                     Or \n                     '),
								A2(emph, $author$project$FontSize$CuteBlue, 'press'),
								$mdgriffith$elm_ui$Element$text('\n                      a number on the keyboard corresponding to a Vertex number.\n                     ')
							]))
					]),
				_Utils_ap(
					A3($author$project$Isomorphism$makeStory, displaySize.deviceType, shapeTransition, helpStatus),
					_List_fromArray(
						[
							A2($author$project$Buttons$lowerNavigation, 'Tree Width', 'Max Cut')
						]))));
	});
var $author$project$Isomorphism$explanationOne = F3(
	function (isoTopic, helpStatus, displaySize) {
		var _v0 = isoTopic.topicState;
		if (_v0.$ === 'Transition') {
			return A3($author$project$Isomorphism$explanationTransition, isoTopic.shapeTransition, helpStatus, displaySize);
		} else {
			return A3($author$project$Isomorphism$explanationGame, isoTopic.isomorphicGame, helpStatus, displaySize);
		}
	});
var $author$project$Buttons$MaxCutHelp = {$: 'MaxCutHelp'};
var $author$project$MaxkCut$buttonWrap = F2(
	function (description, button) {
		var descriptionStyle = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$Font$color(
				A3($mdgriffith$elm_ui$Element$rgb, 0.5, 0.5, 0.5)),
				$mdgriffith$elm_ui$Element$Font$size(10),
				$mdgriffith$elm_ui$Element$centerX
			]);
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[$mdgriffith$elm_ui$Element$centerX]),
			_List_fromArray(
				[
					button,
					A2(
					$mdgriffith$elm_ui$Element$el,
					descriptionStyle,
					$mdgriffith$elm_ui$Element$text(description))
				]));
	});
var $author$project$Explanation$maxCutExplanation = '\n   A maximum cut, is partioning the vertices of a graph in two groups such that the number of edges between these two\n   groups is maximum.\n   ';
var $author$project$Buttons$forwardButton = function () {
	var theButton = A2(
		$mdgriffith$elm_ui$Element$Input$button,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$Border$rounded(100),
				$mdgriffith$elm_ui$Element$centerX
			]),
		{
			label: $lemol$ant_design_icons_elm_ui$Ant$Icons$forwardOutlined(
				_List_fromArray(
					[
						$lemol$ant_design_icons_elm_ui$Ant$Icon$width(40),
						$lemol$ant_design_icons_elm_ui$Ant$Icon$height(40)
					])),
			onPress: $elm$core$Maybe$Just($author$project$Messages$NextAnimation)
		});
	return A2($author$project$Buttons$buttonWrap, 'Next Animation', theButton);
}();
var $author$project$MaxkCut$mediaButtonsForMaxCut = F2(
	function (shapeTransition, displaySize) {
		return A2(
			$mdgriffith$elm_ui$Element$row,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$centerX,
					$mdgriffith$elm_ui$Element$spacing((displaySize.width / 10) | 0)
				]),
			_List_fromArray(
				[
					$author$project$Buttons$playButton(shapeTransition.animationOn),
					$author$project$Buttons$resetButton,
					$author$project$Buttons$forwardButton
				]));
	});
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$MinusOutlined$viewWithAttributes = function (attributes) {
	return A2(
		$elm$svg$Svg$svg,
		_Utils_ap(
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$viewBox('64 64 896 896')
				]),
			attributes),
		_List_fromArray(
			[
				A2(
				$elm$svg$Svg$path,
				_List_fromArray(
					[
						$elm$svg$Svg$Attributes$d('M872 474H152c-4.4 0-8 3.6-8 8v60c0 4.4 3.6 8 8 8h720c4.4 0 8-3.6 8-8v-60c0-4.4-3.6-8-8-8z')
					]),
				_List_Nil)
			]));
};
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$minusOutlined = $lemol$ant_design_icons_elm$Ant$Icons$Svg$MinusOutlined$viewWithAttributes;
var $lemol$ant_design_icons_elm_ui$Ant$Icons$minusOutlined = function (attrs) {
	return A2($lemol$ant_design_icons_elm_ui$Ant$Icon$icon, attrs, $lemol$ant_design_icons_elm$Ant$Icons$Svg$minusOutlined);
};
var $author$project$MaxkCut$explanationTwo = F3(
	function (maxCut, helpStatus, displaySize) {
		var state = maxCut.state;
		var shapeTransition = function () {
			var _v0 = maxCut.state;
			if (_v0.$ === 'TwoCut') {
				return maxCut.transitionA;
			} else {
				return maxCut.transitionB;
			}
		}();
		var emph = $author$project$FontSize$emphForScreen(displaySize.deviceType);
		var max2CutTitle = _List_fromArray(
			[
				A2(emph, $author$project$FontSize$CuteBlue, 'Max'),
				A2(emph, $author$project$FontSize$Pink, ' 2 '),
				A2(emph, $author$project$FontSize$CuteBlue, 'Cut')
			]);
		var max3CutTitle = _List_fromArray(
			[
				A2(emph, $author$project$FontSize$CuteBlue, 'Max'),
				A2(emph, $author$project$FontSize$Pink, ' 3 '),
				A2(emph, $author$project$FontSize$CuteBlue, 'Cut')
			]);
		var topicTitle = _Utils_eq(state, $author$project$MaxkCut$TwoCut) ? max2CutTitle : max3CutTitle;
		var threeCutExplanation = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n               In the \n               animation, the vertices are being segregated into \n               '),
				A2(emph, $author$project$FontSize$CuteGreen, '\n               three sets\n               '),
				$mdgriffith$elm_ui$Element$text('\n               , such that the number of edges \n               '),
				A2(emph, $author$project$FontSize$CuteGreen, 'passing'),
				$mdgriffith$elm_ui$Element$text('\n               from vertices in one\n               set to the vertices in all other sets is more than \n               '),
				A2(emph, $author$project$FontSize$Pink, 'any other way'),
				$mdgriffith$elm_ui$Element$text('\n               the vertices of the graph could have been segregated.  In other\n               words the problem of max 3 cut is to identify such partition of the\n               vertices of the graph that the above objective is satisfied.\n               ')
			]);
		var threeCutLineExplanation = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n               The three Max cut lines, seperates their respective sets from the\n               rest of the graph. The intersection between the cut lines and the\n               edges are shown as \n               '),
				A2(emph, $author$project$FontSize$CuteBlue, '\n               blue \n               '),
				$mdgriffith$elm_ui$Element$text('\n               dots. As you should verify, they are \n               '),
				A2(emph, $author$project$FontSize$Pink, '\n               18 \n               '),
				$mdgriffith$elm_ui$Element$text('\n               in\n               number for each set. This 3 cut is visually trivial as the graph\n               was tripartite.\n               ')
			]);
		var twoCutExplanation = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n               In the animation, the \n               '),
				A2(emph, $author$project$FontSize$CuteGreen, 'vertices'),
				$mdgriffith$elm_ui$Element$text(' are being '),
				A2(emph, $author$project$FontSize$CuteGreen, 'segregated'),
				$mdgriffith$elm_ui$Element$text('\n                  into two sets,\n                  such that the number of edges passing from vertices in one set to\n                  the vertices in another set is more than \n                  '),
				A2(emph, $author$project$FontSize$Pink, '\n                  any other way \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  the vertices\n                  of the graph could have been segregated.  In other words the\n                  problem of max cut is to \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  identify such partition \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  of the vertices of\n                  the graph that the above objective is satisfied.\n                  ')
			]);
		var twoCutLineExplanation = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n               The Max cut line, \n               seperates the two sets of vertices. The\n               intersection between the cut line and the edges are shown as \n               '),
				A2(emph, $author$project$FontSize$CuteBlue, '\n               blue\n               '),
				$mdgriffith$elm_ui$Element$text('\n               dots. As you should verify, they are \n               '),
				A2(emph, $author$project$FontSize$Pink, '\n               9 \n               '),
				$mdgriffith$elm_ui$Element$text('\n               in number. This number is\n               equal to number of edges from the set of vertices at the top going\n               to the vertices at the bottom.\n               ')
			]);
		var drawCutLineExplanation = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('For a clear cut seperation of the sets '),
				A2(emph, $author$project$FontSize$CuteBlue, 'Press'),
				$mdgriffith$elm_ui$Element$text(' the cut line below.')
			]);
		var buttonExplanation = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('Press the '),
				A2(emph, $author$project$FontSize$CuteBlue, 'Play '),
				$mdgriffith$elm_ui$Element$text('button to start the animation. '),
				$mdgriffith$elm_ui$Element$text('Press the '),
				A2(emph, $author$project$FontSize$CuteBlue, 'Restart '),
				$mdgriffith$elm_ui$Element$text('button to see it all over again.')
			]);
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Font$color(
					A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
					$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$spacing(20),
					$mdgriffith$elm_ui$Element$Background$color(
					A3($mdgriffith$elm_ui$Element$rgb, 0.2, 0.2, 0.2)),
					$mdgriffith$elm_ui$Element$width(
					A2($mdgriffith$elm_ui$Element$maximum, displaySize.width, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$scrollbarY
				]),
			_List_fromArray(
				[
					A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$Font$size(
							A2($author$project$FontSize$getFontSize, $author$project$FontSize$Head, displaySize.deviceType)),
							$mdgriffith$elm_ui$Element$Font$heavy
						]),
					$mdgriffith$elm_ui$Element$text('Max Cut')),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$spacing(8)
						]),
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$text($author$project$Explanation$maxCutExplanation)
						])),
					A2($mdgriffith$elm_ui$Element$paragraph, _List_Nil, buttonExplanation),
					A2($author$project$MaxkCut$mediaButtonsForMaxCut, shapeTransition, displaySize),
					A2($mdgriffith$elm_ui$Element$paragraph, _List_Nil, topicTitle),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_Nil,
					_Utils_eq(state, $author$project$MaxkCut$TwoCut) ? twoCutExplanation : threeCutExplanation),
					A2($mdgriffith$elm_ui$Element$paragraph, _List_Nil, drawCutLineExplanation),
					A2(
					$author$project$MaxkCut$buttonWrap,
					'Cutline',
					A2(
						$mdgriffith$elm_ui$Element$Input$button,
						_List_fromArray(
							[$mdgriffith$elm_ui$Element$centerX]),
						{
							label: $lemol$ant_design_icons_elm_ui$Ant$Icons$minusOutlined(
								_List_fromArray(
									[
										$lemol$ant_design_icons_elm_ui$Ant$Icon$width(70),
										$lemol$ant_design_icons_elm_ui$Ant$Icon$height(50)
									])),
							onPress: $elm$core$Maybe$Just($author$project$Messages$MaxCutLine)
						})),
					(!helpStatus) ? A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_Nil,
					_Utils_eq(shapeTransition.specialToken, $author$project$Graph$MakeKCut) ? (_Utils_eq(state, $author$project$MaxkCut$TwoCut) ? twoCutLineExplanation : threeCutLineExplanation) : _List_fromArray(
						[$mdgriffith$elm_ui$Element$none])) : $author$project$Buttons$helpParagraph($author$project$Buttons$MaxCutHelp),
					A2($author$project$Buttons$lowerNavigation, 'Isomporphism', 'Graph Coloring')
				]));
	});
var $author$project$FontSize$Gold = {$: 'Gold'};
var $author$project$Buttons$TreeWidthHelp = {$: 'TreeWidthHelp'};
var $author$project$TreeWidth$storyTreeWidth = F3(
	function (deviceType, status, helpStatus) {
		var piecesMarkedComment = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n                  Similarily all the other pieces are marked by blue dots\n                  representing the subgraphs they are situated inside.\n                  ')
			]);
		var para = function (l) {
			return A2(
				$mdgriffith$elm_ui$Element$paragraph,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$spacing(8)
					]),
				l);
		};
		var emph = $author$project$FontSize$emphForScreen(deviceType);
		var finalComment = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n                  The number of vertices in all the pieces is equal to 3. Therefore the maximum\n                  number of vertices in any piece in the present graph is also 3.\n                  Hence the \n                  '),
				A2(emph, $author$project$FontSize$Pink, '\n                  Possible\n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  tree width for corresponding tree decomposition is\n                  '),
				A2(emph, $author$project$FontSize$Pink, '\n                  3 \n                  '),
				A2(emph, $author$project$FontSize$CuteBlue, '\n                  - \n                  '),
				A2(emph, $author$project$FontSize$CuteGreen, '\n                  1 \n                  '),
				A2(emph, $author$project$FontSize$CuteBlue, '\n                  = \n                  '),
				A2(emph, $author$project$FontSize$Pink, '\n                  2\n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  .\n                  ')
			]);
		var finalJudgement = _List_fromArray(
			[
				A2(emph, $author$project$FontSize$CuteBlue, '\n                  Therefore, \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  the tree width of the graph, is the one corresponding to the\n                  '),
				A2(emph, $author$project$FontSize$CuteGreen, '\n                  first\n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  decomposition which has the maximum size of the piece equal to 3.\n                  As it has the \n                  '),
				A2(emph, $author$project$FontSize$Pink, '\n                  minimum \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  size of the \n                  '),
				A2(emph, $author$project$FontSize$CuteGreen, '\n                  biggest \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  piece accross all tree\n                  decompositions. So tree width of a graph can finally be\n                  defined in the following way:\n                  ')
			]);
		var firstComment = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n                  The graph on the left seems very \n                  '),
				A2(emph, $author$project$FontSize$CuteGreen, '\n                  un-tree \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  like. Lets \n                  '),
				A2(emph, $author$project$FontSize$CuteGreen, '\n                  morph \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  it to another \n                  '),
				A2(emph, $author$project$FontSize$CuteGreen, '\n                  shape. \n                  '),
				A2(emph, $author$project$FontSize$CuteBlue, '\n                  Press \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  forward button\n                  above to make it look a little different. \n                  ')
			]);
		var formulaFinal = _List_fromArray(
			[
				A2(emph, $author$project$FontSize$CuteGreen, '\n                  Tree Width \n                  '),
				A2(emph, $author$project$FontSize$CuteBlue, '\n                  = \n                  '),
				A2(emph, $author$project$FontSize$Pink, '\n                  S\n                  '),
				A2(emph, $author$project$FontSize$CuteBlue, '\n                  - \n                  '),
				A2(emph, $author$project$FontSize$CuteGreen, '\n                  1\n                  ')
			]);
		var honeyCombFirstComment = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n                  The circular graph is now transformed to a \n                  '),
				A2(emph, $author$project$FontSize$CuteGreen, '\n                  cellular\n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  structure. Which is visually more like a \n                  '),
				A2(emph, $author$project$FontSize$CuteGreen, '\n                  tree-like \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  structure.\n                  ')
			]);
		var letSBe = _List_fromArray(
			[
				A2(emph, $author$project$FontSize$CuteBlue, 'Let'),
				A2(emph, $author$project$FontSize$Pink, ' S '),
				$mdgriffith$elm_ui$Element$text('be the smallest of the biggest piece accross all the tree decompositions'),
				A2(emph, $author$project$FontSize$CuteBlue, ' in: ')
			]);
		var secondComment = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n                  Which is now \n                  '),
				A2(emph, $author$project$FontSize$CuteBlue, '\n                  transforming \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  into a new graph, which is more\n                  tree-like \n                  '),
				A2(emph, $author$project$FontSize$CuteBlue, '\n                  visually.\n                  ')
			]);
		var showOnePieceComment = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n                  The graph can now be divided into \n                  '),
				A2(emph, $author$project$FontSize$CuteGreen, '\n                  pieces. \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  The first piece for example\n                  is the \n                  '),
				A2(emph, $author$project$FontSize$CuteGreen, '\n                  sub graph \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  made up by Vertices \n                  '),
				A2(emph, $author$project$FontSize$Pink, '\n                  1, 2  \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  and \n                  '),
				A2(emph, $author$project$FontSize$Pink, '\n                  3\n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  . This is marked by\n                  golden vertices and edges. To make life easier in further\n                  explanations, a piece will be represented by a \n                  '),
				A2(emph, $author$project$FontSize$CuteBlue, '\n                  blue \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  dot present at the\n                  center of the subgraph.\n                  ')
			]);
		var theoreticalComments = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n                  The division of the graph in pieces such as these such that\n                  the pieces together form a tree is called \n                  '),
				A2(emph, $author$project$FontSize$CuteGreen, '\n                  tree decomposition \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  of a\n                  graph. The pieces hence formed have associated a number of\n                  vertices. Here all the pieces have \n                  '),
				A2(emph, $author$project$FontSize$Pink, '\n                  3 \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  vertices associated\n                  with them.\n                  ')
			]);
		var treeDetails = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n                  The \n                  golden \n                  lines \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  joining the \n                  '),
				A2(emph, $author$project$FontSize$CuteGreen, '\n                  pieces \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  form a \n                  '),
				A2(emph, $author$project$FontSize$Gold, '\n                  tree \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  as this structure \n                  '),
				A2(emph, $author$project$FontSize$Pink, '\n                  no\n                  cycles.\n                  ')
			]);
		var treeWidthDef = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n                  Tree width of the graph is related to the maximum number of vertices\n                  associated with a piece for a \n                  '),
				A2(emph, $author$project$FontSize$Pink, '\n                  particular \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  decomposition is given by the formula:\n                  ')
			]);
		var treeWidthDefNew = _List_fromArray(
			[
				A2(emph, $author$project$FontSize$CuteBlue, '\n                  Tree Width,\n                  '),
				$mdgriffith$elm_ui$Element$text('\n                   should be derived from such a tree decomposition\n                  whose biggest piece is of the minimum size across all decompositions.\n                  ')
			]);
		var treeWidthFormula = _List_fromArray(
			[
				A2(emph, $author$project$FontSize$CuteGreen, '\n                  Possibe Tree Width \n                  '),
				A2(emph, $author$project$FontSize$CuteBlue, '\n                  = \n                  '),
				A2(emph, $author$project$FontSize$Pink, '\n                  ( Maximum Number of Vertices in a piece ) \n                  '),
				A2(emph, $author$project$FontSize$CuteBlue, '\n                  - \n                  '),
				A2(emph, $author$project$FontSize$CuteGreen, '\n                  1\n                  ')
			]);
		var concludingComment = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n                  Hence, the tree width of the present graph =\n                  '),
				A2(emph, $author$project$FontSize$CuteGreen, '3 '),
				A2(emph, $author$project$FontSize$CuteBlue, '-'),
				A2(emph, $author$project$FontSize$CuteGreen, ' 1 '),
				A2(emph, $author$project$FontSize$CuteBlue, '='),
				A2(emph, $author$project$FontSize$CuteGreen, ' 2 '),
				$mdgriffith$elm_ui$Element$text('.')
			]);
		var bigPieceExplanation = _List_fromArray(
			[
				A2(emph, $author$project$FontSize$Pink, '\n                  However,\n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  if the decomposition of a graph was done\n                  by deriving \n                  '),
				A2(emph, $author$project$FontSize$CuteGreen, '\n                  bigger \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  pieces like the one shown in\n                  the figure, then the \n                  '),
				A2(emph, $author$project$FontSize$Pink, '\n                  candidate \n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  tree-width would\n                  have been equal to \n                  '),
				A2(emph, $author$project$FontSize$Pink, '\n                  4 \n                  '),
				A2(emph, $author$project$FontSize$CuteBlue, '\n                  - \n                  '),
				A2(emph, $author$project$FontSize$Pink, '\n                  1 \n                  '),
				A2(emph, $author$project$FontSize$CuteBlue, '\n                  = \n                  '),
				A2(emph, $author$project$FontSize$Pink, '\n                  3\n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  .\n                  ')
			]);
		var altTreeExplanation = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n                  Therefore, a tree can be decomposed\n                  in \n                  '),
				A2(emph, $author$project$FontSize$CuteBlue, '\n                  many ways\n                  '),
				$mdgriffith$elm_ui$Element$text('\n                  It can even be decomposed by keeping the\n                  whole graph in a single piece. For the graph shown\n                  in the figure the candidate tree\n                  width in that case would be equal to 12 - 1 = 11.\n                  ')
			]);
		var output = function () {
			switch (status.$) {
				case 'CircularGraph':
					return _List_fromArray(
						[firstComment]);
				case 'MorphingIntoHoneyComb':
					return _List_fromArray(
						[firstComment, secondComment]);
				case 'HoneyCombGraph':
					return _List_fromArray(
						[honeyCombFirstComment]);
				case 'ShowOnePiece':
					return _List_fromArray(
						[honeyCombFirstComment, showOnePieceComment]);
				case 'PiecesMarked':
					return _List_fromArray(
						[showOnePieceComment, piecesMarkedComment]);
				case 'TreeDrawnGraph':
					return _List_fromArray(
						[treeDetails, theoreticalComments, treeWidthDef, treeWidthFormula, finalComment]);
				case 'ShowLargePiece':
					return _List_fromArray(
						[bigPieceExplanation]);
				case 'AltTree':
					return _List_fromArray(
						[bigPieceExplanation, altTreeExplanation, treeWidthDefNew, finalJudgement]);
				default:
					return _List_fromArray(
						[finalJudgement, letSBe, formulaFinal, concludingComment]);
			}
		}();
		var acrossDecompositions = _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text('\n                  There can be multiple tree decompositions, for which the number of pieces in the\n                  larges piece is greater than 3.\n                  ')
			]);
		return (!helpStatus) ? A2($elm$core$List$map, para, output) : _List_fromArray(
			[
				$author$project$Buttons$helpParagraph($author$project$Buttons$TreeWidthHelp)
			]);
	});
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$BackwardOutlined$viewWithAttributes = function (attributes) {
	return A2(
		$elm$svg$Svg$svg,
		_Utils_ap(
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$viewBox('0 0 1024 1024')
				]),
			attributes),
		_List_fromArray(
			[
				A2(
				$elm$svg$Svg$path,
				_List_fromArray(
					[
						$elm$svg$Svg$Attributes$d('M485.6 249.9L198.2 498c-8.3 7.1-8.3 20.8 0 27.9l287.4 248.2c10.7 9.2 26.4.9 26.4-14V263.8c0-14.8-15.7-23.2-26.4-13.9zm320 0L518.2 498a18.6 18.6 0 00-6.2 14c0 5.2 2.1 10.4 6.2 14l287.4 248.2c10.7 9.2 26.4.9 26.4-14V263.8c0-14.8-15.7-23.2-26.4-13.9z')
					]),
				_List_Nil)
			]));
};
var $lemol$ant_design_icons_elm$Ant$Icons$Svg$backwardOutlined = $lemol$ant_design_icons_elm$Ant$Icons$Svg$BackwardOutlined$viewWithAttributes;
var $lemol$ant_design_icons_elm_ui$Ant$Icons$backwardOutlined = function (attrs) {
	return A2($lemol$ant_design_icons_elm_ui$Ant$Icon$icon, attrs, $lemol$ant_design_icons_elm$Ant$Icons$Svg$backwardOutlined);
};
var $author$project$Buttons$treeWidthButtonRow = F2(
	function (isPreviousActive, displaySize) {
		var forward = A2(
			$author$project$Buttons$buttonWrap,
			'Next animation',
			A2(
				$mdgriffith$elm_ui$Element$Input$button,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$Border$rounded(100),
						$mdgriffith$elm_ui$Element$centerX
					]),
				{
					label: $lemol$ant_design_icons_elm_ui$Ant$Icons$forwardOutlined(
						_List_fromArray(
							[
								$lemol$ant_design_icons_elm_ui$Ant$Icon$width(40),
								$lemol$ant_design_icons_elm_ui$Ant$Icon$height(40)
							])),
					onPress: $elm$core$Maybe$Just($author$project$Messages$NextAnimation)
				}));
		var backwardDead = A2(
			$author$project$Buttons$buttonWrap,
			'Previous animation',
			A2(
				$mdgriffith$elm_ui$Element$Input$button,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$Border$rounded(100),
						$mdgriffith$elm_ui$Element$centerX,
						$mdgriffith$elm_ui$Element$Font$color(
						A3($mdgriffith$elm_ui$Element$rgb, 0.4, 0.4, 0.4))
					]),
				{
					label: $lemol$ant_design_icons_elm_ui$Ant$Icons$backwardOutlined(
						_List_fromArray(
							[
								$lemol$ant_design_icons_elm_ui$Ant$Icon$width(40),
								$lemol$ant_design_icons_elm_ui$Ant$Icon$height(40)
							])),
					onPress: $elm$core$Maybe$Nothing
				}));
		var backward = A2(
			$author$project$Buttons$buttonWrap,
			'Previous animation',
			A2(
				$mdgriffith$elm_ui$Element$Input$button,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$Border$rounded(100),
						$mdgriffith$elm_ui$Element$centerX
					]),
				{
					label: $lemol$ant_design_icons_elm_ui$Ant$Icons$backwardOutlined(
						_List_fromArray(
							[
								$lemol$ant_design_icons_elm_ui$Ant$Icon$width(40),
								$lemol$ant_design_icons_elm_ui$Ant$Icon$height(40)
							])),
					onPress: $elm$core$Maybe$Just($author$project$Messages$PreviousTreeWidthAnimation)
				}));
		return A2(
			$mdgriffith$elm_ui$Element$row,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$centerX,
					$mdgriffith$elm_ui$Element$spacing((displaySize.width / 10) | 0)
				]),
			_List_fromArray(
				[
					isPreviousActive ? backward : backwardDead,
					forward
				]));
	});
var $author$project$TreeWidth$treeWidthButtons = F2(
	function (status, displaySize) {
		if (status.$ === 'CircularGraph') {
			return A2($author$project$Buttons$treeWidthButtonRow, false, displaySize);
		} else {
			return A2($author$project$Buttons$treeWidthButtonRow, true, displaySize);
		}
	});
var $author$project$Explanation$treeWidthExplanation = '\n   Tree width can be seen a measure of tree-ness of a graph. It shows how well\n   a graph can be interpreted as a tree. This demonstration is broken into two parts.\n   The first part explains the concept of graph decomposition. The second part will\n   build upon the first to explain the definition of tree width more pricisely.\n   ';
var $author$project$TreeWidth$explanationWidth = F3(
	function (display, helpStatus, displaySize) {
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Font$color(
					A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
					$mdgriffith$elm_ui$Element$spacing(20),
					$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$width(
					A2($mdgriffith$elm_ui$Element$maximum, displaySize.width, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$Background$color(
					A3($mdgriffith$elm_ui$Element$rgb, 0.2, 0.2, 0.2)),
					$mdgriffith$elm_ui$Element$scrollbarY
				]),
			_Utils_ap(
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Element$el,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$Font$size(
								A2($author$project$FontSize$getFontSize, $author$project$FontSize$Head, displaySize.deviceType)),
								$mdgriffith$elm_ui$Element$Font$heavy
							]),
						$mdgriffith$elm_ui$Element$text('Tree Width')),
						A2(
						$mdgriffith$elm_ui$Element$paragraph,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$spacing(8)
							]),
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$text($author$project$Explanation$treeWidthExplanation)
							])),
						A2(
						$mdgriffith$elm_ui$Element$paragraph,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$spacing(8)
							]),
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$text('\n                  Keep pressing the forward and backward buttons to navigate\n                  through this demonstration.\n                  ')
							])),
						A2($author$project$TreeWidth$treeWidthButtons, display.status, displaySize)
					]),
				_Utils_ap(
					A3($author$project$TreeWidth$storyTreeWidth, displaySize.deviceType, display.status, helpStatus),
					_List_fromArray(
						[
							A2($author$project$Buttons$lowerNavigation, 'Vertex Cover', 'Isomorphism')
						]))));
	});
var $author$project$Messages$GotoColoring = {$: 'GotoColoring'};
var $author$project$Messages$GotoCover = {$: 'GotoCover'};
var $author$project$Messages$GotoIsomorphism = {$: 'GotoIsomorphism'};
var $author$project$Messages$GotoMaxkCut = {$: 'GotoMaxkCut'};
var $author$project$Messages$GotoTreeWidth = {$: 'GotoTreeWidth'};
var $author$project$Main$displayMiniGraph = function (svgHtml) {
	return A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$Font$color(
				A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
				$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$Background$color(
				A3($mdgriffith$elm_ui$Element$rgb, 0.2, 0.2, 0.2))
			]),
		$mdgriffith$elm_ui$Element$html(svgHtml));
};
var $author$project$Graph$displaySvg = function (elements) {
	return A2(
		$elm$svg$Svg$svg,
		_List_fromArray(
			[
				$elm$svg$Svg$Attributes$viewBox('0 0 400 400')
			]),
		elements);
};
var $elm_explorations$linear_algebra$Math$Vector3$getX = _MJS_v3getX;
var $elm_explorations$linear_algebra$Math$Vector3$getY = _MJS_v3getY;
var $elm$svg$Svg$line = $elm$svg$Svg$trustedNode('line');
var $elm$svg$Svg$Attributes$stroke = _VirtualDom_attribute('stroke');
var $elm$svg$Svg$Attributes$x1 = _VirtualDom_attribute('x1');
var $elm$svg$Svg$Attributes$x2 = _VirtualDom_attribute('x2');
var $elm$svg$Svg$Attributes$y1 = _VirtualDom_attribute('y1');
var $elm$svg$Svg$Attributes$y2 = _VirtualDom_attribute('y2');
var $author$project$Graph$line = F2(
	function (veca, vecb) {
		return A2(
			$elm$svg$Svg$line,
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$x1(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getX(veca)))),
					$elm$svg$Svg$Attributes$y1(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getY(veca)))),
					$elm$svg$Svg$Attributes$x2(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getX(vecb)))),
					$elm$svg$Svg$Attributes$y2(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getY(vecb)))),
					$elm$svg$Svg$Attributes$stroke('white')
				]),
			_List_Nil);
	});
var $author$project$Graph$drawEdge = function (e) {
	return A2($author$project$Graph$line, e.vertexOne.pos, e.vertexTwo.pos);
};
var $author$project$Messages$HoverOver = function (a) {
	return {$: 'HoverOver', a: a};
};
var $author$project$Messages$MouseOut = function (a) {
	return {$: 'MouseOut', a: a};
};
var $elm$svg$Svg$circle = $elm$svg$Svg$trustedNode('circle');
var $elm$svg$Svg$Attributes$cx = _VirtualDom_attribute('cx');
var $elm$svg$Svg$Attributes$cy = _VirtualDom_attribute('cy');
var $elm$svg$Svg$Events$onClick = function (msg) {
	return A2(
		$elm$html$Html$Events$on,
		'click',
		$elm$json$Json$Decode$succeed(msg));
};
var $elm$svg$Svg$Events$onMouseOut = function (msg) {
	return A2(
		$elm$html$Html$Events$on,
		'mouseout',
		$elm$json$Json$Decode$succeed(msg));
};
var $elm$svg$Svg$Events$onMouseOver = function (msg) {
	return A2(
		$elm$html$Html$Events$on,
		'mouseover',
		$elm$json$Json$Decode$succeed(msg));
};
var $elm$svg$Svg$Attributes$r = _VirtualDom_attribute('r');
var $elm$svg$Svg$Attributes$style = _VirtualDom_attribute('style');
var $author$project$Graph$ccircle = F4(
	function (size, pos, color, name) {
		return A2(
			$elm$svg$Svg$circle,
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$cx(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getX(pos)))),
					$elm$svg$Svg$Attributes$cy(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getY(pos)))),
					$elm$svg$Svg$Attributes$r(
					$elm$core$String$fromInt(size)),
					$elm$svg$Svg$Attributes$style('fill: ' + (color + ';')),
					$elm$svg$Svg$Events$onMouseOver(
					$author$project$Messages$HoverOver(name)),
					$elm$svg$Svg$Events$onMouseOut(
					$author$project$Messages$MouseOut(name)),
					$elm$svg$Svg$Events$onClick(
					$author$project$Messages$ToggleVertexStatus(name))
				]),
			_List_Nil);
	});
var $author$project$Graph$drawGoldenCircle = function (v) {
	return A4($author$project$Graph$ccircle, 15, v.pos, '#BF8915', v.name);
};
var $author$project$Graph$drawSelectedVertex = function (v) {
	return A4($author$project$Graph$ccircle, 13, v.pos, '#BF8915', v.name);
};
var $elm$svg$Svg$Attributes$strokeWidth = _VirtualDom_attribute('stroke-width');
var $author$project$Graph$lline = F2(
	function (veca, vecb) {
		return A2(
			$elm$svg$Svg$line,
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$x1(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getX(veca)))),
					$elm$svg$Svg$Attributes$y1(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getY(veca)))),
					$elm$svg$Svg$Attributes$x2(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getX(vecb)))),
					$elm$svg$Svg$Attributes$y2(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getY(vecb)))),
					$elm$svg$Svg$Attributes$stroke('#BF8915'),
					$elm$svg$Svg$Attributes$strokeWidth('3')
				]),
			_List_Nil);
	});
var $author$project$Graph$drawSpecialEdge = function (e) {
	return A2($author$project$Graph$lline, e.vertexOne.pos, e.vertexTwo.pos);
};
var $author$project$Messages$VertexClicked = function (a) {
	return {$: 'VertexClicked', a: a};
};
var $avh4$elm_color$Color$toCssString = function (_v0) {
	var r = _v0.a;
	var g = _v0.b;
	var b = _v0.c;
	var a = _v0.d;
	var roundTo = function (x) {
		return $elm$core$Basics$round(x * 1000) / 1000;
	};
	var pct = function (x) {
		return $elm$core$Basics$round(x * 10000) / 100;
	};
	return $elm$core$String$concat(
		_List_fromArray(
			[
				'rgba(',
				$elm$core$String$fromFloat(
				pct(r)),
				'%,',
				$elm$core$String$fromFloat(
				pct(g)),
				'%,',
				$elm$core$String$fromFloat(
				pct(b)),
				'%,',
				$elm$core$String$fromFloat(
				roundTo(a)),
				')'
			]));
};
var $author$project$Graph$circle = F4(
	function (size, pos, color, name) {
		return A2(
			$elm$svg$Svg$circle,
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$cx(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getX(pos)))),
					$elm$svg$Svg$Attributes$cy(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getY(pos)))),
					$elm$svg$Svg$Attributes$r(
					$elm$core$String$fromInt(size)),
					$elm$svg$Svg$Attributes$style(
					'fill: ' + ($avh4$elm_color$Color$toCssString(color) + ';')),
					$elm$svg$Svg$Events$onMouseOver(
					$author$project$Messages$HoverOver(name)),
					$elm$svg$Svg$Events$onMouseOut(
					$author$project$Messages$MouseOut(name)),
					$elm$svg$Svg$Events$onClick(
					$author$project$Messages$VertexClicked(name))
				]),
			_List_Nil);
	});
var $author$project$Graph$drawVertex = function (v) {
	return A4($author$project$Graph$circle, 10, v.pos, v.color, v.name);
};
var $elm$svg$Svg$Attributes$class = _VirtualDom_attribute('class');
var $elm$svg$Svg$Attributes$fontSize = _VirtualDom_attribute('font-size');
var $elm$svg$Svg$text = $elm$virtual_dom$VirtualDom$text;
var $elm$svg$Svg$Attributes$textAnchor = _VirtualDom_attribute('text-anchor');
var $elm$svg$Svg$text_ = $elm$svg$Svg$trustedNode('text');
var $elm$svg$Svg$Attributes$x = _VirtualDom_attribute('x');
var $elm$svg$Svg$Attributes$y = _VirtualDom_attribute('y');
var $author$project$Graph$writeName = F2(
	function (name, pos) {
		return A2(
			$elm$svg$Svg$text_,
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$x(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getX(pos)))),
					$elm$svg$Svg$Attributes$y(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getY(pos)))),
					$elm$svg$Svg$Attributes$class('small'),
					$elm$svg$Svg$Attributes$fontSize('7px'),
					$elm$svg$Svg$Attributes$textAnchor('middle'),
					$elm$svg$Svg$Events$onClick(
					$author$project$Messages$VertexClicked(name))
				]),
			_List_fromArray(
				[
					$elm$svg$Svg$text(
					$elm$core$String$fromInt(name))
				]));
	});
var $author$project$Graph$writeVertexName = function (v) {
	return A2($author$project$Graph$writeName, v.name, v.pos);
};
var $author$project$Graph$drawGraph = function (g) {
	var selectedVertices = A2(
		$elm$core$List$filter,
		function (ver) {
			return ver.glow;
		},
		g.vertices);
	var _v0 = $author$project$Graph$seperateEdges(g);
	var specialEdges = _v0.a;
	var normalEdges = _v0.b;
	var haloVertices = A2($author$project$Graph$getHaloVertices, g, specialEdges);
	return _Utils_ap(
		A2($elm$core$List$map, $author$project$Graph$drawEdge, normalEdges),
		_Utils_ap(
			A2($elm$core$List$map, $author$project$Graph$drawSpecialEdge, specialEdges),
			_Utils_ap(
				A2($elm$core$List$map, $author$project$Graph$drawGoldenCircle, haloVertices),
				_Utils_ap(
					A2($elm$core$List$map, $author$project$Graph$drawVertex, g.vertices),
					_Utils_ap(
						A2($elm$core$List$map, $author$project$Graph$drawSelectedVertex, selectedVertices),
						A2($elm$core$List$map, $author$project$Graph$writeVertexName, g.vertices))))));
};
var $author$project$GraphColoring$miniColGraph = $author$project$Graph$displaySvg(
	$author$project$Graph$drawGraph(
		A4(
			$author$project$Graph$makeGraph,
			$author$project$Graph$PolygonCycleDoll(5),
			A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 200, 100, 0),
			A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 80, 80, 0),
			$elm$core$Basics$pi / 4)));
var $author$project$Isomorphism$drawGraph = function (g) {
	var selectedVertices = A2(
		$elm$core$List$filter,
		function (ver) {
			return ver.glow;
		},
		g.vertices);
	var _v0 = $author$project$Graph$seperateEdges(g);
	var specialEdges = _v0.a;
	var normalEdges = _v0.b;
	var haloVertices = A2($author$project$Graph$getHaloVertices, g, specialEdges);
	return _Utils_ap(
		A2($elm$core$List$map, $author$project$Graph$drawEdge, normalEdges),
		_Utils_ap(
			A2($elm$core$List$map, $author$project$Graph$drawSpecialEdge, specialEdges),
			_Utils_ap(
				A2($elm$core$List$map, $author$project$Graph$drawGoldenCircle, haloVertices),
				_Utils_ap(
					A2($elm$core$List$map, $author$project$Graph$drawVertex, g.vertices),
					_Utils_ap(
						A2($elm$core$List$map, $author$project$Graph$drawSelectedVertex, selectedVertices),
						A2($elm$core$List$map, $author$project$Graph$writeVertexName, g.vertices))))));
};
var $author$project$Isomorphism$miniIsoGraph = $author$project$Graph$displaySvg(
	$author$project$Isomorphism$drawGraph(
		A4(
			$author$project$Graph$makeGraph,
			$author$project$Graph$PolygonCycleDoll(4),
			A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 200, 100, 0),
			A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 80, 80, 0),
			$elm$core$Basics$pi / 4)));
var $author$project$MaxkCut$miniMaxGraph = function () {
	var _v0 = $author$project$MaxkCut$threeCutGeometry;
	var graph = _v0.a;
	return $author$project$Graph$displaySvg(
		$author$project$Graph$drawGraph(graph));
}();
var $author$project$TreeWidth$miniTreeWidth = function () {
	var grid = $author$project$TreeWidth$treeWidthDisplay.gridHoneyComb;
	var graph = $author$project$TreeWidth$treeWidthDisplay.graph;
	return $author$project$Graph$displaySvg(
		$author$project$Graph$drawGraph(
			A2($author$project$Graph$morphGraph, graph, grid)));
}();
var $mdgriffith$elm_ui$Internal$Flag$borderStyle = $mdgriffith$elm_ui$Internal$Flag$flag(11);
var $mdgriffith$elm_ui$Element$Border$solid = A2($mdgriffith$elm_ui$Internal$Model$Class, $mdgriffith$elm_ui$Internal$Flag$borderStyle, $mdgriffith$elm_ui$Internal$Style$classes.borderSolid);
var $mdgriffith$elm_ui$Internal$Model$BorderWidth = F5(
	function (a, b, c, d, e) {
		return {$: 'BorderWidth', a: a, b: b, c: c, d: d, e: e};
	});
var $mdgriffith$elm_ui$Element$Border$width = function (v) {
	return A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$borderWidth,
		A5(
			$mdgriffith$elm_ui$Internal$Model$BorderWidth,
			'b-' + $elm$core$String$fromInt(v),
			v,
			v,
			v,
			v));
};
var $author$project$Main$makeTopicIcon = F2(
	function (displaySize, topicMsg) {
		var tex = function () {
			switch (topicMsg.$) {
				case 'GotoIsomorphism':
					return 'Graph Isomorphism.';
				case 'GotoMaxkCut':
					return 'Max k Cut.';
				case 'GotoColoring':
					return 'Graph Coloring.';
				case 'GotoCover':
					return 'Vertex Cover.';
				case 'GotoTreeWidth':
					return 'Tree Width.';
				default:
					return 'Oops';
			}
		}();
		var miniGraph = function () {
			switch (topicMsg.$) {
				case 'GotoIsomorphism':
					return $author$project$Isomorphism$miniIsoGraph;
				case 'GotoMaxkCut':
					return $author$project$MaxkCut$miniMaxGraph;
				case 'GotoColoring':
					return $author$project$GraphColoring$miniColGraph;
				case 'GotoCover':
					return $author$project$Isomorphism$miniIsoGraph;
				case 'GotoTreeWidth':
					return $author$project$TreeWidth$miniTreeWidth;
				default:
					return $author$project$Isomorphism$miniIsoGraph;
			}
		}();
		var dimension = A2($elm$core$Basics$min, displaySize.height, displaySize.width);
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Events$onClick(topicMsg),
					$mdgriffith$elm_ui$Element$pointer,
					A2($mdgriffith$elm_ui$Element$paddingXY, 13, 15),
					$mdgriffith$elm_ui$Element$Border$solid,
					$mdgriffith$elm_ui$Element$Border$width(2),
					$mdgriffith$elm_ui$Element$Border$rounded(15),
					$mdgriffith$elm_ui$Element$width(
					A2($mdgriffith$elm_ui$Element$minimum, (dimension / 4) | 0, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$height(
					A2($mdgriffith$elm_ui$Element$minimum, (dimension / 4) | 0, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$clip
				]),
			_List_fromArray(
				[
					$author$project$Main$displayMiniGraph(miniGraph),
					A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[$mdgriffith$elm_ui$Element$centerX]),
					$mdgriffith$elm_ui$Element$text(tex))
				]));
	});
var $mdgriffith$elm_ui$Element$scrollbarX = A2($mdgriffith$elm_ui$Internal$Model$Class, $mdgriffith$elm_ui$Internal$Flag$overflow, $mdgriffith$elm_ui$Internal$Style$classes.scrollbarsX);
var $mdgriffith$elm_ui$Internal$Model$Padding = F5(
	function (a, b, c, d, e) {
		return {$: 'Padding', a: a, b: b, c: c, d: d, e: e};
	});
var $mdgriffith$elm_ui$Internal$Model$Spaced = F3(
	function (a, b, c) {
		return {$: 'Spaced', a: a, b: b, c: c};
	});
var $mdgriffith$elm_ui$Internal$Model$extractSpacingAndPadding = function (attrs) {
	return A3(
		$elm$core$List$foldr,
		F2(
			function (attr, _v0) {
				var pad = _v0.a;
				var spacing = _v0.b;
				return _Utils_Tuple2(
					function () {
						if (pad.$ === 'Just') {
							var x = pad.a;
							return pad;
						} else {
							if ((attr.$ === 'StyleClass') && (attr.b.$ === 'PaddingStyle')) {
								var _v3 = attr.b;
								var name = _v3.a;
								var t = _v3.b;
								var r = _v3.c;
								var b = _v3.d;
								var l = _v3.e;
								return $elm$core$Maybe$Just(
									A5($mdgriffith$elm_ui$Internal$Model$Padding, name, t, r, b, l));
							} else {
								return $elm$core$Maybe$Nothing;
							}
						}
					}(),
					function () {
						if (spacing.$ === 'Just') {
							var x = spacing.a;
							return spacing;
						} else {
							if ((attr.$ === 'StyleClass') && (attr.b.$ === 'SpacingStyle')) {
								var _v6 = attr.b;
								var name = _v6.a;
								var x = _v6.b;
								var y = _v6.c;
								return $elm$core$Maybe$Just(
									A3($mdgriffith$elm_ui$Internal$Model$Spaced, name, x, y));
							} else {
								return $elm$core$Maybe$Nothing;
							}
						}
					}());
			}),
		_Utils_Tuple2($elm$core$Maybe$Nothing, $elm$core$Maybe$Nothing),
		attrs);
};
var $mdgriffith$elm_ui$Internal$Model$paddingNameFloat = F4(
	function (top, right, bottom, left) {
		return 'pad-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(top) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(right) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(bottom) + ('-' + $mdgriffith$elm_ui$Internal$Model$floatClass(left)))))));
	});
var $mdgriffith$elm_ui$Element$wrappedRow = F2(
	function (attrs, children) {
		var _v0 = $mdgriffith$elm_ui$Internal$Model$extractSpacingAndPadding(attrs);
		var padded = _v0.a;
		var spaced = _v0.b;
		if (spaced.$ === 'Nothing') {
			return A4(
				$mdgriffith$elm_ui$Internal$Model$element,
				$mdgriffith$elm_ui$Internal$Model$asRow,
				$mdgriffith$elm_ui$Internal$Model$div,
				A2(
					$elm$core$List$cons,
					$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.contentLeft + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.contentCenterY + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.wrapped)))),
					A2(
						$elm$core$List$cons,
						$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$shrink),
						A2(
							$elm$core$List$cons,
							$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$shrink),
							attrs))),
				$mdgriffith$elm_ui$Internal$Model$Unkeyed(children));
		} else {
			var _v2 = spaced.a;
			var spaceName = _v2.a;
			var x = _v2.b;
			var y = _v2.c;
			var newPadding = function () {
				if (padded.$ === 'Just') {
					var _v5 = padded.a;
					var name = _v5.a;
					var t = _v5.b;
					var r = _v5.c;
					var b = _v5.d;
					var l = _v5.e;
					if ((_Utils_cmp(r, x / 2) > -1) && (_Utils_cmp(b, y / 2) > -1)) {
						var newTop = t - (y / 2);
						var newRight = r - (x / 2);
						var newLeft = l - (x / 2);
						var newBottom = b - (y / 2);
						return $elm$core$Maybe$Just(
							A2(
								$mdgriffith$elm_ui$Internal$Model$StyleClass,
								$mdgriffith$elm_ui$Internal$Flag$padding,
								A5(
									$mdgriffith$elm_ui$Internal$Model$PaddingStyle,
									A4($mdgriffith$elm_ui$Internal$Model$paddingNameFloat, newTop, newRight, newBottom, newLeft),
									newTop,
									newRight,
									newBottom,
									newLeft)));
					} else {
						return $elm$core$Maybe$Nothing;
					}
				} else {
					return $elm$core$Maybe$Nothing;
				}
			}();
			if (newPadding.$ === 'Just') {
				var pad = newPadding.a;
				return A4(
					$mdgriffith$elm_ui$Internal$Model$element,
					$mdgriffith$elm_ui$Internal$Model$asRow,
					$mdgriffith$elm_ui$Internal$Model$div,
					A2(
						$elm$core$List$cons,
						$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.contentLeft + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.contentCenterY + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.wrapped)))),
						A2(
							$elm$core$List$cons,
							$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$shrink),
							A2(
								$elm$core$List$cons,
								$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$shrink),
								_Utils_ap(
									attrs,
									_List_fromArray(
										[pad]))))),
					$mdgriffith$elm_ui$Internal$Model$Unkeyed(children));
			} else {
				var halfY = -(y / 2);
				var halfX = -(x / 2);
				return A4(
					$mdgriffith$elm_ui$Internal$Model$element,
					$mdgriffith$elm_ui$Internal$Model$asEl,
					$mdgriffith$elm_ui$Internal$Model$div,
					attrs,
					$mdgriffith$elm_ui$Internal$Model$Unkeyed(
						_List_fromArray(
							[
								A4(
								$mdgriffith$elm_ui$Internal$Model$element,
								$mdgriffith$elm_ui$Internal$Model$asRow,
								$mdgriffith$elm_ui$Internal$Model$div,
								A2(
									$elm$core$List$cons,
									$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.contentLeft + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.contentCenterY + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.wrapped)))),
									A2(
										$elm$core$List$cons,
										$mdgriffith$elm_ui$Internal$Model$Attr(
											A2(
												$elm$html$Html$Attributes$style,
												'margin',
												$elm$core$String$fromFloat(halfY) + ('px' + (' ' + ($elm$core$String$fromFloat(halfX) + 'px'))))),
										A2(
											$elm$core$List$cons,
											$mdgriffith$elm_ui$Internal$Model$Attr(
												A2(
													$elm$html$Html$Attributes$style,
													'width',
													'calc(100% + ' + ($elm$core$String$fromInt(x) + 'px)'))),
											A2(
												$elm$core$List$cons,
												$mdgriffith$elm_ui$Internal$Model$Attr(
													A2(
														$elm$html$Html$Attributes$style,
														'height',
														'calc(100% + ' + ($elm$core$String$fromInt(y) + 'px)'))),
												A2(
													$elm$core$List$cons,
													A2(
														$mdgriffith$elm_ui$Internal$Model$StyleClass,
														$mdgriffith$elm_ui$Internal$Flag$spacing,
														A3($mdgriffith$elm_ui$Internal$Model$SpacingStyle, spaceName, x, y)),
													_List_Nil))))),
								$mdgriffith$elm_ui$Internal$Model$Unkeyed(children))
							])));
			}
		}
	});
var $author$project$Main$homePage = function (displaySize) {
	return A2(
		$mdgriffith$elm_ui$Element$column,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$centerX,
				$mdgriffith$elm_ui$Element$centerY,
				$mdgriffith$elm_ui$Element$Font$color(
				A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
				$mdgriffith$elm_ui$Element$Font$heavy,
				A2($mdgriffith$elm_ui$Element$spacingXY, 10, 30),
				$mdgriffith$elm_ui$Element$scrollbarY,
				$mdgriffith$elm_ui$Element$scrollbarX,
				$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$padding(10)
			]),
		_List_fromArray(
			[
				A2(
				$mdgriffith$elm_ui$Element$paragraph,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$Font$size(45),
						A2($mdgriffith$elm_ui$Element$paddingXY, 5, 10)
					]),
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Element$el,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$Font$color(
								A3($mdgriffith$elm_ui$Element$rgb, 0.5, 0.9, 0.7)),
								$mdgriffith$elm_ui$Element$Font$size(70)
							]),
						$mdgriffith$elm_ui$Element$text('V')),
						$mdgriffith$elm_ui$Element$text('isualization of '),
						A2(
						$mdgriffith$elm_ui$Element$el,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$Font$color(
								A3($mdgriffith$elm_ui$Element$rgb, 0.5, 0.9, 0.7)),
								$mdgriffith$elm_ui$Element$Font$size(70)
							]),
						$mdgriffith$elm_ui$Element$text('C')),
						$mdgriffith$elm_ui$Element$text('lassical '),
						A2(
						$mdgriffith$elm_ui$Element$el,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$Font$color(
								A3($mdgriffith$elm_ui$Element$rgb, 0.5, 0.9, 0.7)),
								$mdgriffith$elm_ui$Element$Font$size(70)
							]),
						$mdgriffith$elm_ui$Element$text('G')),
						$mdgriffith$elm_ui$Element$text('raph '),
						A2(
						$mdgriffith$elm_ui$Element$el,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$Font$color(
								A3($mdgriffith$elm_ui$Element$rgb, 0.5, 0.9, 0.7)),
								$mdgriffith$elm_ui$Element$Font$size(70)
							]),
						$mdgriffith$elm_ui$Element$text('T')),
						$mdgriffith$elm_ui$Element$text('heory '),
						A2(
						$mdgriffith$elm_ui$Element$el,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$Font$color(
								A3($mdgriffith$elm_ui$Element$rgb, 0.5, 0.9, 0.7)),
								$mdgriffith$elm_ui$Element$Font$size(70)
							]),
						$mdgriffith$elm_ui$Element$text('P')),
						$mdgriffith$elm_ui$Element$text('roblems')
					])),
				A2(
				$mdgriffith$elm_ui$Element$row,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$centerX,
						$mdgriffith$elm_ui$Element$centerY,
						$mdgriffith$elm_ui$Element$Font$color(
						A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
						$mdgriffith$elm_ui$Element$Font$heavy,
						A2($mdgriffith$elm_ui$Element$spacingXY, 30, 30)
					]),
				A2(
					$elm$core$List$map,
					$author$project$Main$makeTopicIcon(displaySize),
					_List_fromArray(
						[$author$project$Messages$GotoIsomorphism, $author$project$Messages$GotoMaxkCut, $author$project$Messages$GotoColoring]))),
				A2(
				$mdgriffith$elm_ui$Element$wrappedRow,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$centerX,
						$mdgriffith$elm_ui$Element$centerY,
						$mdgriffith$elm_ui$Element$Font$color(
						A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1)),
						$mdgriffith$elm_ui$Element$Font$heavy,
						A2($mdgriffith$elm_ui$Element$spacingXY, 30, 15)
					]),
				A2(
					$elm$core$List$map,
					$author$project$Main$makeTopicIcon(displaySize),
					_List_fromArray(
						[$author$project$Messages$GotoCover, $author$project$Messages$GotoTreeWidth])))
			]));
};
var $elm$svg$Svg$Attributes$opacity = _VirtualDom_attribute('opacity');
var $elm$svg$Svg$rect = $elm$svg$Svg$trustedNode('rect');
var $author$project$Isomorphism$drawSquares = F2(
	function (choice, gameState) {
		var squareTwoColor = function () {
			var _v7 = _Utils_Tuple2(choice, gameState);
			_v7$2:
			while (true) {
				if (_v7.b.$ === 'Check') {
					switch (_v7.a.$) {
						case 'FirstGraph':
							var _v8 = _v7.a;
							var _v9 = _v7.b;
							return 'red';
						case 'SecondGraph':
							var _v10 = _v7.a;
							var _v11 = _v7.b;
							return 'red';
						default:
							break _v7$2;
					}
				} else {
					break _v7$2;
				}
			}
			return 'gray';
		}();
		var squareOneColor = function () {
			var _v2 = _Utils_Tuple2(choice, gameState);
			_v2$2:
			while (true) {
				if (_v2.b.$ === 'Check') {
					switch (_v2.a.$) {
						case 'FirstGraph':
							var _v3 = _v2.a;
							var _v4 = _v2.b;
							return 'green';
						case 'SecondGraph':
							var _v5 = _v2.a;
							var _v6 = _v2.b;
							return 'green';
						default:
							break _v2$2;
					}
				} else {
					break _v2$2;
				}
			}
			return 'gray';
		}();
		var circleTwoColor = function () {
			if (choice.$ === 'SecondGraph') {
				return 'blue';
			} else {
				return 'gray';
			}
		}();
		var circleOneColor = function () {
			if (choice.$ === 'FirstGraph') {
				return 'blue';
			} else {
				return 'gray';
			}
		}();
		return _List_fromArray(
			[
				A2(
				$elm$svg$Svg$rect,
				_List_fromArray(
					[
						$elm$svg$Svg$Attributes$x('220'),
						$elm$svg$Svg$Attributes$y('30'),
						$elm$svg$Svg$Attributes$width('155'),
						$elm$svg$Svg$Attributes$height('160'),
						$elm$svg$Svg$Attributes$opacity('0.2'),
						$elm$svg$Svg$Attributes$stroke('white'),
						$elm$svg$Svg$Events$onClick($author$project$Messages$IsoChoiceOne),
						$elm$svg$Svg$Attributes$fill(squareOneColor)
					]),
				_List_Nil),
				A2(
				$elm$svg$Svg$rect,
				_List_fromArray(
					[
						$elm$svg$Svg$Attributes$x('220'),
						$elm$svg$Svg$Attributes$y('230'),
						$elm$svg$Svg$Attributes$width('155'),
						$elm$svg$Svg$Attributes$height('160'),
						$elm$svg$Svg$Attributes$opacity('0.2'),
						$elm$svg$Svg$Attributes$stroke('white'),
						$elm$svg$Svg$Events$onClick($author$project$Messages$IsoChoiceTwo),
						$elm$svg$Svg$Attributes$fill(squareTwoColor)
					]),
				_List_Nil),
				A2(
				$elm$svg$Svg$circle,
				_List_fromArray(
					[
						$elm$svg$Svg$Attributes$cx('229'),
						$elm$svg$Svg$Attributes$cy('180'),
						$elm$svg$Svg$Attributes$r('5'),
						$elm$svg$Svg$Attributes$stroke('white'),
						$elm$svg$Svg$Attributes$opacity('0.2'),
						$elm$svg$Svg$Attributes$fill(circleOneColor),
						$elm$svg$Svg$Events$onClick($author$project$Messages$IsoChoiceOne)
					]),
				_List_Nil),
				A2(
				$elm$svg$Svg$circle,
				_List_fromArray(
					[
						$elm$svg$Svg$Attributes$cx('229'),
						$elm$svg$Svg$Attributes$cy('380'),
						$elm$svg$Svg$Attributes$r('5'),
						$elm$svg$Svg$Attributes$stroke('white'),
						$elm$svg$Svg$Attributes$opacity('0.2'),
						$elm$svg$Svg$Attributes$fill(circleTwoColor),
						$elm$svg$Svg$Events$onClick($author$project$Messages$IsoChoiceTwo)
					]),
				_List_Nil)
			]);
	});
var $author$project$Isomorphism$isomorphicDisplay = function (topic) {
	var _v0 = topic.topicState;
	if (_v0.$ === 'Transition') {
		return $author$project$Graph$displaySvg(
			_Utils_ap(
				$author$project$Isomorphism$drawGraph(topic.shapeTransition.graphA),
				$author$project$Isomorphism$drawGraph(topic.shapeTransition.graphB)));
	} else {
		var game = topic.isomorphicGame;
		var gameState = game.gameState;
		var choice = game.choiceState;
		return $author$project$Graph$displaySvg(
			_Utils_ap(
				$author$project$Isomorphism$drawGraph(topic.isomorphicGame.transition.graph),
				_Utils_ap(
					A2($author$project$Isomorphism$drawSquares, choice, gameState),
					_Utils_ap(
						$author$project$Isomorphism$drawGraph(topic.isomorphicGame.graphB),
						$author$project$Isomorphism$drawGraph(topic.isomorphicGame.graphC)))));
	}
};
var $author$project$VertexCover$drawGraphForCover = function (g) {
	var selectedVertices = A2(
		$elm$core$List$filter,
		function (ver) {
			return ver.glow;
		},
		g.vertices);
	var _v0 = $author$project$Graph$seperateEdges(g);
	var specialEdges = _v0.a;
	var normalEdges = _v0.b;
	var haloVertices = A2($author$project$Graph$getHaloVertices, g, specialEdges);
	return _Utils_ap(
		A2($elm$core$List$map, $author$project$Graph$drawEdge, normalEdges),
		_Utils_ap(
			A2($elm$core$List$map, $author$project$Graph$drawSpecialEdge, specialEdges),
			_Utils_ap(
				A2($elm$core$List$map, $author$project$Graph$drawVertex, g.vertices),
				_Utils_ap(
					A2($elm$core$List$map, $author$project$Graph$drawSelectedVertex, selectedVertices),
					A2($elm$core$List$map, $author$project$Graph$writeVertexName, g.vertices)))));
};
var $author$project$VertexCover$paneFour = function (display) {
	var _v0 = display.state;
	if (_v0.$ === 'First') {
		return $author$project$Graph$displaySvg(
			$author$project$VertexCover$drawGraphForCover(display.graphA));
	} else {
		return $author$project$Graph$displaySvg(
			$author$project$VertexCover$drawGraphForCover(display.graphB));
	}
};
var $author$project$Messages$ColoringSelectColor = function (a) {
	return {$: 'ColoringSelectColor', a: a};
};
var $author$project$GraphColoring$makeSquare = F3(
	function (pos, size, color) {
		return A2(
			$elm$svg$Svg$rect,
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$x(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getX(pos)))),
					$elm$svg$Svg$Attributes$y(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getY(pos)))),
					$elm$svg$Svg$Attributes$width(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getX(size)))),
					$elm$svg$Svg$Attributes$height(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getY(size)))),
					$elm$svg$Svg$Attributes$style(
					'fill: ' + ($avh4$elm_color$Color$toCssString(color) + ';')),
					$elm$svg$Svg$Events$onClick(
					$author$project$Messages$ColoringSelectColor(color))
				]),
			_List_Nil);
	});
var $author$project$GraphColoring$colorPallete = function (display) {
	var sizeSmall = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 20, 20, 0);
	var sizeBig = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 20, 35, 0);
	var sizeOfColor = function (color) {
		return _Utils_eq(display.chosenColor, color) ? sizeBig : sizeSmall;
	};
	var red = A3($avh4$elm_color$Color$rgb, 1, 0, 0);
	var squareRed = A3(
		$author$project$GraphColoring$makeSquare,
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 170, 230, 0),
		sizeOfColor(red),
		red);
	var green = A3($avh4$elm_color$Color$rgb, 0, 1, 0);
	var squareGreen = A3(
		$author$project$GraphColoring$makeSquare,
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 200, 230, 0),
		sizeOfColor(green),
		green);
	var blue = A3($avh4$elm_color$Color$rgb, 0, 0, 1);
	var squareBlue = A3(
		$author$project$GraphColoring$makeSquare,
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 230, 230, 0),
		sizeOfColor(blue),
		blue);
	return _List_fromArray(
		[squareRed, squareGreen, squareBlue]);
};
var $author$project$GraphColoring$colorPalleteTwo = function (display) {
	var sizeSmall = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 20, 20, 0);
	var sizeBig = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 20, 35, 0);
	var sizeOfColor = function (color) {
		return _Utils_eq(display.chosenColor, color) ? sizeBig : sizeSmall;
	};
	var red = A3($avh4$elm_color$Color$rgb, 1, 0, 0);
	var squareRed = A3(
		$author$project$GraphColoring$makeSquare,
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 170, 230, 0),
		sizeOfColor(red),
		red);
	var green = A3($avh4$elm_color$Color$rgb, 0, 1, 0);
	var squareGreen = A3(
		$author$project$GraphColoring$makeSquare,
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 200, 230, 0),
		sizeOfColor(green),
		green);
	var blue = A3($avh4$elm_color$Color$rgb, 0, 0, 1);
	var squareBlue = A3(
		$author$project$GraphColoring$makeSquare,
		A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 230, 230, 0),
		sizeOfColor(blue),
		blue);
	return _List_fromArray(
		[squareRed, squareGreen]);
};
var $author$project$GraphColoring$drawGraphForColoring = function (g) {
	var verticesOfSameColor = function (edge) {
		return _Utils_eq(edge.vertexOne.color, edge.vertexTwo.color) && (!_Utils_eq(
			edge.vertexOne.color,
			A3($avh4$elm_color$Color$rgb, 1, 1, 1)));
	};
	var normalEdges = A2(
		$elm$core$List$filter,
		function (e) {
			return !verticesOfSameColor(e);
		},
		g.edges);
	var miscoloredEdges = A2(
		$elm$core$List$filter,
		function (e) {
			return verticesOfSameColor(e);
		},
		g.edges);
	return _Utils_ap(
		A2($elm$core$List$map, $author$project$Graph$drawEdge, normalEdges),
		_Utils_ap(
			A2($elm$core$List$map, $author$project$Graph$drawSpecialEdge, miscoloredEdges),
			_Utils_ap(
				A2($elm$core$List$map, $author$project$Graph$drawVertex, g.vertices),
				A2($elm$core$List$map, $author$project$Graph$writeVertexName, g.vertices))));
};
var $author$project$GraphColoring$paneThree = function (displaySeries) {
	var display = function () {
		var _v1 = displaySeries.state;
		if (_v1.$ === 'TwoColor') {
			return displaySeries.colorDisplayA;
		} else {
			return displaySeries.colorDisplayB;
		}
	}();
	var colorPalleteHere = function () {
		var _v0 = displaySeries.state;
		if (_v0.$ === 'TwoColor') {
			return $author$project$GraphColoring$colorPalleteTwo;
		} else {
			return $author$project$GraphColoring$colorPallete;
		}
	}();
	return $author$project$Graph$displaySvg(
		_Utils_ap(
			$author$project$GraphColoring$drawGraphForColoring(display.graphA),
			colorPalleteHere(display)));
};
var $author$project$Graph$gline = F2(
	function (veca, vecb) {
		return A2(
			$elm$svg$Svg$line,
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$x1(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getX(veca)))),
					$elm$svg$Svg$Attributes$y1(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getY(veca)))),
					$elm$svg$Svg$Attributes$x2(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getX(vecb)))),
					$elm$svg$Svg$Attributes$y2(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getY(vecb)))),
					$elm$svg$Svg$Attributes$stroke('#999999'),
					$elm$svg$Svg$Attributes$strokeWidth('4')
				]),
			_List_Nil);
	});
var $author$project$Graph$drawGrayEdge = function (e) {
	return A2($author$project$Graph$gline, e.vertexOne.pos, e.vertexTwo.pos);
};
var $author$project$Graph$drawGrayVertex = function (v) {
	return A4($author$project$Graph$ccircle, 13, v.pos, '#999999', v.name);
};
var $author$project$Graph$drawIntersectionPoint = F2(
	function (size, pos) {
		return A2(
			$elm$svg$Svg$circle,
			_List_fromArray(
				[
					$elm$svg$Svg$Attributes$cx(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getX(pos)))),
					$elm$svg$Svg$Attributes$cy(
					$elm$core$String$fromInt(
						$elm$core$Basics$round(
							$elm_explorations$linear_algebra$Math$Vector3$getY(pos)))),
					$elm$svg$Svg$Attributes$r(
					$elm$core$String$fromInt(size)),
					$elm$svg$Svg$Attributes$style('fill: ' + ('blue' + ';'))
				]),
			_List_Nil);
	});
var $author$project$Graph$drawSmallVertex = function (v) {
	return A4($author$project$Graph$circle, 4, v.pos, v.color, v.name);
};
var $author$project$Graph$findCenterOfQuad = F5(
	function (a, b, c, d, vs) {
		var pos4 = function () {
			var _v4 = A2($author$project$Graph$lookUpVertex, d, vs);
			if (_v4.$ === 'Just') {
				var x = _v4.a;
				return x.pos;
			} else {
				return A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 0.0, 0.0, 0.0);
			}
		}();
		var _v0 = _Utils_Tuple3(
			A2($author$project$Graph$lookUpVertex, a, vs),
			A2($author$project$Graph$lookUpVertex, b, vs),
			A2($author$project$Graph$lookUpVertex, c, vs));
		if (_v0.a.$ === 'Nothing') {
			var _v1 = _v0.a;
			return $elm$core$Maybe$Nothing;
		} else {
			if (_v0.b.$ === 'Nothing') {
				var _v2 = _v0.b;
				return $elm$core$Maybe$Nothing;
			} else {
				if (_v0.c.$ === 'Nothing') {
					var _v3 = _v0.c;
					return $elm$core$Maybe$Nothing;
				} else {
					var v1 = _v0.a.a;
					var v2 = _v0.b.a;
					var v3 = _v0.c.a;
					return $elm$core$Maybe$Just(
						A2(
							$elm_explorations$linear_algebra$Math$Vector3$scale,
							0.25,
							A2(
								$elm_explorations$linear_algebra$Math$Vector3$add,
								pos4,
								A2(
									$elm_explorations$linear_algebra$Math$Vector3$add,
									v3.pos,
									A2($elm_explorations$linear_algebra$Math$Vector3$add, v1.pos, v2.pos)))));
				}
			}
		}
	});
var $author$project$Graph$findCenterOfTriple = F4(
	function (a, b, c, vs) {
		var _v0 = _Utils_Tuple3(
			A2($author$project$Graph$lookUpVertex, a, vs),
			A2($author$project$Graph$lookUpVertex, b, vs),
			A2($author$project$Graph$lookUpVertex, c, vs));
		if (_v0.a.$ === 'Nothing') {
			var _v1 = _v0.a;
			return $elm$core$Maybe$Nothing;
		} else {
			if (_v0.b.$ === 'Nothing') {
				var _v2 = _v0.b;
				return $elm$core$Maybe$Nothing;
			} else {
				if (_v0.c.$ === 'Nothing') {
					var _v3 = _v0.c;
					return $elm$core$Maybe$Nothing;
				} else {
					var v1 = _v0.a.a;
					var v2 = _v0.b.a;
					var v3 = _v0.c.a;
					return $elm$core$Maybe$Just(
						A2(
							$elm_explorations$linear_algebra$Math$Vector3$scale,
							0.333,
							A2(
								$elm_explorations$linear_algebra$Math$Vector3$add,
								v3.pos,
								A2($elm_explorations$linear_algebra$Math$Vector3$add, v1.pos, v2.pos))));
				}
			}
		}
	});
var $author$project$Graph$findTwoPositions = F2(
	function (vs, x) {
		var _v1 = x.a;
		var a1 = _v1.a;
		var b1 = _v1.b;
		var c1 = _v1.c;
		var _v2 = x.b;
		var a2 = _v2.a;
		var b2 = _v2.b;
		var c2 = _v2.c;
		var pos2 = A4($author$project$Graph$findCenterOfTriple, a2, b2, c2, vs);
		var pos1 = A4($author$project$Graph$findCenterOfTriple, a1, b1, c1, vs);
		var _v3 = _Utils_Tuple2(pos1, pos2);
		if (_v3.a.$ === 'Nothing') {
			var _v4 = _v3.a;
			return $elm$core$Maybe$Nothing;
		} else {
			if (_v3.b.$ === 'Nothing') {
				var _v5 = _v3.b;
				return $elm$core$Maybe$Nothing;
			} else {
				var p1 = _v3.a.a;
				var p2 = _v3.b.a;
				return $elm$core$Maybe$Just(
					_Utils_Tuple2(p1, p2));
			}
		}
	});
var $author$project$TreeWidth$drawGraphForTreeWidth = function (display) {
	var unsafeTail = function (xs) {
		if (!xs.b) {
			return _List_Nil;
		} else {
			if (!xs.b.b) {
				var x = xs.a;
				return _List_Nil;
			} else {
				var x = xs.a;
				var _v27 = xs.b;
				var y = _v27.a;
				var xss = _v27.b;
				return xss;
			}
		}
	};
	var unsafeHead = function (xs) {
		if (xs.b) {
			var x = xs.a;
			var xss = xs.b;
			return x;
		} else {
			return A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 0, 0, 0);
		}
	};
	var gSmall = display.graphSmall;
	var smallEdges = function () {
		var _v24 = display.status;
		switch (_v24.$) {
			case 'CircularGraph':
				return _List_Nil;
			case 'MorphingIntoHoneyComb':
				return _List_Nil;
			default:
				return gSmall.edges;
		}
	}();
	var smallVertices = function () {
		var _v23 = display.status;
		switch (_v23.$) {
			case 'CircularGraph':
				return _List_Nil;
			case 'MorphingIntoHoneyComb':
				return _List_Nil;
			default:
				return gSmall.vertices;
		}
	}();
	var g = display.graph;
	var onePieceCenter = function () {
		var _v21 = display.status;
		if (_v21.$ === 'ShowOnePiece') {
			var _v22 = A4($author$project$Graph$findCenterOfTriple, 1, 2, 3, g.vertices);
			if (_v22.$ === 'Nothing') {
				return _List_Nil;
			} else {
				var x = _v22.a;
				return _List_fromArray(
					[x]);
			}
		} else {
			return _List_Nil;
		}
	}();
	var showBigPieceEdges = function () {
		var _v20 = display.status;
		if (_v20.$ === 'ShowLargePiece') {
			return A2(
				$author$project$Graph$makeEdgesWithTuples,
				_List_fromArray(
					[
						_Utils_Tuple2(1, 2),
						_Utils_Tuple2(2, 3),
						_Utils_Tuple2(2, 4),
						_Utils_Tuple2(4, 3),
						_Utils_Tuple2(3, 1)
					]),
				g.vertices);
		} else {
			return _List_Nil;
		}
	}();
	var showBigPieceVertices = function () {
		var _v19 = display.status;
		if (_v19.$ === 'ShowLargePiece') {
			return A2(
				$elm$core$List$filterMap,
				function (name) {
					return A2($author$project$Graph$lookUpVertex, name, g.vertices);
				},
				_List_fromArray(
					[1, 2, 3, 4]));
		} else {
			return _List_Nil;
		}
	}();
	var showGrayEdges = function () {
		var _v18 = display.status;
		if (_v18.$ === 'AltTree') {
			return A2(
				$author$project$Graph$makeEdgesWithTuples,
				_List_fromArray(
					[
						_Utils_Tuple2(1, 2),
						_Utils_Tuple2(2, 3),
						_Utils_Tuple2(2, 4),
						_Utils_Tuple2(4, 3),
						_Utils_Tuple2(3, 1)
					]),
				g.vertices);
		} else {
			return _List_Nil;
		}
	}();
	var showGrayVertices = function () {
		var _v17 = display.status;
		if (_v17.$ === 'AltTree') {
			return A2(
				$elm$core$List$filterMap,
				function (name) {
					return A2($author$project$Graph$lookUpVertex, name, g.vertices);
				},
				_List_fromArray(
					[1, 2, 3, 4]));
		} else {
			return _List_Nil;
		}
	}();
	var showPieceEdges = function () {
		var _v16 = display.status;
		if (_v16.$ === 'ShowOnePiece') {
			return A2(
				$author$project$Graph$makeEdgesWithTuples,
				_List_fromArray(
					[
						_Utils_Tuple2(1, 2),
						_Utils_Tuple2(2, 3),
						_Utils_Tuple2(3, 1)
					]),
				g.vertices);
		} else {
			return _List_Nil;
		}
	}();
	var showPieceVertices = function () {
		var _v15 = display.status;
		if (_v15.$ === 'ShowOnePiece') {
			return A2(
				$elm$core$List$filterMap,
				function (name) {
					return A2($author$project$Graph$lookUpVertex, name, g.vertices);
				},
				_List_fromArray(
					[1, 2, 3]));
		} else {
			return _List_Nil;
		}
	}();
	var treeLinesDrawn = function () {
		var _v14 = display.status;
		switch (_v14.$) {
			case 'TreeDrawnGraph':
				return A2(
					$elm$core$List$filterMap,
					$author$project$Graph$findTwoPositions(g.vertices),
					display.treeLines);
			case 'FinalSlide':
				return A2(
					$elm$core$List$filterMap,
					$author$project$Graph$findTwoPositions(g.vertices),
					display.treeLines);
			default:
				return _List_Nil;
		}
	}();
	var centersOftriples = function () {
		var _v10 = display.status;
		switch (_v10.$) {
			case 'TreeDrawnGraph':
				return A2(
					$elm$core$List$filterMap,
					function (_v11) {
						var a = _v11.a;
						var b = _v11.b;
						var c = _v11.c;
						return A4($author$project$Graph$findCenterOfTriple, a, b, c, g.vertices);
					},
					display.triples);
			case 'PiecesMarked':
				return A2(
					$elm$core$List$filterMap,
					function (_v12) {
						var a = _v12.a;
						var b = _v12.b;
						var c = _v12.c;
						return A4($author$project$Graph$findCenterOfTriple, a, b, c, g.vertices);
					},
					display.triples);
			case 'FinalSlide':
				return A2(
					$elm$core$List$filterMap,
					function (_v13) {
						var a = _v13.a;
						var b = _v13.b;
						var c = _v13.c;
						return A4($author$project$Graph$findCenterOfTriple, a, b, c, g.vertices);
					},
					display.triples);
			default:
				return _List_Nil;
		}
	}();
	var bigPieceCenter = function () {
		var _v7 = display.status;
		switch (_v7.$) {
			case 'ShowLargePiece':
				var _v8 = A5($author$project$Graph$findCenterOfQuad, 1, 2, 3, 4, g.vertices);
				if (_v8.$ === 'Nothing') {
					return _List_Nil;
				} else {
					var x = _v8.a;
					return _List_fromArray(
						[x]);
				}
			case 'AltTree':
				var _v9 = A5($author$project$Graph$findCenterOfQuad, 1, 2, 3, 4, g.vertices);
				if (_v9.$ === 'Nothing') {
					return _List_Nil;
				} else {
					var x = _v9.a;
					return _List_fromArray(
						[x]);
				}
			default:
				return _List_Nil;
		}
	}();
	var altTreeLinesDrawn = function () {
		var _v6 = display.status;
		if (_v6.$ === 'AltTree') {
			return unsafeTail(
				A2(
					$elm$core$List$filterMap,
					$author$project$Graph$findTwoPositions(g.vertices),
					display.treeLines));
		} else {
			return _List_Nil;
		}
	}();
	var altTreeDots = function () {
		var _v4 = display.status;
		if (_v4.$ === 'AltTree') {
			return unsafeTail(
				A2(
					$elm$core$List$filterMap,
					function (_v5) {
						var a = _v5.a;
						var b = _v5.b;
						var c = _v5.c;
						return A4($author$project$Graph$findCenterOfTriple, a, b, c, g.vertices);
					},
					display.triples));
		} else {
			return _List_Nil;
		}
	}();
	var firstBranchAltTree = function () {
		var _v3 = display.status;
		if (_v3.$ === 'AltTree') {
			var secondPoint = unsafeHead(altTreeDots);
			var firstDot = unsafeHead(bigPieceCenter);
			return _List_fromArray(
				[
					_Utils_Tuple2(firstDot, secondPoint)
				]);
		} else {
			return _List_Nil;
		}
	}();
	return _Utils_ap(
		A2($elm$core$List$map, $author$project$Graph$drawEdge, g.edges),
		_Utils_ap(
			A2($elm$core$List$map, $author$project$Graph$drawEdge, smallEdges),
			_Utils_ap(
				A2(
					$elm$core$List$map,
					function (_v0) {
						var p1 = _v0.a;
						var p2 = _v0.b;
						return A2($author$project$Graph$lline, p1, p2);
					},
					treeLinesDrawn),
				_Utils_ap(
					A2($elm$core$List$map, $author$project$Graph$drawGrayEdge, showGrayEdges),
					_Utils_ap(
						A2(
							$elm$core$List$map,
							function (_v1) {
								var p1 = _v1.a;
								var p2 = _v1.b;
								return A2($author$project$Graph$lline, p1, p2);
							},
							altTreeLinesDrawn),
						_Utils_ap(
							A2(
								$elm$core$List$map,
								function (_v2) {
									var p1 = _v2.a;
									var p2 = _v2.b;
									return A2($author$project$Graph$lline, p1, p2);
								},
								firstBranchAltTree),
							_Utils_ap(
								A2(
									$elm$core$List$map,
									$author$project$Graph$drawIntersectionPoint(6),
									centersOftriples),
								_Utils_ap(
									A2(
										$elm$core$List$map,
										$author$project$Graph$drawIntersectionPoint(6),
										altTreeDots),
									_Utils_ap(
										A2($elm$core$List$map, $author$project$Graph$drawVertex, g.vertices),
										_Utils_ap(
											A2($elm$core$List$map, $author$project$Graph$drawSmallVertex, smallVertices),
											_Utils_ap(
												A2($elm$core$List$map, $author$project$Graph$drawSpecialEdge, showPieceEdges),
												_Utils_ap(
													A2($elm$core$List$map, $author$project$Graph$drawSpecialEdge, showBigPieceEdges),
													_Utils_ap(
														A2($elm$core$List$map, $author$project$Graph$drawSelectedVertex, showPieceVertices),
														_Utils_ap(
															A2($elm$core$List$map, $author$project$Graph$drawSelectedVertex, showBigPieceVertices),
															_Utils_ap(
																A2($elm$core$List$map, $author$project$Graph$drawGrayVertex, showGrayVertices),
																_Utils_ap(
																	A2(
																		$elm$core$List$map,
																		$author$project$Graph$drawIntersectionPoint(6),
																		bigPieceCenter),
																	A2($elm$core$List$map, $author$project$Graph$writeVertexName, g.vertices)))))))))))))))));
};
var $author$project$TreeWidth$paneTree = function (display) {
	return $author$project$Graph$displaySvg(
		$author$project$TreeWidth$drawGraphForTreeWidth(display));
};
var $author$project$Graph$drawIntersectionPoints = function (points) {
	return A2(
		$elm$core$List$map,
		$author$project$Graph$drawIntersectionPoint(3),
		points);
};
var $author$project$MaxkCut$drawCutLine = function (cutLine) {
	var start = cutLine.a;
	var end = cutLine.b;
	var l = cutLine.c;
	return _Utils_ap(
		_List_fromArray(
			[
				A2($author$project$Graph$line, start, end)
			]),
		$author$project$Graph$drawIntersectionPoints(l));
};
var $author$project$MaxkCut$CutLine = F3(
	function (a, b, c) {
		return {$: 'CutLine', a: a, b: b, c: c};
	});
var $author$project$Graph$findEdgeLines = function (edges) {
	if (edges.b) {
		var x = edges.a;
		var xs = edges.b;
		return A2(
			$elm$core$List$cons,
			_Utils_Tuple2(x.vertexOne.pos, x.vertexTwo.pos),
			$author$project$Graph$findEdgeLines(xs));
	} else {
		return _List_Nil;
	}
};
var $ianmackenzie$elm_geometry$Geometry$Types$LineSegment2d = function (a) {
	return {$: 'LineSegment2d', a: a};
};
var $ianmackenzie$elm_geometry$LineSegment2d$fromEndpoints = $ianmackenzie$elm_geometry$Geometry$Types$LineSegment2d;
var $ianmackenzie$elm_units$Length$inMeters = function (_v0) {
	var numMeters = _v0.a;
	return numMeters;
};
var $ianmackenzie$elm_units$Quantity$Quantity = function (a) {
	return {$: 'Quantity', a: a};
};
var $ianmackenzie$elm_geometry$Vector2d$cross = F2(
	function (_v0, _v1) {
		var v2 = _v0.a;
		var v1 = _v1.a;
		return $ianmackenzie$elm_units$Quantity$Quantity((v1.x * v2.y) - (v1.y * v2.x));
	});
var $ianmackenzie$elm_geometry$Vector2d$dot = F2(
	function (_v0, _v1) {
		var v2 = _v0.a;
		var v1 = _v1.a;
		return $ianmackenzie$elm_units$Quantity$Quantity((v1.x * v2.x) + (v1.y * v2.y));
	});
var $ianmackenzie$elm_geometry$LineSegment2d$endpoints = function (_v0) {
	var endpoints_ = _v0.a;
	return endpoints_;
};
var $ianmackenzie$elm_geometry$Geometry$Types$Vector2d = function (a) {
	return {$: 'Vector2d', a: a};
};
var $ianmackenzie$elm_geometry$Vector2d$from = F2(
	function (_v0, _v1) {
		var p1 = _v0.a;
		var p2 = _v1.a;
		return $ianmackenzie$elm_geometry$Geometry$Types$Vector2d(
			{x: p2.x - p1.x, y: p2.y - p1.y});
	});
var $ianmackenzie$elm_geometry$Geometry$Types$Point2d = function (a) {
	return {$: 'Point2d', a: a};
};
var $ianmackenzie$elm_geometry$Point2d$interpolateFrom = F3(
	function (_v0, _v1, t) {
		var p1 = _v0.a;
		var p2 = _v1.a;
		return (t <= 0.5) ? $ianmackenzie$elm_geometry$Geometry$Types$Point2d(
			{x: p1.x + (t * (p2.x - p1.x)), y: p1.y + (t * (p2.y - p1.y))}) : $ianmackenzie$elm_geometry$Geometry$Types$Point2d(
			{x: p2.x + ((1 - t) * (p1.x - p2.x)), y: p2.y + ((1 - t) * (p1.y - p2.y))});
	});
var $ianmackenzie$elm_geometry$LineSegment2d$interpolate = F2(
	function (lineSegment, t) {
		var _v0 = $ianmackenzie$elm_geometry$LineSegment2d$endpoints(lineSegment);
		var start = _v0.a;
		var end = _v0.b;
		return A3($ianmackenzie$elm_geometry$Point2d$interpolateFrom, start, end, t);
	});
var $ianmackenzie$elm_units$Quantity$lessThan = F2(
	function (_v0, _v1) {
		var y = _v0.a;
		var x = _v1.a;
		return _Utils_cmp(x, y) < 0;
	});
var $ianmackenzie$elm_units$Quantity$minus = F2(
	function (_v0, _v1) {
		var y = _v0.a;
		var x = _v1.a;
		return $ianmackenzie$elm_units$Quantity$Quantity(x - y);
	});
var $ianmackenzie$elm_units$Quantity$plus = F2(
	function (_v0, _v1) {
		var y = _v0.a;
		var x = _v1.a;
		return $ianmackenzie$elm_units$Quantity$Quantity(x + y);
	});
var $ianmackenzie$elm_units$Quantity$ratio = F2(
	function (_v0, _v1) {
		var x = _v0.a;
		var y = _v1.a;
		return x / y;
	});
var $ianmackenzie$elm_geometry$LineSegment2d$vector = function (lineSegment) {
	var _v0 = $ianmackenzie$elm_geometry$LineSegment2d$endpoints(lineSegment);
	var p1 = _v0.a;
	var p2 = _v0.b;
	return A2($ianmackenzie$elm_geometry$Vector2d$from, p1, p2);
};
var $ianmackenzie$elm_units$Quantity$zero = $ianmackenzie$elm_units$Quantity$Quantity(0);
var $ianmackenzie$elm_geometry$LineSegment2d$intersectionPoint = F2(
	function (lineSegment1, lineSegment2) {
		var s = $ianmackenzie$elm_geometry$LineSegment2d$vector(lineSegment2);
		var r = $ianmackenzie$elm_geometry$LineSegment2d$vector(lineSegment1);
		var _v0 = $ianmackenzie$elm_geometry$LineSegment2d$endpoints(lineSegment2);
		var q = _v0.a;
		var q_ = _v0.b;
		var _v1 = $ianmackenzie$elm_geometry$LineSegment2d$endpoints(lineSegment1);
		var p = _v1.a;
		var p_ = _v1.b;
		var pq = A2($ianmackenzie$elm_geometry$Vector2d$from, p, q);
		var pqXr = A2($ianmackenzie$elm_geometry$Vector2d$cross, r, pq);
		var pqXs = A2($ianmackenzie$elm_geometry$Vector2d$cross, s, pq);
		var pq_ = A2($ianmackenzie$elm_geometry$Vector2d$from, p, q_);
		var rXpq_ = A2($ianmackenzie$elm_geometry$Vector2d$cross, pq_, r);
		var uDenominator = A2($ianmackenzie$elm_units$Quantity$plus, rXpq_, pqXr);
		var qp_ = A2($ianmackenzie$elm_geometry$Vector2d$from, q, p_);
		var sXqp_ = A2($ianmackenzie$elm_geometry$Vector2d$cross, qp_, s);
		var tDenominator = A2($ianmackenzie$elm_units$Quantity$minus, sXqp_, pqXs);
		if (_Utils_eq(tDenominator, $ianmackenzie$elm_units$Quantity$zero) || _Utils_eq(uDenominator, $ianmackenzie$elm_units$Quantity$zero)) {
			return A2(
				$ianmackenzie$elm_units$Quantity$lessThan,
				$ianmackenzie$elm_units$Quantity$zero,
				A2($ianmackenzie$elm_geometry$Vector2d$dot, s, r)) ? (_Utils_eq(p_, q_) ? $elm$core$Maybe$Just(p_) : (_Utils_eq(p, q) ? $elm$core$Maybe$Just(p) : $elm$core$Maybe$Nothing)) : (_Utils_eq(p_, q) ? $elm$core$Maybe$Just(p_) : (_Utils_eq(p, q_) ? $elm$core$Maybe$Just(p) : $elm$core$Maybe$Nothing));
		} else {
			var u = A2($ianmackenzie$elm_units$Quantity$ratio, pqXr, uDenominator);
			var t = A2($ianmackenzie$elm_units$Quantity$ratio, pqXs, tDenominator);
			if (((0 <= t) && (t <= 1)) && ((0 <= u) && (u <= 1))) {
				var intersection = (_Utils_cmp(
					A2($elm$core$Basics$min, t, 1 - t),
					A2($elm$core$Basics$min, u, 1 - u)) < 1) ? A2($ianmackenzie$elm_geometry$LineSegment2d$interpolate, lineSegment1, t) : A2($ianmackenzie$elm_geometry$LineSegment2d$interpolate, lineSegment2, u);
				return $elm$core$Maybe$Just(intersection);
			} else {
				return $elm$core$Maybe$Nothing;
			}
		}
	});
var $ianmackenzie$elm_geometry$Point2d$meters = F2(
	function (x, y) {
		return $ianmackenzie$elm_geometry$Geometry$Types$Point2d(
			{x: x, y: y});
	});
var $ianmackenzie$elm_geometry$Point2d$xCoordinate = function (_v0) {
	var p = _v0.a;
	return $ianmackenzie$elm_units$Quantity$Quantity(p.x);
};
var $ianmackenzie$elm_geometry$Point2d$yCoordinate = function (_v0) {
	var p = _v0.a;
	return $ianmackenzie$elm_units$Quantity$Quantity(p.y);
};
var $author$project$Graph$findIntersection = F2(
	function (lineOne, lineTwo) {
		var _v0 = lineTwo;
		var p21 = _v0.a;
		var p22 = _v0.b;
		var point3 = A2(
			$ianmackenzie$elm_geometry$Point2d$meters,
			$elm_explorations$linear_algebra$Math$Vector3$getX(p21),
			$elm_explorations$linear_algebra$Math$Vector3$getY(p21));
		var point4 = A2(
			$ianmackenzie$elm_geometry$Point2d$meters,
			$elm_explorations$linear_algebra$Math$Vector3$getX(p22),
			$elm_explorations$linear_algebra$Math$Vector3$getY(p22));
		var line2 = $ianmackenzie$elm_geometry$LineSegment2d$fromEndpoints(
			_Utils_Tuple2(point3, point4));
		var _v1 = lineOne;
		var p11 = _v1.a;
		var p12 = _v1.b;
		var point1 = A2(
			$ianmackenzie$elm_geometry$Point2d$meters,
			$elm_explorations$linear_algebra$Math$Vector3$getX(p11),
			$elm_explorations$linear_algebra$Math$Vector3$getY(p11));
		var point2 = A2(
			$ianmackenzie$elm_geometry$Point2d$meters,
			$elm_explorations$linear_algebra$Math$Vector3$getX(p12),
			$elm_explorations$linear_algebra$Math$Vector3$getY(p12));
		var line1 = $ianmackenzie$elm_geometry$LineSegment2d$fromEndpoints(
			_Utils_Tuple2(point1, point2));
		var _v2 = A2($ianmackenzie$elm_geometry$LineSegment2d$intersectionPoint, line1, line2);
		if (_v2.$ === 'Nothing') {
			return $elm$core$Maybe$Nothing;
		} else {
			var poinIn = _v2.a;
			var y = $ianmackenzie$elm_units$Length$inMeters(
				$ianmackenzie$elm_geometry$Point2d$yCoordinate(poinIn));
			var x = $ianmackenzie$elm_units$Length$inMeters(
				$ianmackenzie$elm_geometry$Point2d$xCoordinate(poinIn));
			return $elm$core$Maybe$Just(
				A3($elm_explorations$linear_algebra$Math$Vector3$vec3, x, y, 0));
		}
	});
var $author$project$MaxkCut$makeCutLine = function (shapeTransition) {
	var start = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 210, 155, 0);
	var setB = _List_fromArray(
		[5, 6, 7, 8]);
	var setA = _List_fromArray(
		[1, 2, 3, 4]);
	var end = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 370, 155, 0);
	var edgeLines = $author$project$Graph$findEdgeLines(shapeTransition.graphB.edges);
	var intersectionPoints = A2(
		$elm$core$List$filterMap,
		$author$project$Graph$findIntersection(
			_Utils_Tuple2(start, end)),
		edgeLines);
	return A3($author$project$MaxkCut$CutLine, start, end, intersectionPoints);
};
var $author$project$MaxkCut$paneTwoA = function (shapeTransition) {
	var graphB = shapeTransition.graphB;
	var graphA = shapeTransition.graphA;
	var _v0 = shapeTransition.specialToken;
	if (_v0.$ === 'MakeKCut') {
		var cutLine = $author$project$MaxkCut$makeCutLine(shapeTransition);
		return $author$project$Graph$displaySvg(
			_Utils_ap(
				$author$project$Graph$drawGraph(graphA),
				_Utils_ap(
					$author$project$Graph$drawGraph(graphB),
					$author$project$MaxkCut$drawCutLine(cutLine))));
	} else {
		return $author$project$Graph$displaySvg(
			_Utils_ap(
				$author$project$Graph$drawGraph(graphA),
				$author$project$Graph$drawGraph(graphB)));
	}
};
var $elm$core$List$member = F2(
	function (x, xs) {
		return A2(
			$elm$core$List$any,
			function (a) {
				return _Utils_eq(a, x);
			},
			xs);
	});
var $elm_explorations$linear_algebra$Math$Vector3$normalize = _MJS_v3normalize;
var $author$project$Graph$findPositionsOfTuples = F2(
	function (vs, tu) {
		var name1 = tu.a;
		var name2 = tu.b;
		var _v1 = _Utils_Tuple2(
			A2($author$project$Graph$lookUpVertex, name1, vs),
			A2($author$project$Graph$lookUpVertex, name2, vs));
		if (_v1.a.$ === 'Nothing') {
			var _v2 = _v1.a;
			return $elm$core$Maybe$Nothing;
		} else {
			if (_v1.b.$ === 'Nothing') {
				var _v3 = _v1.b;
				return $elm$core$Maybe$Nothing;
			} else {
				var vertexOne = _v1.a.a;
				var vertexTwo = _v1.b.a;
				var pullDown = A3($elm_explorations$linear_algebra$Math$Vector3$vec3, 0, 20, 0);
				var pos2 = vertexTwo.pos;
				var pos1 = vertexOne.pos;
				var diff = $elm_explorations$linear_algebra$Math$Vector3$normalize(
					A2($elm_explorations$linear_algebra$Math$Vector3$sub, pos2, pos1));
				var linePos1 = A2(
					$elm_explorations$linear_algebra$Math$Vector3$sub,
					pos1,
					A2($elm_explorations$linear_algebra$Math$Vector3$scale, 50, diff));
				var linePos2 = A2(
					$elm_explorations$linear_algebra$Math$Vector3$add,
					pos2,
					A2($elm_explorations$linear_algebra$Math$Vector3$scale, 50, diff));
				var _v4 = A2(
					$elm$core$List$member,
					vertexOne.name,
					_List_fromArray(
						[1, 2, 3])) ? _Utils_Tuple2(
					A2($elm_explorations$linear_algebra$Math$Vector3$sub, linePos1, pullDown),
					A2($elm_explorations$linear_algebra$Math$Vector3$sub, linePos2, pullDown)) : _Utils_Tuple2(
					A2(
						$elm_explorations$linear_algebra$Math$Vector3$add,
						linePos1,
						A2($elm_explorations$linear_algebra$Math$Vector3$scale, 1.6, pullDown)),
					A2(
						$elm_explorations$linear_algebra$Math$Vector3$add,
						linePos2,
						A2($elm_explorations$linear_algebra$Math$Vector3$scale, 1.6, pullDown)));
				var finalPos1 = _v4.a;
				var finalPos2 = _v4.b;
				return $elm$core$Maybe$Just(
					_Utils_Tuple2(finalPos1, finalPos2));
			}
		}
	});
var $author$project$MaxkCut$makeCutLineB = function (shapeTransition) {
	var vertices = shapeTransition.graphB.vertices;
	var firstTuple = _List_fromArray(
		[
			_Utils_Tuple2(4, 6),
			_Utils_Tuple2(7, 9),
			_Utils_Tuple2(1, 3)
		]);
	var listOfTupledPosns = A2(
		$elm$core$List$filterMap,
		$author$project$Graph$findPositionsOfTuples(vertices),
		firstTuple);
	var edgeLines = $author$project$Graph$findEdgeLines(shapeTransition.graphB.edges);
	var intersectionPoints = A2(
		$elm$core$List$map,
		function (_v1) {
			var p1 = _v1.a;
			var p2 = _v1.b;
			return A2(
				$elm$core$List$filterMap,
				$author$project$Graph$findIntersection(
					_Utils_Tuple2(p1, p2)),
				edgeLines);
		},
		listOfTupledPosns);
	return A3(
		$elm$core$List$map2,
		F2(
			function (_v0, ins) {
				var p1 = _v0.a;
				var p2 = _v0.b;
				return A3($author$project$MaxkCut$CutLine, p1, p2, ins);
			}),
		listOfTupledPosns,
		intersectionPoints);
};
var $author$project$MaxkCut$paneTwoB = function (shapeTransition) {
	var graphB = shapeTransition.graphB;
	var graphA = shapeTransition.graphA;
	var _v0 = shapeTransition.specialToken;
	if (_v0.$ === 'MakeKCut') {
		var cutLines = $author$project$MaxkCut$makeCutLineB(shapeTransition);
		var drawCutLines = $elm$core$List$concat(
			A2($elm$core$List$map, $author$project$MaxkCut$drawCutLine, cutLines));
		return $author$project$Graph$displaySvg(
			_Utils_ap(
				$author$project$Graph$drawGraph(graphB),
				drawCutLines));
	} else {
		return $author$project$Graph$displaySvg(
			$author$project$Graph$drawGraph(graphB));
	}
};
var $author$project$MaxkCut$paneTwo = function (maxCutTrans) {
	var _v0 = maxCutTrans.state;
	if (_v0.$ === 'TwoCut') {
		return $author$project$MaxkCut$paneTwoA(maxCutTrans.transitionA);
	} else {
		return $author$project$MaxkCut$paneTwoB(maxCutTrans.transitionB);
	}
};
var $author$project$Main$showTopic = function (displaySize) {
	return $mdgriffith$elm_ui$Element$row(
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$height(
				A2($mdgriffith$elm_ui$Element$maximum, displaySize.height, $mdgriffith$elm_ui$Element$fill))
			]));
};
var $author$project$Main$viewTopic = F2(
	function (model, displaySize) {
		var explanationSize = _Utils_update(
			displaySize,
			{width: (displaySize.width / 2) | 0});
		var _v0 = model.topic;
		switch (_v0.$) {
			case 'Isomorphic':
				var isoTopic = _v0.a;
				return A2(
					$author$project$Main$showTopic,
					displaySize,
					_List_fromArray(
						[
							$author$project$Main$displayColumn(
							$author$project$Isomorphism$isomorphicDisplay(isoTopic)),
							A3($author$project$Isomorphism$explanationOne, isoTopic, model.helpStatus, explanationSize)
						]));
			case 'MaxCut':
				var maxCutTrans = _v0.a;
				return A2(
					$author$project$Main$showTopic,
					displaySize,
					_List_fromArray(
						[
							$author$project$Main$displayColumn(
							$author$project$MaxkCut$paneTwo(maxCutTrans)),
							A3($author$project$MaxkCut$explanationTwo, maxCutTrans, model.helpStatus, explanationSize)
						]));
			case 'GraphColoring':
				var display = _v0.a;
				return A2(
					$author$project$Main$showTopic,
					displaySize,
					_List_fromArray(
						[
							$author$project$Main$displayColumn(
							$author$project$GraphColoring$paneThree(display)),
							A3($author$project$GraphColoring$explanationColoring, display, model.helpStatus, explanationSize)
						]));
			case 'VertexCover':
				var display = _v0.a;
				return A2(
					$author$project$Main$showTopic,
					displaySize,
					_List_fromArray(
						[
							$author$project$Main$displayColumn(
							$author$project$VertexCover$paneFour(display)),
							A3($author$project$VertexCover$explanationCover, display, model.helpStatus, explanationSize)
						]));
			case 'TreeWidth':
				var display = _v0.a;
				return A2(
					$author$project$Main$showTopic,
					displaySize,
					_List_fromArray(
						[
							$author$project$Main$displayColumn(
							$author$project$TreeWidth$paneTree(display)),
							A3($author$project$TreeWidth$explanationWidth, display, model.helpStatus, explanationSize)
						]));
			case 'HomePage':
				return $author$project$Main$homePage(displaySize);
			case 'ScreenSize':
				return A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill)
						]),
					$mdgriffith$elm_ui$Element$text(
						$elm$core$String$fromInt(model.displaySize.width) + (' x ' + $elm$core$String$fromInt(model.displaySize.height))));
			default:
				return A2($author$project$Main$aboutPage, model.displaySize.width, model.displaySize.height);
		}
	});
var $author$project$Main$viewbody = function (model) {
	var heightOfHeader = $elm$core$Basics$round(model.displaySize.height * 0.085);
	var heightOfRest = model.displaySize.height - heightOfHeader;
	var displaySize = A3($author$project$FontSize$DisplaySize, model.displaySize.width, heightOfRest, model.displaySize.deviceType);
	return A3(
		$mdgriffith$elm_ui$Element$layoutWith,
		$author$project$Main$layOutOptions,
		$author$project$Main$layOutAttributes(model.displaySize.deviceType),
		A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$fill)
				]),
			_List_fromArray(
				[
					$author$project$Main$headerOfPage(heightOfHeader),
					A2($author$project$Main$viewTopic, model, displaySize)
				])));
};
var $author$project$Main$view = function (model) {
	return {
		body: _List_fromArray(
			[
				$author$project$Main$viewbody(model)
			]),
		title: 'Visualization'
	};
};
var $author$project$Main$main = $elm$browser$Browser$application(
	{init: $author$project$Main$init, onUrlChange: $author$project$Messages$UrlChanged, onUrlRequest: $author$project$Messages$LinkClicked, subscriptions: $author$project$Main$subscription, update: $author$project$Main$update, view: $author$project$Main$view});
_Platform_export({'Main':{'init':$author$project$Main$main(
	A2(
		$elm$json$Json$Decode$andThen,
		function (width) {
			return A2(
				$elm$json$Json$Decode$andThen,
				function (height) {
					return $elm$json$Json$Decode$succeed(
						{height: height, width: width});
				},
				A2($elm$json$Json$Decode$field, 'height', $elm$json$Json$Decode$int));
		},
		A2($elm$json$Json$Decode$field, 'width', $elm$json$Json$Decode$int)))(0)}});}(this));