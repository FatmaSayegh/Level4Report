module Test.Generated.Main exposing (main)

import Example

import Test.Reporter.Reporter exposing (Report(..))
import Console.Text exposing (UseColor(..))
import Test.Runner.Node
import Test

main : Test.Runner.Node.TestProgram
main =
    Test.Runner.Node.run
        { runs = 100
        , report = ConsoleReport UseColor
        , seed = 280131561788775
        , processes = 12
        , globs =
            []
        , paths =
            [ "/home/fatoom/Documents/Project/Repository/Website/tests/Example.elm"
            ]
        }
        [ ( "Example"
          , [ Test.Runner.Node.check Example.keyToMsgTest
            , Test.Runner.Node.check Example.myGrid
            , Test.Runner.Node.check Example.testGraph
            , Test.Runner.Node.check Example.changeGlowTestSuite
            , Test.Runner.Node.check Example.graphGridDistSuite
            , Test.Runner.Node.check Example.graphGridDistValueSuite
            , Test.Runner.Node.check Example.makeGraphNoVerticesSuite
            , Test.Runner.Node.check Example.isLookUpVertexNameSameSuit
            , Test.Runner.Node.check Example.fullyConnectedGraphEdgeCountSuite
            ]
          )
        ]