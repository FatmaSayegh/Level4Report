1. Drag vertex to change it's position
2. Draw straight line
3. Calculate the intersection of two lines.
4. Draw polyline.
5. Make vertices divided into two sets depending on which side of the 
   line of the polyline they lie on.
