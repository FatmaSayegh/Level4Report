### Now make an index.html and start from there.

- Make index.html
- Get fonts
- Center Elements.
